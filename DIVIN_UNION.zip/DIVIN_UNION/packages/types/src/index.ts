export type Plan = 'FREE' | 'PREMIUM' | 'ELITE';
export type MaritalStatus = 'SINGLE' | 'WIDOWED' | 'DIVORCED' | 'SEPARATED';
export type Gender = 'MALE' | 'FEMALE';
export type Role = 'USER' | 'MODERATOR' | 'SUPER_ADMIN';
export interface PublicProfile { id: string; firstName: string; lastName: string; age: number; gender: Gender; city: string; country: string; photoUrl: string; bio: string; maritalStatus: MaritalStatus; verified: boolean; plan: Plan; }
