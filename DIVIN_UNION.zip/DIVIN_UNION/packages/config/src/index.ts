export const APP_NAME = "Divin'Union";
export const FREE_DAILY_MESSAGE_LIMIT = 5;
export const COORDINATE_MIN_MESSAGES_EACH = 10;
export const PLANS = { FREE: 0, PREMIUM: 4.99, ELITE: 9.99 } as const;
