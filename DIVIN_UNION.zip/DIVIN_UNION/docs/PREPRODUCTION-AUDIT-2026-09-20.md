# Divin'Union — audit pré-production et feuille de route

**Date :** 20 septembre 2026  
**Base auditée :** `divin-union-mvp.zip`  
**Statut :** architecture de référence, non production

## 1. Périmètre observé

Le dépôt est un monorepo pnpm composé d’une application web Next.js, d’une API NestJS, d’un accès PostgreSQL via Prisma, d’une base Redis prévue par Docker Compose et de contrats partagés. Les domaines déjà présents sont l’inscription, l’authentification, les profils, la découverte, les likes, la messagerie REST/Socket.IO, la modération, l’administration et les abonnements.

Les règles produit existantes couvrent l’accès 18+, l’appartenance chrétienne, les statuts matrimoniaux autorisés, la photo obligatoire, les offres Free/Premium/Elite, la limite de cinq messages texte gratuits par jour, les photos et notes vocales réservées aux abonnés, le filtrage des coordonnées et l’absence d’appels audio/vidéo.

## 2. Constats bloquants avant production

| Priorité | Domaine | Constat | Risque | Remédiation attendue |
|---|---|---|---|---|
| P0 | OTP | `register()` positionne `phoneVerified: true`, mais ne vérifie pas qu’un OTP a effectivement été validé pour ce numéro et ce parcours d’inscription. | Création de comptes avec numéro non vérifié. | Introduire un challenge OTP à usage unique, lié au téléphone et au contexte d’inscription, consommé atomiquement lors de la création du compte. |
| P0 | Authentification | Le schéma contient `RefreshSession`, mais le service ne crée ni ne renouvelle de session de refresh token. | Révocation impossible et sessions longues non contrôlables. | Ajouter access token court, refresh token opaque haché en base, rotation, révocation, détection de réutilisation et cookies sécurisés. |
| P0 | Secrets | Des secrets de développement sont utilisés par défaut (`dev-secret-change-me`). | Risque de compromission si la configuration est incomplète. | Refuser le démarrage en environnement non local quand les secrets requis sont absents ou faibles. |
| P0 | WebSocket | Le gateway autorise `origin: '*'` et les événements `conversation:join`/`typing` sans vérifier l’identité ni l’appartenance à la conversation. | Lecture indirecte de présence, événements inter-utilisateurs et abus cross-origin. | Authentifier le handshake Socket.IO, vérifier les membres côté serveur avant chaque join et limiter l’origine aux domaines configurés. |
| P0 | Médias | L’inscription demande `profilePhotoUrl` librement fourni par le client ; `mediaUrl` est également persisté sans upload ni contrôle de type, taille ou propriété. | Médias non maîtrisés, liens externes, contenu malveillant et fuite de données. | Ajouter un stockage objet privé, URLs présignées, contrôle MIME/taille, antivirus/modération, ownership et expiration des URLs. |
| P0 | Paiement | `checkout` retourne uniquement un objet de prix et le fournisseur configuré (`mock` par défaut). Aucun webhook signé ne met à jour les abonnements. | Paiements non encaissés ou droits premium falsifiables. | Choisir un prestataire compatible avec le marché cible, implémenter checkout réel, webhooks signés idempotents, rapprochement et révocation des droits. |
| P1 | SMS | Le code OTP est écrit dans les logs et renvoyé en mode développement ; aucun rate limiting n’est visible. | Fuite de codes et abus SMS/brute force. | Adapter SMS réel, limites par numéro/IP/appareil, cooldown, compteur d’essais atomique, journalisation sans secret et alertes. |
| P1 | Validation | Plusieurs contrôleurs utilisent `any` et aucun DTO explicite n’est défini pour les entrées critiques. | Payloads inattendus, types faibles et règles métier contournables. | DTO `class-validator` stricts pour auth, profils, messages, rapports, admin et paiements ; activer `forbidNonWhitelisted`. |
| P1 | RBAC | Les contrôleurs admin/modération lèvent `Error('Forbidden')` au lieu d’exceptions HTTP dédiées ou d’un guard partagé. | Réponses 500 et contrôle d’accès dispersé. | Créer un `RolesGuard`/décorateur, retourner 403, journaliser les actions sensibles et protéger le super-admin contre l’auto-suppression. |
| P1 | Messagerie | Le compteur gratuit compte les messages persistés mais la règle de filtrage retourne un blocage sans créer d’événement d’audit ; audio/image n’ont pas de pipeline média. | Contournement, expérience incohérente et modération incomplète. | Quota atomique/Redis, décision de blocage auditée, validation de taille/type et modération média. |
| P1 | Modération | Le signalement est peu validé et les actions de résolution/audit ne sont pas exposées dans la base observée. | Traitement manuel non traçable. | Workflow de modération avec statuts, résolution, notes internes, audit immutable et protections contre les abus de signalement. |
| P1 | Vie privée | Les profils exposent directement `photoUrl` et plusieurs données personnelles ; le mode invisible/voyage existe au schéma mais n’est pas raccordé aux requêtes observées. | Exposition de données et fonctionnalités annoncées incomplètes. | Définir précisément la visibilité par plan, filtrer les champs publics, signer les accès média et implémenter les règles Elite. |
| P2 | Qualité | Aucun test E2E visible dans l’archive ; la couverture des règles critiques n’est pas établie. | Régressions sur auth, quotas, droits et paiements. | Tests unitaires et E2E PostgreSQL/Redis : OTP, âge, quotas, filtrage, RBAC, webhooks, revocation et WebSocket. |
| P2 | Déploiement | Docker Compose couvre surtout le local ; HTTPS, migrations contrôlées, sauvegardes, observabilité et gestion des secrets ne sont pas décrits comme déploiement effectif. | Déploiement fragile et reprise difficile. | Pipeline CI/CD, secrets manager, TLS, migrations non destructives, sauvegardes chiffrées, logs structurés, métriques et alertes. |

## 3. Écarts fonctionnels à clarifier avant codage

Les décisions suivantes manquent et changent l’architecture ou les contrats externes :

1. **SMS/OTP :** quel prestataire et quels pays doivent être couverts au lancement ? Le périmètre prioritaire est-il RDC uniquement ou international dès la première version ?
2. **Paiement :** quel prestataire doit être utilisé pour les paiements récurrents en dollars, notamment pour les utilisateurs en RDC ? Faut-il gérer uniquement carte bancaire ou aussi Mobile Money ?
3. **Stockage média :** quel fournisseur objet est retenu, et quelles limites sont souhaitées pour les photos, audios et durées de conservation ?
4. **Authentification :** le mot de passe doit-il rester un mécanisme de secours après OTP, ou l’inscription et la connexion doivent-elles devenir entièrement passwordless ?
5. **Visibilité produit :** quelles sont les règles exactes de confidentialité Elite (profil invisible, découverte, affichage des likes, mode voyage) et leur priorité par rapport aux utilisateurs Free/Premium ?
6. **Administration :** quelles actions un `MODERATOR` peut-il effectuer exactement, et qui peut créer/révoquer les rôles ?

## 4. Séquence d’implémentation recommandée

### Tranche A — sécurité de l’identité

Mettre en place les DTO stricts, normaliser et valider les numéros au format international, créer le challenge OTP lié à l’inscription, ajouter limites et verrouillage, implémenter les refresh sessions rotatives, durcir les secrets et ajouter les tests d’authentification.

### Tranche B — contrôle d’accès et temps réel

Ajouter le guard de rôles, les exceptions HTTP correctes, l’audit des actions sensibles, l’authentification Socket.IO et la vérification d’appartenance à chaque conversation.

### Tranche C — médias

Choisir le stockage objet, implémenter les URLs présignées et l’ownership, puis brancher les photos et notes vocales avec limites de taille, MIME, antivirus et modération.

### Tranche D — abonnements

Choisir le prestataire, créer checkout et portail client si disponible, traiter les webhooks signés de manière idempotente, synchroniser `Subscription` et `User.plan`, puis couvrir les transitions d’échec, expiration et remboursement.

### Tranche E — abus, modération et exploitation

Ajouter Redis pour les quotas/rate limits, détecter les comportements abusifs, compléter le workflow de signalement, créer l’audit immutable, fournir les métriques et préparer les sauvegardes et alertes.

### Tranche F — validation de livraison

Ajouter tests unitaires, intégration et E2E, CI avec lint/build/migrations contrôlées, déploiement HTTPS, vérification des headers, rotation des secrets et procédure de rollback.

## 5. Règle de conservation de la base existante

Aucune fonctionnalité actuelle ne doit être supprimée sans validation. Les changements de contrat doivent être introduits de façon additive lorsque c’est possible, avec migration Prisma non destructive et tests de compatibilité pour les parcours existants.

## 6. Conclusion

La structure est une bonne base de travail, mais elle doit rester explicitement **MVP non production**. La prochaine implémentation sûre est la tranche A, après choix du prestataire SMS et confirmation du comportement souhaité pour le mot de passe. Les choix paiement et stockage peuvent être préparés par interfaces/adapters, mais leur intégration réelle ne doit pas être simulée comme si elle était prête pour la production.
