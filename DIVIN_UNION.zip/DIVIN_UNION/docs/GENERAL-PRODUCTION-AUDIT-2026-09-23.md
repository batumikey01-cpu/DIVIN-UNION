# Divin'Union — audit général de préparation à la production

**Date :** 23 septembre 2026  
**Périmètre :** monorepo pnpm, API NestJS, Web Next.js, Prisma/PostgreSQL, Socket.IO, Docker Compose, authentification, matching, messagerie, modération, administration et abonnements.  
**Conclusion :** **non autorisé pour une mise en production**.

## 1. Verdict exécutif

Le projet constitue une base MVP cohérente et compilable. Le frontend Next.js et l’API NestJS se compilent sans erreur, et les sept suites unitaires API passent. L’authentification dispose déjà d’un JWT court, de refresh sessions persistantes hachées, d’une rotation et d’une détection de réutilisation. Le gateway Socket.IO vérifie désormais le JWT et l’appartenance aux conversations.

Ces résultats ne suffisent pas à qualifier l’application de production-ready. Plusieurs fonctions essentielles restent des interfaces ou des comportements de développement. Le paiement ne crée pas de checkout réel et ne traite aucun webhook. Le SMS est encore absent en production. Les médias sont acceptés comme URLs fournies par le client, sans upload contrôlé. Les tests d’intégration avec PostgreSQL et Redis n’ont pas été exécutés, car Docker n’est pas disponible dans l’environnement d’audit et aucun serveur PostgreSQL local ne répond sur `127.0.0.1:5432`. Enfin, `pnpm audit --prod` signale **9 avis**, dont **6 de sévérité élevée**, **2 modérés** et **1 faible**.

La décision recommandée est donc : **poursuivre l’implémentation et bloquer toute mise en ligne publique jusqu’à la clôture des P0 et des P1 listés ci-dessous**.

## 2. Résultats de validation

| Contrôle | Résultat | Interprétation |
|---|---:|---|
| Build API NestJS | Réussi | Le typage et les imports de l’API passent. |
| Build Web Next.js | Réussi | Next.js 15.5.25 compile et génère les routes prévues. |
| Tests unitaires API | **28/28** | 7 suites passent. La couverture reste unitaire et mockée. |
| Validation Prisma | Réussie avec `DATABASE_URL` | Le schéma est valide. |
| État des migrations | Non vérifiable | PostgreSQL est inaccessible sur `127.0.0.1:5432`. |
| Tests intégration PostgreSQL/Redis | Non exécutés | Docker n’est pas installé dans l’environnement d’audit. |
| Audit dépendances production | Échec | 9 avis : 6 high, 2 moderate, 1 low. |
| Health check | Partiel | `/health` renvoie un statut statique et ne vérifie ni PostgreSQL ni Redis. |

La première commande de test a été relancée avec la syntaxe correcte. La commande `pnpm --filter @divinunion/api test -- --runInBand` transmettait un motif invalide à Jest et produisait « No tests found » ; la commande fiable est `pnpm --filter @divinunion/api exec jest --runInBand`.

## 3. Bloqueurs P0 — à traiter avant toute production

### P0.1 — Aucun fournisseur SMS réel n’est branché

`AuthService.requestOtp()` génère et hache le code, mais le dépôt ne contient pas d’adapter SMS réel. Le projet expose le code dans la réponse en environnement non production et l’écrit dans les logs de développement. Compose utilise `SMS_PROVIDER=mock` par défaut et le bootstrap ne refuse pas cette valeur lorsque `NODE_ENV=production`.

Le parcours d’inscription ne peut donc pas être considéré comme opérationnel en production. Il faut choisir le fournisseur et les pays couverts, implémenter l’interface d’envoi, supprimer toute sortie de code OTP, imposer l’échec du démarrage lorsque le provider est mock en production et ajouter des tests d’intégration avec un adapter de test isolé.

### P0.2 — Les abonnements et paiements ne sont pas réels

`SubscriptionsService.createCheckout()` renvoie uniquement un plan, des prix et le nom du provider. Il ne crée pas de session de paiement, ne persiste pas une souscription active et ne possède aucun endpoint de webhook signé. Le schéma `Subscription` existe, mais il n’est pas alimenté par un flux de paiement vérifié.

Aucun droit Premium ou Elite ne doit être accordé sur la base de cette implémentation. Il faut choisir un prestataire compatible avec le marché cible, ajouter l’adapter, vérifier les signatures, rendre les webhooks idempotents, gérer les expirations, remboursements et échecs, puis synchroniser `Subscription` et `User.plan` côté serveur.

### P0.3 — Les médias ne sont pas sécurisés

`profilePhotoUrl` est fourni directement par le client et `mediaUrl` peut être persisté sans contrôle d’ownership, de MIME, de taille, de contenu ou d’expiration. Aucun upload objet, URL présignée, antivirus ou pipeline de modération n’est présent.

Cette situation permet des liens externes arbitraires et ne répond pas aux exigences de photos et notes vocales. Il faut choisir S3, R2 ou GCS, créer une abstraction de stockage, limiter les extensions et types MIME, vérifier la taille, rattacher chaque objet à son propriétaire et ne servir que des URLs contrôlées.

### P0.4 — Les migrations et le démarrage réel n’ont pas été validés sur PostgreSQL

Le schéma Prisma est valide, et une migration initiale existe. Cependant, `prisma migrate status` échoue avec `P1001` car aucun serveur PostgreSQL ne répond sur `127.0.0.1:5432`. Docker n’est pas installé dans l’environnement d’audit. La migration n’a donc pas été appliquée sur une base réelle et le seed n’a pas été exécuté dans cette validation.

Avant production, il faut exécuter une base PostgreSQL versionnée dans CI et dans un environnement de staging, appliquer `prisma migrate deploy`, exécuter le seed uniquement dans les environnements autorisés et tester un déploiement depuis une base vide puis depuis une base existante.

## 4. Risques P1 — à traiter avant ouverture publique

### P1.1 — Rate limiting incomplet et non distribué

La demande OTP impose un cooldown par numéro, mais aucune limite par IP, appareil ou compte n’est visible. La vérification OTP incrémente les tentatives avec une opération séparée et la consommation de vérification elle-même n’est pas conditionnelle : deux vérifications concurrentes peuvent potentiellement réussir avant que `usedAt` soit écrit. La connexion par mot de passe n’a pas de limite d’essais apparente.

Redis est déclaré dans Compose, mais aucun rate limiter distribué n’est raccordé aux routes sensibles. Il faut ajouter des limites sur OTP request, OTP verify, login, refresh et actions de messagerie. Les compteurs et la consommation doivent être atomiques, avec verrouillage ou mise à jour conditionnelle et journalisation des décisions sans secrets.

### P1.2 — DTOs critiques encore remplacés par `any`

Les contrôleurs de messagerie et d’abonnement acceptent des corps `any`. La validation globale NestJS est correctement activée avec `whitelist`, `transform`, `forbidNonWhitelisted` et `forbidUnknownValues`, mais elle ne peut pas protéger un payload qui n’a pas de DTO explicite.

Il faut ajouter des DTOs stricts pour la création de conversation, l’envoi de message, le type et la taille du corps, les URLs média, les checkouts, les webhooks et les paramètres d’administration. Les identifiants de route doivent également être validés et les champs sensibles doivent être rejetés plutôt qu’ignorés.

### P1.3 — Risque de sélection trop large de conversations

`conversationHistory()` et `createConversation()` utilisent une condition Prisma `every` sur les membres et vérifient que les deux utilisateurs sont inclus. Cette logique peut correspondre à une conversation qui contient également d’autres membres. Le modèle n’a pas de contrainte garantissant qu’une conversation de rencontre est strictement composée de deux personnes.

Il faut définir le modèle conversationnel : conversation strictement bipartite ou groupe autorisé. Pour le parcours actuel, il faut rechercher une paire exacte, vérifier l’appartenance de l’utilisateur demandeur et ajouter des tests empêchant toute fuite d’historique d’une conversation contenant un tiers.

### P1.4 — Protection et traçabilité de l’administration incomplètes

Le RBAC existe pour les contrôleurs admin et de modération, ce qui est une amélioration importante. Toutefois, la recherche administrateur expose notamment le téléphone, les actions sensibles ne sont pas enregistrées dans un journal d’audit immuable et la suppression logique ne montre pas de protection spécifique contre l’auto-suppression du dernier super-administrateur.

Il faut limiter les champs selon le rôle, ajouter un audit append-only pour les opérations sensibles, imposer une validation des paramètres d’administration et tester les scénarios de révocation, de dernier super-administrateur et d’accès modérateur.

### P1.5 — Quotas et modération non atomiques

La limite de cinq messages gratuits par jour est calculée par comptage des messages persistés. Cette logique peut être contournée par des requêtes concurrentes si plusieurs messages sont acceptés avant le comptage suivant. Les contenus filtrés renvoient un résultat bloqué, mais la décision n’est pas enregistrée dans un audit de modération.

Il faut déplacer le quota vers une opération atomique ou Redis avec expiration quotidienne, conserver une trace minimale des blocages et couvrir les courses concurrentes par des tests d’intégration.

### P1.6 — Headers et protection Web à compléter

`helmet` est configuré sur l’API. Le frontend Next.js ne montre pas de politique CSP, de headers de sécurité applicatifs ou de stratégie explicite contre le chargement de contenu arbitraire. Le token d’accès est conservé dans `localStorage`, ce qui augmente l’impact d’une XSS côté Web, même si le refresh token est HttpOnly.

Avant production, il faut définir une CSP compatible avec Next.js et les images utilisées, vérifier les headers en staging, limiter les origines Socket.IO et évaluer un mécanisme d’accès qui réduise l’exposition du token côté navigateur.

### P1.7 — Dépendances vulnérables non résolues

`pnpm audit --prod` signale neuf avis, dont six high, deux moderate et un low. Les chaînes identifiées incluent notamment `postcss` via Next.js, `deepmerge-ts` via Prisma et `multer` via `@nestjs/platform-express`. L’audit doit être rejoué après mise à niveau des dépendances et chaque exception doit être documentée avec son impact réel dans les bundles de production.

Le dépôt ne doit pas être déclaré prêt tant que les versions corrigées ne sont pas installées ou qu’une analyse documentée ne justifie chaque exception.

## 5. Risques P2 — à traiter avant une exploitation durable

La couverture actuelle est limitée à sept suites unitaires API. Elle ne comprend pas de test E2E avec PostgreSQL, de test Redis, de test de migrations, de test de webhook de paiement, de test d’upload média, de test de cookies en navigateur ou de test de déploiement conteneurisé.

Le health check `/health` est statique. Il doit exposer au minimum l’état de l’API et, selon le besoin opérationnel, la disponibilité de PostgreSQL et Redis sans divulguer de secret. Les conteneurs n’ont pas encore de procédure documentée de sauvegarde, restauration, rotation de secrets, rollback et migration contrôlée. La configuration Compose reste adaptée au développement et au staging, pas à elle seule à une exposition publique.

Les valeurs par défaut de PostgreSQL dans Compose sont des identifiants de développement. Elles doivent être interdites en production, même si les variables sont normalement surchargées. Les images gagneraient également à utiliser un utilisateur non root, des healthchecks applicatifs et une configuration de logs structurés.

## 6. Éléments déjà satisfaisants

L’API et le Web compilent actuellement sans erreur. Le schéma Prisma est syntaxiquement valide. Les refresh tokens sont opaques, hachés en base et associés à une session. La rotation révoque l’ancien token et la réutilisation d’une session révoquée déclenche la révocation des sessions actives de l’utilisateur.

La validation globale NestJS est stricte. Le parcours d’inscription vérifie l’âge minimal, l’appartenance chrétienne et le challenge OTP avant de marquer le téléphone comme vérifié. Le matching exclut les utilisateurs inactifs, supprimés, bloqués et déjà swipés. Le gateway Socket.IO authentifie le handshake, contrôle les membres avant l’entrée dans une room et dérive l’expéditeur du socket plutôt que du payload client.

Le dépôt contient une migration initiale, un seed de démonstration et des comptes de test. Ces données sont utiles pour le développement, mais elles ne doivent pas être exécutées ou exposées dans un environnement de production.

## 7. Plan de sortie recommandé

La prochaine étape doit être une tranche de durcissement, et non une mise en ligne. Elle doit d’abord choisir les fournisseurs SMS, paiement et stockage. Ensuite, l’équipe doit brancher les adapters réels derrière des interfaces, refuser les providers mockés en production et compléter les DTOs, limites et opérations atomiques.

La deuxième étape doit créer un environnement staging avec PostgreSQL et Redis réels. Il faut y appliquer les migrations, exécuter le seed contrôlé, lancer les E2E et tester les scénarios de concurrence. Les dépendances doivent être corrigées avant la création de l’image finale.

La troisième étape doit mettre en place le déploiement sécurisé : TLS au niveau du reverse proxy ou de la plateforme, secrets manager, sauvegardes chiffrées, restauration testée, logs structurés, métriques, alertes et procédure de rollback. La mise en production ne pourra être envisagée qu’après une nouvelle validation documentée sans P0 ni P1 ouverts.

## 8. Décisions requises du propriétaire du produit

Les choix suivants restent nécessaires pour terminer l’architecture sans inventer d’intégration :

1. Le fournisseur SMS et les pays couverts au lancement.
2. Le prestataire de paiement, les devises et le support éventuel de Mobile Money.
3. Le fournisseur de stockage objet et les limites de photos et d’audios.
4. La politique exacte des profils invisibles, du mode voyage et des droits Elite.
5. La définition précise des pouvoirs `MODERATOR` et `SUPER_ADMIN`.
6. La politique de conservation et de suppression des photos, audios, messages et rapports.

## 9. Commandes de vérification exécutées

```bash
pnpm --filter @divinunion/api exec jest --runInBand
pnpm --filter @divinunion/api build
pnpm --filter @divinunion/web build
DATABASE_URL='postgresql://divinunion:divinunion@127.0.0.1:5432/divinunion?schema=public' \
  pnpm --filter @divinunion/api exec prisma validate
DATABASE_URL='postgresql://divinunion:divinunion@127.0.0.1:5432/divinunion?schema=public' \
  pnpm --filter @divinunion/api exec prisma migrate status
pnpm audit --prod --json
```

`prisma validate` passe lorsque `DATABASE_URL` est fournie. `prisma migrate status` échoue ensuite avec `P1001`, car la base n’est pas joignable. Le build Web génère notamment les routes `/`, `/discover`, `/login`, `/register`, `/chat/[partnerId]` et `/profile/[id]`.

## Références

[1]: ../apps/api/src/main.ts "Bootstrap API, validation, CORS et secrets"
[2]: ../apps/api/src/auth/auth.service.ts "Service d’authentification, OTP et refresh sessions"
[3]: ../apps/api/src/messaging/messaging.gateway.ts "Gateway Socket.IO et contrôle d’accès aux conversations"
[4]: ../apps/api/src/messaging/messaging.service.ts "Quotas, filtrage et persistance des messages"
[5]: ../apps/api/src/subscriptions/subscriptions.service.ts "Checkout d’abonnement actuellement disponible"
[6]: ../apps/api/prisma/schema.prisma "Schéma Prisma"
[7]: ../apps/api/prisma/migrations/00000000000000_init/migration.sql "Migration Prisma initiale"
[8]: ../infra/docker-compose.yml "Services locaux PostgreSQL, Redis, API et Web"
[9]: ../docs/PREPRODUCTION-AUDIT-2026-09-20.md "Audit préproduction précédent et feuille de route"
[10]: https://github.com/advisories/GHSA-qx2v-qp2m-jg93 "Avis PostCSS signalé par l’audit des dépendances"
[11]: https://github.com/advisories/GHSA-6g55-p6wh-862q "Avis PostCSS signalé par l’audit des dépendances"

**Auteur :** Manus AI
