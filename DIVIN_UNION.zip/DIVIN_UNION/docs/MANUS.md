# Reprise Manus AI
1. Copier .env.example vers les secrets.
2. Démarrer PostgreSQL/Redis via infra/docker-compose.yml.
3. pnpm install; pnpm db:generate; pnpm db:migrate; pnpm db:seed.
4. Brancher un fournisseur SMS et son callback signé.
5. Brancher le prestataire de paiement et ses webhooks signés.
6. Ajouter stockage objet privé pour photos/audio.
7. Ajouter rate limiting distribué Redis.
8. Ajouter tests E2E et scans de sécurité avant production.
9. Ne jamais committer les secrets.
