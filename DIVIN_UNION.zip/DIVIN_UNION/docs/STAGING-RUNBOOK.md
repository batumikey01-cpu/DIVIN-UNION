# Runbook staging et rollback

## Pré-déploiement

Injecter les secrets depuis le gestionnaire de secrets, exécuter `node scripts/verify-env.mjs`, puis lancer `pnpm install --frozen-lockfile`, `pnpm --filter @divinunion/api exec prisma validate`, les tests, les builds et `pnpm audit --prod`. Les fournisseurs doivent être réels en staging ; les providers `mock` et `local` sont réservés au développement et aux tests.

## Migration

Sauvegarder PostgreSQL avant toute migration. Exécuter `pnpm --filter @divinunion/api exec prisma migrate deploy` avec `DATABASE_URL` staging. Vérifier `/health`, les logs, les migrations appliquées et les parcours d’authentification, messagerie, médias et abonnements.

## Rollback applicatif

Déployer l’image précédente immuable, sans supprimer la base. Si une migration irréversible a été appliquée, suivre une migration corrective versionnée ; ne jamais modifier manuellement l’historique Prisma en production. Restaurer la sauvegarde uniquement après décision d’incident et vérification de son intégrité.

## Contrôles post-déploiement

Vérifier les healthchecks API/Web, les erreurs 5xx, les connexions Socket.IO, les notifications, les événements de paiement et les accès média. Documenter l’heure, la version déployée, les migrations et la décision de maintien ou de rollback.
