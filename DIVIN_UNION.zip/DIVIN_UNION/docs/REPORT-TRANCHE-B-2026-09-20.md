# Divin'Union — rapport de Tranche B

**Tranche :** contrôle d’accès et temps réel  
**Date :** 20 septembre 2026  
**Statut :** implémentée et validée par compilation/tests ; non production

## Ce qui a été implémenté

Un décorateur `Roles()` et un `RolesGuard` partagés ont été ajoutés. Les endpoints d’administration et de modération utilisent maintenant le guard JWT puis le guard de rôles, avec des réponses 403 via `ForbiddenException` au lieu d’erreurs génériques susceptibles de devenir des 500.

La matrice actuellement codée conserve les capacités existantes : `MODERATOR` et `SUPER_ADMIN` peuvent rechercher les utilisateurs et consulter les statistiques ; seul `SUPER_ADMIN` peut supprimer un utilisateur. Les signalements restent accessibles aux utilisateurs authentifiés, tandis que la consultation des signalements est limitée à `MODERATOR` et `SUPER_ADMIN`. Aucune route existante n’a été supprimée.

Le gateway Socket.IO n’accepte plus les origines `*`. Il utilise l’origine web configurée, vérifie un JWT transmis dans `handshake.auth.token` ou dans l’en-tête Authorization, vérifie que l’utilisateur existe et est actif, puis attache son identité au socket. Les événements `conversation:join` et `typing` vérifient désormais l’appartenance à la conversation avant de rejoindre une room ou d’émettre un événement.

## Fichiers modifiés ou ajoutés

| Fichier | Rôle |
|---|---|
| `apps/api/src/common/roles.guard.ts` | Décorateur `Roles` et guard RBAC partagé |
| `apps/api/src/admin/admin.controller.ts` | Contrôle déclaratif des rôles admin |
| `apps/api/src/admin/admin.module.ts` | Enregistrement des dépendances RBAC/auth |
| `apps/api/src/moderation/moderation.controller.ts` | Contrôle déclaratif des rôles modération |
| `apps/api/src/moderation/moderation.module.ts` | Enregistrement des dépendances RBAC/auth |
| `apps/api/src/messaging/messaging.gateway.ts` | Handshake JWT, origine contrôlée et vérification de membership |
| `apps/api/src/messaging/messaging.module.ts` | Injection de `JwtService` et `PrismaService` dans le gateway |
| `docs/REPORT-TRANCHE-B-2026-09-20.md` | Présent rapport |

## Migrations effectuées

Aucune migration SQL n’a été nécessaire pour cette tranche. Le RBAC repose sur l’enum `Role` existant et la sécurité WebSocket réutilise les tables `User` et `ConversationMember` existantes.

## Tests exécutés

- `pnpm build` — compilation NestJS et build Next.js réussis.
- `pnpm test` — 1 suite, 3 tests réussis ; les tests de la Tranche A restent verts.

La matrice RBAC et les événements Socket.IO n’ont pas encore de tests E2E avec serveur et base PostgreSQL réels ; c’est un point restant de la Tranche F.

## Problèmes restant à résoudre

Les corps des endpoints admin, modération et messagerie utilisent encore plusieurs `any` et doivent recevoir leurs DTOs stricts. Les actions admin sensibles ne sont pas encore journalisées dans un audit immutable. La création/révocation des rôles n’est pas exposée et devra être spécifiée avant implémentation.

Le gateway vérifie l’identité et l’appartenance, mais il ne dispose pas encore de rate limiting Redis, de limite de taille des payloads, de gestion centralisée des erreurs Socket.IO ni de tests E2E. La configuration CORS doit être validée avec les domaines HTTPS de production.

## Décisions à confirmer

Avant la Tranche C, il faut confirmer le fournisseur de stockage objet pour les photos et notes vocales. Le code actuel conserve le champ `profilePhotoUrl` et `mediaUrl` pour compatibilité, mais aucun upload sécurisé n’est encore considéré comme implémenté. Il faut également confirmer les limites de taille, les formats audio autorisés, la durée maximale des notes vocales et la politique de conservation/suppression.

La matrice détaillée des permissions `MODERATOR`/`SUPER_ADMIN` reste à confirmer ; la tranche conserve uniquement les permissions déjà implicites dans le code de référence.

## Conclusion

La Tranche B réduit les risques P0 liés aux contrôles d’accès admin et au temps réel, sans rendre l’application prête pour la production. Les médias, paiements, anti-abus distribué, validation complète des DTOs, audit, E2E et déploiement HTTPS restent ouverts.
