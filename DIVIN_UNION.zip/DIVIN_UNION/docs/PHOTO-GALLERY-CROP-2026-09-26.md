# Divin’Union — chantier galerie photo et sécurité OAuth

## Galerie photo
- Liste des photos approuvées de l'utilisateur.
- Désignation d'une photo principale.
- Suppression par ID de photo propriétaire.
- Réordonnancement API sécurisé sur les photos appartenant à l'utilisateur.
- Mise à jour de `User.profilePhotoUrl` lorsque la photo principale change.

## Recadrage
- Aperçu local avant envoi.
- Recadrage carré côté navigateur via Canvas.
- Zoom réglable avant l'envoi.
- Le fichier recadré est envoyé comme JPEG.

## OAuth
Le jeton temporaire d'inscription sociale ne passe plus dans l'URL.
Il est placé dans un cookie HTTP-only, court et limité au chemin `/auth`, puis consommé par `POST /auth/oauth/complete`.

Cela évite l'exposition du jeton dans l'historique du navigateur, les logs de proxy ou les en-têtes Referer.

## Tests
Les dépendances Node/pnpm ne sont pas installées dans l'environnement de travail courant. La compilation TypeScript, Prisma et les tests E2E Docker restent à exécuter dans l'environnement projet équipé.
