# Divin'Union — rapport de Tranche A

**Tranche :** sécurité de l’identité  
**Date :** 20 septembre 2026  
**Statut :** implémentée et validée par compilation/tests ; non production

## Ce qui a été implémenté

Le parcours d’inscription exige désormais une vérification OTP consommée pour le même numéro avant la création du compte. Les demandes OTP sont limitées par un cooldown d’une minute, les codes expirent après cinq minutes et les tentatives invalides sont comptées avec un plafond de cinq essais. Le code n’est plus renvoyé en production et le mode de développement conserve uniquement le code de test existant.

Les entrées d’authentification sont maintenant portées par des DTOs `class-validator` stricts : format international du téléphone, code OTP à six chiffres, date valide, âge minimum contrôlé côté service, mot de passe fort, enums métier et propriétés inconnues refusées par le `ValidationPipe` global.

La création de compte et la connexion créent maintenant une session de refresh persistée sous forme de token opaque haché avec Argon2id. La route `/auth/refresh` révoque la session utilisée et émet une nouvelle session, ce qui fournit la rotation. La route `/auth/logout` révoque la session courante. Le refresh token est placé dans un cookie HttpOnly, SameSite Strict, avec `secure` activé en production ; l’access token reste retourné dans la réponse afin de préserver le client web actuel.

Le bootstrap refuse en production les secrets essentiels absents ou faibles, interdit le secret JWT de développement, écoute explicitement sur `0.0.0.0` et refuse les propriétés non déclarées dans les payloads HTTP.

La page web d’inscription transmet désormais l’identifiant de vérification OTP reçu et confirmé au endpoint de création de compte. Aucun parcours existant n’a été supprimé et le mot de passe reste compatible comme mécanisme de connexion de secours.

## Fichiers modifiés ou ajoutés

| Fichier | Rôle |
|---|---|
| `apps/api/src/auth/auth.dto.ts` | DTOs stricts pour OTP, inscription et connexion |
| `apps/api/src/auth/auth.service.ts` | Cooldown/limites OTP, inscription liée à OTP, refresh rotatif et révocation |
| `apps/api/src/auth/auth.controller.ts` | Routes typées auth, cookie refresh, refresh et logout |
| `apps/api/src/main.ts` | Validation de configuration et `ValidationPipe` strict |
| `apps/api/src/auth/auth.service.spec.ts` | Tests unitaires OTP et refresh session |
| `apps/api/jest.config.cjs` | Configuration Jest/ts-jest |
| `apps/api/package.json` | Dépendances de test Jest/ts-jest |
| `apps/web/src/app/register/page.tsx` | Transmission de la vérification OTP au backend |
| `apps/api/prisma/schema.prisma` | Schéma remis dans un format Prisma valide ; relation des sessions de refresh explicitée |
| `docs/PREPRODUCTION-AUDIT-2026-09-20.md` | Feuille de route et audit de référence |

Le lockfile pnpm a également été régénéré par l’installation des dépendances de test.

## Migrations effectuées

Aucune migration SQL destructive ou additive n’a été exécutée sur une base, car aucune base PostgreSQL de l’environnement n’a été fournie. Le modèle `RefreshSession` existait déjà dans le schéma de référence ; la Tranche A le raccorde au service sans modification de table. La correction du schéma Prisma est syntaxique et ne change pas les colonnes existantes. Avant déploiement, il faudra exécuter une migration Prisma contrôlée contre l’environnement cible et vérifier que `RefreshSession` existe réellement dans la base.

## Tests exécutés

Les validations suivantes passent :

- `pnpm db:generate` — client Prisma généré avec succès.
- `pnpm build` — compilation NestJS et build Next.js réussis.
- `pnpm test` — 1 suite, 3 tests réussis.
- Les tests couvrent le refus d’inscription sans OTP vérifié, l’incrément du compteur d’échecs OTP et la création d’une session de refresh lors de la connexion.

## Problèmes restant à résoudre

La rotation recherche actuellement les sessions candidates et vérifie les hashes Argon2 en mémoire ; cette stratégie doit être remplacée ou complétée par un identifiant de session public séparé du hash pour éviter un coût qui croît avec le nombre de sessions. La détection de réutilisation d’un refresh token révoqué et la révocation globale par utilisateur doivent encore être ajoutées.

Le fournisseur SMS réel n’est pas branché : il n’existe pas encore d’adapter, de signature de requête, de gestion des erreurs fournisseur ni de limites Redis distribuées. Les limites actuelles sont valables au niveau applicatif et devront être renforcées par IP, numéro, appareil et adresse réseau.

Les DTOs stricts ne couvrent pas encore les contrôleurs profils, messagerie, modération, administration et abonnements. Les droits admin et le WebSocket restent à traiter dans la Tranche B. Les médias, paiements, webhooks, anti-abus avancé, tests E2E, sauvegardes et HTTPS restent non production.

Les tests ne connectent pas encore PostgreSQL et ne valident donc pas les transactions concurrentes, l’atomicité du quota ou le comportement d’une migration réelle.

## Décisions à confirmer

Aucune décision supplémentaire n’est nécessaire pour conserver le mot de passe comme secours compatible dans cette tranche. Restent toutefois à confirmer avant les intégrations suivantes :

1. le fournisseur SMS et le périmètre RDC/international ;
2. le prestataire de paiement et la prise en charge éventuelle du Mobile Money ;
3. le fournisseur de stockage objet et les limites photo/audio ;
4. la matrice exacte des permissions `MODERATOR` et `SUPER_ADMIN`.

## Conclusion

La Tranche A est techniquement intégrée et validée par build/tests, mais elle ne rend pas l’application prête pour la production. Les P0/P1/P2 de l’audit restent ouverts tant que les fournisseurs réels, les contrôles distribués, les médias, les paiements, le temps réel, les tests d’intégration et le déploiement sécurisé ne sont pas traités.


## Mise à jour de conformité après revue stricte

La revue demandée a identifié deux lacunes dans la première version de la tranche et elles ont été corrigées :

- La consommation du challenge OTP se fait désormais par `updateMany` conditionnel dans la transaction Prisma d’inscription, avec `consumedAt: null`, `verifiedAt` non nul, numéro et identifiant concordants. Une seconde inscription avec le même challenge ne peut donc pas consommer à nouveau le challenge.
- Les refresh tokens ont désormais un identifiant de session public aléatoire séparé du secret haché. Le format du cookie est `sessionId.secret`; le lookup ne parcourt plus toutes les sessions. Une rotation révoque atomiquement la session précédente et crée la suivante. La réutilisation d’une session révoquée ou expirée marque `reuseDetectedAt`, révoque les sessions encore actives de l’utilisateur et renvoie une erreur d’authentification.
- La normalisation du téléphone est appliquée aussi dans le service, et pas uniquement via `class-transformer`, afin de protéger les appels directs et les futurs adapters.
- La génération OTP utilise une source aléatoire cryptographiquement meilleure que `Math.random` et les codes ne sont journalisés qu’en environnement non production.

## État exact de validation

Les commandes suivantes passent désormais :

- `pnpm db:generate`
- `pnpm test` — 1 suite, **5 tests réussis** : normalisation du téléphone, échec OTP et compteur, consommation atomique, rejet de réutilisation OTP et détection de réutilisation refresh.
- `pnpm build` — API NestJS et web Next.js réussis.

La migration ajoutée est `apps/api/prisma/migrations/20260920_tranche_a_identity/migration.sql`. Elle est additive et nullable : elle ajoute `OtpCode.verifiedAt`, `OtpCode.consumedAt` et `RefreshSession.reuseDetectedAt`. Elle n’a pas été appliquée à une base PostgreSQL dans cet environnement, car aucune base cible n’est disponible. Il reste donc à exécuter `pnpm db:migrate` sur une base de développement réelle et à valider une migration d’intégration avant de considérer cette tranche comme clôturée.

## Verdict honnête

Le code de la Tranche A est implémenté et les tests unitaires passent. La tranche n’est **pas encore déclarée entièrement terminée** au sens des règles de livraison, car il manque encore :

1. un test d’intégration réel avec PostgreSQL pour la transaction OTP, les contraintes utilisateur et la rotation concurrente ;
2. l’application et la vérification de la migration sur une base de développement ;
3. un rate limiting distribué par Redis/IP/appareil ;
4. l’adapter SMS réel, qui reste volontairement non choisi et non simulé comme prêt pour production ;
5. la validation HTTPS/CORS/cookies dans un environnement de déploiement.

Aucune Tranche B ou C ne doit être présentée comme une suite de production tant que ces validations P0/P1 de l’identité ne sont pas réalisées.


## Vérification d’intégration de l’environnement

La configuration `infra/docker-compose.yml` prévoit PostgreSQL 17 et Redis 8, mais Docker/Compose n’est pas installé dans l’environnement courant (`docker: command not found`). Aucun conteneur ni aucune base de données n’ont donc été démarrés, et aucun test d’intégration PostgreSQL ne peut être revendiqué. Cette limitation est conservée explicitement plutôt que masquée par un mock.
