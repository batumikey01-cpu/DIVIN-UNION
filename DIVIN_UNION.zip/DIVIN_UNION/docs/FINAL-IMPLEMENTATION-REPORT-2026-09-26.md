# Divin’Union — rapport d’implémentation finale de la tranche disponible

## Base de travail
Archive source : `divin-union-next-2026-09-26.zip`.

## Modifications appliquées

### P0 sécurité / authentification
- `JwtGuard` recharge désormais l’utilisateur en base et refuse les comptes suspendus/désactivés/supprimés, même avec un ancien JWT.
- Les sessions refresh sont révoquées lors d’une suspension et lors d’un changement de mot de passe.
- Expiration d’un abonnement vérifiée sur les requêtes protégées ; le compte repasse à FREE et la souscription active est marquée EXPIRED.
- Rate limiting persistant PostgreSQL ajouté pour fonctionner en multi-instance.
- Les limites sensibles (OTP, récupération de mot de passe) passent par ce rate limiter par défaut.

### P0 paiement
- Suppression du faux checkout générique.
- Ajout d’un `PaymentProviderRegistry`.
- Ajout d’un adaptateur WonyaPay via HTTP.
- Configuration provider en base : nom, driver, URL, environnement, référence partenaire, caisse, devises, activation.
- Secret provider chiffré AES-256-GCM avec `PAYMENT_CONFIG_ENCRYPTION_KEY`.
- Référence de transaction de 20 caractères.
- Transaction de paiement persistée.
- Vérification de statut fournisseur avant activation d’un paiement callback.
- Contrôles de référence, montant, devise et statut.
- Idempotence par référence de transaction.
- Prix 1/3/6 mois configurables en base et modifiables par super-admin.
- Expiration calendaire réelle par ajout de mois, et non `30 * N` jours.
- Synchronisation manuelle d’une transaction disponible via l’API.

> Le token WonyaPay réel n’est pas embarqué dans l’archive. Il doit être configuré depuis l’admin avec une clé de chiffrement serveur. Un secret précédemment exposé dans la conversation ne doit pas être réutilisé : il doit être régénéré côté fournisseur.

### Messagerie
- Nouveau modèle de conversation : `PRE_MATCH`, `OPEN`, `CLOSED`.
- Introduction contrôlée avant match.
- Une introduction en attente par expéditeur/conversation.
- Le destinataire peut répondre ; la conversation passe alors à `OPEN`.
- Un match réciproque ouvre également la conversation.
- Une conversation ouverte reste protégée par blocage/autorisation côté serveur.
- Le bouton d’introduction est ajouté à la découverte.
- Les coordonnées des utilisateurs FREE sont masquées dans le texte au lieu de bloquer arbitrairement tout le message.
- Upload sécurisé de média de messagerie (image/audio), stockage serveur, validation de type/magic bytes/taille et contrôle de propriété.
- Les médias de conversation sont accessibles uniquement aux participants.

### Profils / découverte
- Une photo approuvée est requise avant l’accès à la découverte.
- Les profils inactifs, supprimés, bloqués et invisibles sont exclus.
- Le mode voyage existant est utilisé pour la localisation de découverte.
- Pagination côté résultat limitée à 50 après filtrage serveur.
- Boost Premium ajouté avec durée contrôlée.
- Endpoint Premium `who-liked-me` ajouté.
- Page `/profile/[id]` ne dépend plus de `landingProfiles` ; elle récupère un vrai profil backend.
- Endpoint public de profil réel ajouté, avec exposition limitée des données.

### Authentification
- Récupération de mot de passe complète : token aléatoire, hash SHA-256, expiration 30 min, usage unique, invalidation des sessions, message générique et rate limit.
- Nouveau fournisseur email transactionnel pour le reset.
- Nouveau code OTP invalide les anciens codes.
- Microsoft OAuth renforce les contrôles issuer/tenant/expiration/nbf, en conservant state/nonce/PKCE existants.

### Notifications
- Centre de notifications persistant en base.
- Lecture/unread et lecture globale.
- Match, message, paiement et sécurité produisent maintenant des notifications persistées.
- Architecture prête pour un provider email/push futur sans exposer les contenus privés dans les logs.

### Administration
- Suspension/réactivation utilisateur.
- Révocation des refresh sessions lors d’une suspension.
- Tarification administrable.
- Fournisseurs de paiement administrables sans exposer le secret chiffré.
- Consultation des paiements et abonnements.
- Statistiques complétées avec paiements en attente.
- Audit log conservé sur les actions sensibles.

### UX
- Gate chrétien ajouté à l’ouverture de l’application.
- Parcours récupération de mot de passe ajouté.
- Interface admin minimale pour tarifs et fournisseurs de paiement.
- Upload image/audio intégré à la messagerie.

## Validation réalisée dans cet environnement

### PASS
- `scripts/quality-check.mjs` : PASS.
- Résultat : 62 fichiers API / 34 fichiers Web.

### BLOCKED
Les tests runtime complets n’ont pas pu être exécutés dans cet environnement car :
- `pnpm` n’est pas installé ;
- les dépendances `node_modules` ne sont pas présentes ;
- Docker/PostgreSQL ne sont pas disponibles ici ;
- aucun accès réseau npm fiable n’est disponible pour installer les dépendances ;
- l’appel réel WonyaPay ne peut pas être effectué sans configuration de test autorisée et sans secret fournisseur.

Par conséquent, aucun résultat `PASS` n’est revendiqué pour les tests Jest/E2E/runtime ou pour un paiement WonyaPay réel.

## Points nécessitant encore un environnement d’exécution

1. Générer Prisma Client.
2. Appliquer les migrations.
3. Lancer PostgreSQL.
4. Installer les dépendances avec pnpm.
5. Lancer Jest et corriger toute régression de compilation/runtime restante.
6. Lancer le frontend et le backend ensemble.
7. Exécuter le parcours E2E A/B/admin.
8. Configurer un provider email réel.
9. Configurer le stockage production.
10. Configurer WonyaPay sandbox avec un compte/caisse autorisé.
11. Vérifier le callback HTTPS public et le statut WonyaPay réel.
12. Vérifier mobile/tablette/desktop sur navigateur réel.

## Sécurité

Aucun token WonyaPay réel n’est stocké dans le dépôt. Les secrets provider sont chiffrés en base et la clé maître doit rester dans l’environnement serveur.

Les comptes suspendus/supprimés ne peuvent plus continuer à appeler les API protégées avec un ancien JWT.

## Conclusion

Toutes les corrections qui pouvaient être implémentées et vérifiées statiquement dans l’environnement de travail ont été appliquées sur la dernière archive de référence. Les validations dépendant d’un runtime complet, d’une base PostgreSQL, de Docker, de fournisseurs externes ou de secrets réels restent explicitement `BLOCKED` et ne sont pas présentées comme réussies.

## QA runtime/static follow-up — 2026-09-26

Une passe QA supplémentaire a identifié et corrigé plusieurs défauts qui n'étaient pas couverts par le contrôle structurel initial :

- **P1 — Gate chrétien / UX inscription** : le gate était monté globalement et le clic « Oui » ne garantissait pas une transition de route explicite. Le gate est maintenant limité aux parcours d'inscription et déclenche explicitement une transition vers `/register?christian=1`.
- **P1 — Médias protégés** : plusieurs interfaces utilisaient directement `/media/assets/...` dans des balises `<img>`/`<audio>` sans transmettre le JWT. Les profils découverte, le gestionnaire de photos, le chat et la modération admin utilisent maintenant un composant de chargement média authentifié.
- **P0/P1 — MediaController** : l'endpoint `GET /media/assets/:id` utilisait `request.user` sans injecter `@Req() request`. Corrigé.
- **P1 — MessagingService** : `maskCoordinates()` était appelé mais absent de la classe. Corrigé avec un masquage explicite des numéros, réseaux sociaux et URLs.
- **P1 — MessagingService** : le filtrage de coordonnées pouvait s'appliquer aussi aux utilisateurs Premium. Corrigé : le masquage est limité au plan FREE.
- **P1 — AdminController** : collision de nom entre l'injection `payments` et la méthode `payments()`, détectée par TypeScript. Corrigée en `paymentRegistry`.
- **P1 — Discovery** : deux sources de découverte concurrentes provoquaient un doublon d'interface et deux chargements backend. La page utilise maintenant une seule source `SwipeDeck`, avec photo, profil, like/pass, introduction et modération intégrés.
- **P1 — Administration frontend** : ajout d'un tableau de bord `/admin` avec statistiques, recherche utilisateurs, suspension/réactivation et traitement des signalements, plus accès aux modules médias, tarifs et paiements.

### Validation effectuée après cette passe

- `node scripts/quality-check.mjs` : **PASS — 62 fichiers API, 39 fichiers Web**.
- Vérification TypeScript globale tentée avec le compilateur disponible : **BLOCKED** par l'absence des dépendances du workspace (`node_modules`, `@nestjs/*`, `@prisma/client`, types Node/Jest, etc.). Cette commande a néanmoins permis de détecter la collision `payments` et l'appel manquant `maskCoordinates`, corrigés ensuite.
- Tests Jest/runtime/E2E : **BLOCKED** tant que les dépendances, PostgreSQL et les services externes ne sont pas disponibles.
