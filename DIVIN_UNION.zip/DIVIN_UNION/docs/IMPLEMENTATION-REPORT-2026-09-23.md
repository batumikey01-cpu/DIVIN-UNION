# Rapport d’intégration et d’autocritique — Divin’Union

**Date :** 23 septembre 2026

## Résultat

Une tranche de durcissement locale a été appliquée au projet. Les validations disponibles dans le sandbox sont positives : le schéma Prisma est valide, l’API compile, les tests API passent, le Web compile et l’audit des dépendances de production ne signale plus de vulnérabilité.

## Corrections appliquées

Le bootstrap NestJS conserve `helmet`, les cookies, la validation globale stricte et les contrôles de secrets. Le CORS accepte `WEB_ORIGIN` ou `CLIENT_URL` sous forme de liste explicite et refuse les origines inconnues. En production, le démarrage refuse désormais les fournisseurs `mock` ou `local`, ainsi qu’un secret de webhook absent ou trop court.

Les contrôleurs de messagerie, de checkout et de profil utilisent des DTOs class-validator explicites. Les messages imposent un type, une taille maximale et une URL HTTPS pour les médias transmis. Ces contrôles de payload ne remplacent pas encore un véritable pipeline de stockage et de modération des fichiers.

La recherche de conversation est maintenant strictement bipartite : les deux utilisateurs doivent être membres et aucun tiers ne peut être présent. Cela corrige le risque de fuite d’historique identifié dans l’audit.

La consommation OTP est conditionnelle et atomique via `updateMany`, avec vérification de `usedAt`, de l’expiration et du nombre maximal de tentatives. Deux vérifications concurrentes ne peuvent donc pas toutes deux consommer le même code au niveau de cette opération.

Le service d’abonnements crée une référence de checkout persistée en `PENDING`. Le webhook vérifie une signature HMAC SHA-256, traite les événements de manière idempotente et active le plan dans une transaction Prisma. Il ne s’agit pas encore d’un adaptateur Stripe, Mobile Money ou autre fournisseur réel : le choix du prestataire reste une décision produit nécessaire.

Le healthcheck vérifie maintenant PostgreSQL avec `SELECT 1` et renvoie `503` lorsque la base est indisponible. Les overrides pnpm forcent `postcss`, `deepmerge-ts` et `multer` vers des versions corrigées.

## Tests finaux réussis

Les commandes suivantes ont été exécutées avec succès :

```bash
DATABASE_URL='postgresql://divinunion:divinunion@127.0.0.1:5432/divinunion?schema=public' \
  pnpm --filter @divinunion/api exec prisma validate
pnpm --filter @divinunion/api prisma:generate
pnpm --filter @divinunion/api build
pnpm --filter @divinunion/api exec jest --runInBand
pnpm --filter @divinunion/web build
pnpm audit --prod --json
```

Résultats : **8 suites réussies, 31 tests réussis**, builds API et Web réussis, validation Prisma réussie et **0 vulnérabilité** signalée par l’audit de production (`0 high`, `0 moderate`, `0 low`, `0 critical`).

Les tests ajoutés couvrent l’isolation des conversations contenant un tiers, la consommation OTP concurrente, la création de checkout en attente, le rejet des signatures invalides et l’idempotence du webhook signé.

## Autocritique et limites restantes

La correction de typage du service de messagerie a d’abord introduit une erreur de compilation dans le gateway ; la validation finale l’a détectée et une boucle supplémentaire a corrigé cette régression. Le résultat final a ensuite été recompilé et testé avec succès.

La couverture reste principalement unitaire et mockée. Docker n’est pas installé dans le sandbox, aucun PostgreSQL ou Redis réel n’a donc été démarré, et `prisma migrate status` n’a pas pu valider une base vivante. Les fournisseurs SMS, paiement et stockage réels ne sont pas choisis ni connectés. Les limites distribuées Redis, les uploads contrôlés, les antivirus, la CSP frontend, les journaux d’audit administratifs et les tests de charge restent des travaux de staging/architecture qui ne peuvent pas être validés honnêtement dans cet environnement sans décisions et services externes.

En conséquence, le projet est **techniquement plus robuste et validé localement**, mais ce rapport ne le déclare pas prêt pour une mise en production publique tant que les limites externes et les tests d’intégration réels ne sont pas traités.
