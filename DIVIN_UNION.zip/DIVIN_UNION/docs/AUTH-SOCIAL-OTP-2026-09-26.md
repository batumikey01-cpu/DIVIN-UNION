# Divin’Union — chantier Authentification sociale + OTP

## Ordre produit

1. Google — connexion/création de compte principale
2. Apple — connexion/création de compte principale
3. Microsoft — connexion/création de compte principale
4. Email + mot de passe — option secondaire
5. OTP email — vérification de l’email pour le parcours secondaire
6. OTP SMS — conservé comme fournisseur optionnel pour une future vérification téléphonique

## Architecture

- OAuth/OIDC est géré côté API.
- Chaque tentative OAuth possède un `state`, un `nonce`, un PKCE `code_verifier` et une expiration.
- Les états OAuth sont stockés en base et consommés une seule fois.
- Les comptes sociaux sont liés dans `SocialAccount` avec une contrainte unique `(provider, providerAccountId)`.
- Un nouveau compte social passe par une session courte `SocialSignupSession` avant la création définitive du profil.
- Aucun secret OAuth n'est stocké dans le code ou le frontend.
- Apple utilise un client secret JWT signé avec la clé privée fournie par Apple.
- Les JWT OIDC reçus sont vérifiés avec les clés publiques JWKS du fournisseur lorsqu'un `id_token` est présent.
- Le refresh token reste en cookie HTTP-only; il n'est pas envoyé dans l'URL.

## Fournisseurs OTP

- `SMS_PROVIDER`: fournisseur SMS existant, conservé pour une utilisation future.
- `EMAIL_OTP_PROVIDER`: `mock` en développement ou `http` pour un fournisseur email réel.
- Les codes OTP sont hashés en base, valables 10 minutes et limités à 5 tentatives.
- Les demandes email sont limitées à 3 par heure et protégées par un délai de renvoi.

## Variables à configurer

`GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `MICROSOFT_CLIENT_ID`, `MICROSOFT_CLIENT_SECRET`, `APPLE_CLIENT_ID`, `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_PRIVATE_KEY`, `API_PUBLIC_URL` et, en production, `EMAIL_OTP_PROVIDER=http`, `EMAIL_OTP_HTTP_URL`, `EMAIL_OTP_HTTP_SECRET`.

Les secrets ne doivent jamais être commités dans Git, placés dans le ZIP, affichés au frontend ou écrits dans les logs.

## Vérification restante

Le code doit être validé après installation des dépendances et génération Prisma, puis testé en environnement Docker avec de vraies configurations OAuth de test. Cette étape n'est pas déclarée comme réussie tant que ces tests n'ont pas été exécutés.
