# Architecture
Next.js -> NestJS REST + Socket.IO -> PostgreSQL/Prisma. Redis est prévu pour rate limiting, présence et jobs distribués. Médias via stockage objet privé. Matching V1 déterministe; score de compatibilité extensible.
