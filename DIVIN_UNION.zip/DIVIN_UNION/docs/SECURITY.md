# Sécurité — pré-production
Le code est une base MVP. Avant production: rate limiting Redis, validation DTO explicite, refresh token rotatif, stockage objet privé + URLs signées, fournisseur SMS réel, webhooks de paiement signés, auth WebSocket, tests E2E, logs/audit, sauvegardes chiffrées et HTTPS.
