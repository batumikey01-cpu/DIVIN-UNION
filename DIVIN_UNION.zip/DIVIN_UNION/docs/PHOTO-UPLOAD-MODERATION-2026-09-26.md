# Chantier photos — 2026-09-26

## Objectif
Remplacer la saisie d'URL de photo par un vrai upload de fichier, avec validation serveur, stockage, état de modération et approbation administrateur.

## Réalisé
- Upload multipart `POST /media/photos` pour JPEG/PNG/WebP.
- Limite 10 Mo.
- Vérification du type MIME et de la signature binaire (magic bytes).
- Vérification des dimensions (200 à 6000 px).
- SHA-256 du fichier enregistré.
- Clé de stockage aléatoire par utilisateur.
- Stockage local configurable par `MEDIA_STORAGE_DIR` en développement/staging.
- `MediaAsset` passe par `PENDING` avant visibilité.
- Approbation/rejet par MODERATOR/SUPER_ADMIN.
- Audit des décisions de modération.
- Photo approuvée reliée à `Photo` et devient la `profilePhotoUrl` principale.
- Suppression réservée au propriétaire.
- Endpoint de lecture protégé par JWT.
- Interface d'inscription sans champ URL : sélection d'un fichier + aperçu.
- Interface admin `/admin/media` pour les photos en attente.
- Conservation d'un chemin `InMemoryStorageProvider` pour les tests.

## Important
Le stockage local est un provider de développement/staging. Pour la production multi-instance, il faudra brancher un provider objet durable (S3-compatible ou équivalent) via la même interface `StorageProvider`.

Le recadrage interactif avancé reste à finaliser ; l'inscription affiche actuellement un aperçu avant envoi. Le serveur reste la source de vérité pour la validation du fichier.

## Validation environnement
Les dépendances Node du ZIP ne sont pas installées dans l'environnement actuel et Docker n'est pas disponible ici. Les tests TypeScript/Jest et la migration Prisma doivent donc être exécutés dans l'environnement Docker/staging du projet avant validation finale.
