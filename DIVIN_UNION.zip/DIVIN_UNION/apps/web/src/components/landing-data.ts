export type LandingProfile = { id: string; name: string; age: number; city: string; role: string; image: string; quote: string };

const homeImage = (name: string) => `/home-images/${name}.png`;

export const landingProfiles: LandingProfile[] = [
  { id: 'sarah', name: 'Sarah', age: 29, city: 'Kinshasa', role: 'Responsable de communauté', image: homeImage('1000859392'), quote: 'Je cherche une relation sincère, fondée sur la foi et la complicité.' },
  { id: 'daniel', name: 'Daniel', age: 31, city: 'Lubumbashi', role: 'Entrepreneur', image: homeImage('1000859581'), quote: 'Construire à deux, avec patience, humour et une vraie vision commune.' },
  { id: 'esther', name: 'Esther', age: 27, city: 'Goma', role: 'Enseignante', image: homeImage('1000859401'), quote: 'Une belle rencontre commence par une conversation authentique.' },
  { id: 'samuel', name: 'Samuel', age: 30, city: 'Kisangani', role: 'Ingénieur', image: homeImage('1000859402'), quote: 'La foi donne du sens au chemin que nous choisissons de parcourir ensemble.' },
];

export const landingTestimonials = [
  { name: 'Cédric & Marie', city: 'Kinshasa', image: homeImage('1000859399'), text: 'Nous nous sommes parlé pendant deux semaines avant de nous rencontrer. Aujourd’hui, nous préparons notre mariage avec beaucoup de gratitude.' },
  { name: 'Sarah & Daniel', city: 'Lubumbashi', image: homeImage('1000859389'), text: 'Nous avions la même foi, les mêmes valeurs et cette envie de construire quelque chose de sérieux. Divin’Union nous a permis de nous rencontrer.' },
  { name: 'David & Alice', city: 'Kinshasa', image: homeImage('1000859399'), text: 'Une rencontre simple, respectueuse et pleine d’espérance. Nous recommandons cette communauté à tous ceux qui cherchent du sérieux.' },
];

export const heroImage = homeImage('1000859389');
