'use client';

import { useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

type Props = {
  src: string;
  alt?: string;
  kind?: 'image' | 'audio';
  className?: string;
  style?: React.CSSProperties;
  controls?: boolean;
};

export function AuthenticatedMedia({ src, alt = '', kind = 'image', className, style, controls }: Props) {
  const [objectUrl, setObjectUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let active = true;
    let createdUrl: string | null = null;
    setObjectUrl(null);
    setFailed(false);

    const token = window.sessionStorage.getItem('du_token');
    if (!token || !src) {
      setFailed(true);
      return () => undefined;
    }

    const url = src.startsWith('http') ? src : `${API}${src}`;
    fetch(url, { headers: { Authorization: `Bearer ${token}` }, credentials: 'include' })
      .then(async (response) => {
        if (!response.ok) throw new Error('Média inaccessible.');
        return response.blob();
      })
      .then((blob) => {
        if (!active) return;
        createdUrl = URL.createObjectURL(blob);
        setObjectUrl(createdUrl);
      })
      .catch(() => {
        if (active) setFailed(true);
      });

    return () => {
      active = false;
      if (createdUrl) URL.revokeObjectURL(createdUrl);
    };
  }, [src]);

  if (failed) return <span className="muted" role="img" aria-label={alt}>Média indisponible</span>;
  if (!objectUrl) return <span className="muted" aria-hidden="true">Chargement…</span>;
  if (kind === 'audio') return <audio controls={controls ?? true} src={objectUrl} className={className} style={style} />;
  return <img src={objectUrl} alt={alt} className={className} style={style} />;
}
