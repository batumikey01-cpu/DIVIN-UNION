'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChatWindow } from './chat-window';
import { ModerationActions } from './moderation-actions';

function readSubject(token: string) {
  try {
    const payload = token.split('.')[1];
    const decoded = JSON.parse(window.atob(payload.replace(/-/g, '+').replace(/_/g, '/')));
    return typeof decoded.sub === 'string' ? decoded.sub : null;
  } catch {
    return null;
  }
}

export function ChatPageClient({ partnerId }: { partnerId: string }) {
  const router = useRouter();
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const token = window.sessionStorage.getItem('du_token');
    const subject = token ? readSubject(token) : null;
    if (!token || !subject) {
      router.replace('/login');
      return;
    }
    setToken(token);
    setCurrentUserId(subject);
  }, [router]);

  if (!currentUserId || !token) return <main className="container"><p className="muted">Ouverture de la conversation…</p></main>;

  return (
    <main className="container chat-page">
      <div className="chat-page-header">
        <h1>Messagerie Divin’Union</h1>
        <ModerationActions targetId={partnerId} token={token} onBlockedSuccess={() => router.replace('/discover')} />
      </div>
      <ChatWindow currentUserId={currentUserId} partnerId={partnerId} />
    </main>
  );
}
