'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { fetchDiscoveryProfiles, ProfileCardDto, submitSwipe, sendIntroduction } from '../lib/matching-api';
import { ModerationActions } from './moderation-actions';
import { AuthenticatedMedia } from './authenticated-media';

interface SwipeDeckProps { token: string; }

export function SwipeDeck({ token }: SwipeDeckProps) {
  const [profiles, setProfiles] = useState<ProfileCardDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [intro, setIntro] = useState('');
  const [introOpen, setIntroOpen] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true); setError(null);
    fetchDiscoveryProfiles(token)
      .then((data) => { if (active) setProfiles(data); })
      .catch((cause) => { if (active) setError(cause instanceof Error ? cause.message : 'Erreur chargement profils.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [token]);

  async function handleAction(action: 'LIKE' | 'PASS') {
    const current = profiles[0];
    if (!current || submitting) return;
    setSubmitting(true); setError(null); setMessage('');
    try {
      const result = await submitSwipe(current.id, action, token);
      setProfiles((previous) => previous.slice(1));
      setMessage(result.matched ? 'Match ! Vous pouvez maintenant discuter.' : action === 'LIKE' ? 'Intérêt enregistré.' : 'Profil passé.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Erreur lors de l’action.');
    } finally { setSubmitting(false); }
  }

  if (loading) return <div className="swipe-state muted">Chargement des profils…</div>;
  if (error) return <div className="swipe-state swipe-error" role="alert">{error}</div>;
  if (profiles.length === 0) return <div className="swipe-state muted">Plus aucun profil à découvrir pour le moment.</div>;

  const current = profiles[0];
  async function submitIntro() {
    if (!intro.trim() || !token) return;
    setSubmitting(true); setError(null); setMessage('');
    try {
      await sendIntroduction(current.id, intro, token);
      setIntro(''); setIntroOpen(false); setProfiles((p) => p.slice(1));
      setMessage('Introduction envoyée.');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Erreur.');
    } finally { setSubmitting(false); }
  }

  return (
    <>
      {message && <p role="status">{message}</p>}
      <section className="swipe-deck" aria-label="Découverte rapide">
        <div className="swipe-card card">
          <div style={{ display: 'grid', gap: 16 }}>
            {current.photoUrl && <AuthenticatedMedia src={current.photoUrl} alt={`Photo de ${current.name || 'ce profil'}`} style={{ width: '100%', maxHeight: 480, objectFit: 'cover', borderRadius: 18 }} />}
            <div className="swipe-card-heading"><h2>{current.name || 'Profil'}</h2>{current.age && <span className="muted">{current.age} ans</span>}</div>
            {(current.city || current.country) && <p className="muted">{current.city}{current.city && current.country ? ', ' : ''}{current.country}</p>}
            <p>{current.bio || 'Aucune biographie renseignée.'}</p>
            <Link className="btn" href={`/profile/${current.id}`}>Voir le profil</Link>
            <ModerationActions targetId={current.id} token={token} onBlockedSuccess={() => setProfiles((previous) => previous.slice(1))} />
            <div className="swipe-actions">
              <button type="button" onClick={() => void handleAction('PASS')} disabled={submitting} className="btn swipe-pass">Passer</button>
              <button type="button" onClick={() => void handleAction('LIKE')} disabled={submitting} className="btn swipe-like">J’aime</button>
              <button type="button" onClick={() => setIntroOpen(true)} disabled={submitting} className="btn">Envoyer une introduction</button>
            </div>
          </div>
        </div>
      </section>
      {introOpen && <div role="dialog" aria-modal="true" className="card" style={{ marginTop: 12 }}><h3>Votre introduction</h3><p className="muted">Un seul message avant réponse. La personne garde le contrôle.</p><textarea value={intro} onChange={e => setIntro(e.target.value)} maxLength={2000} rows={4} placeholder="Bonjour…" style={{ width: '100%' }} /><div style={{ display: 'flex', gap: 8, marginTop: 8 }}><button type="button" className="btn" onClick={() => setIntroOpen(false)}>Annuler</button><button type="button" className="btn primary" disabled={!intro.trim() || submitting} onClick={() => void submitIntro()}>Envoyer</button></div></div>}
    </>
  );
}
