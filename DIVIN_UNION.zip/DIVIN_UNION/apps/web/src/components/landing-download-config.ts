export type DownloadPlatform = 'android' | 'ios';

function configuredUrl(...values: Array<string | undefined>) {
  const value = values.find((candidate) => candidate?.trim());
  return value?.trim() || null;
}

export const landingDownloadConfig: Record<DownloadPlatform, { label: string; url: string | null }> = {
  android: {
    label: 'Android',
    url: configuredUrl(process.env.NEXT_PUBLIC_ANDROID_DOWNLOAD_URL, process.env.ANDROID_DOWNLOAD_URL),
  },
  ios: {
    label: 'iOS / iPhone',
    url: configuredUrl(process.env.NEXT_PUBLIC_IOS_DOWNLOAD_URL, process.env.IOS_DOWNLOAD_URL),
  },
};
