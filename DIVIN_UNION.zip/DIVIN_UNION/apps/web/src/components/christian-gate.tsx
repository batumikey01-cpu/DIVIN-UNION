'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

const GATE_KEY = 'du_christian_gate';

export function ChristianGate() {
  const router = useRouter();
  const pathname = usePathname();
  const [answer, setAnswer] = useState<boolean | null>(null);
  const [ready, setReady] = useState(false);
  const [approvedByClick, setApprovedByClick] = useState(false);

  useEffect(() => {
    try {
      const value = sessionStorage.getItem(GATE_KEY);
      setAnswer(value === 'yes' ? true : value === 'no' ? false : null);
    } catch {
      setAnswer(null);
      setApprovedByClick(false);
    } finally {
      setReady(true);
    }
  }, []);

  function acceptChristianGate() {
    try {
      sessionStorage.setItem(GATE_KEY, 'yes');
    } catch {
      // The route navigation below still gives the user access when storage is unavailable.
    }

    // Always perform an explicit route transition so the click cannot leave the user
    // visually stuck behind the global gate. The registration page remains the same
    // page, but the query parameter makes the transition observable by Next.js.
    router.replace(`${pathname}?christian=1`);
    setAnswer(true);
    setApprovedByClick(true);
  }

  function rejectChristianGate() {
    try {
      sessionStorage.setItem(GATE_KEY, 'no');
    } catch {
      // Keep the rejection visible for the current render even if storage is unavailable.
    }
    setAnswer(false);
  }

  function resetChristianGate() {
    try {
      sessionStorage.removeItem(GATE_KEY);
    } catch {
      // The state reset below is enough for the current page.
    }
    setAnswer(null);
  }

  const isSignupRoute = pathname === '/register' || pathname.startsWith('/register/');
  // Registration must always have an explicit, current consent decision.
  // A previous sessionStorage answer alone must never silently bypass the gate.
  if (!isSignupRoute || !ready || approvedByClick) return null;

  if (answer === false) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#001d3d] p-6 text-white">
        <div className="max-w-md text-center">
          <h2 className="text-3xl font-bold">Divin’Union est réservé aux chrétiens</h2>
          <p className="mt-4 text-white/80">
            L’accès est réservé aux personnes qui déclarent être chrétiennes.
          </p>
          <button
            type="button"
            className="mt-6 rounded-full bg-white px-6 py-3 font-bold text-[#001d3d]"
            onClick={resetChristianGate}
          >
            Modifier ma réponse
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#001d3d]/95 p-6 text-white">
      <div className="max-w-md rounded-3xl bg-white p-8 text-center text-[#001d3d]">
        <h2 className="text-3xl font-bold">Tu es chrétien ?</h2>
        <p className="mt-3 text-slate-600">
          Divin’Union est une plateforme de rencontres chrétiennes.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <button
            type="button"
            className="rounded-full bg-[#001d3d] px-7 py-3 font-bold text-white"
            onClick={acceptChristianGate}
          >
            Oui
          </button>
          <button
            type="button"
            className="rounded-full border px-7 py-3 font-bold"
            onClick={rejectChristianGate}
          >
            Non
          </button>
        </div>
      </div>
    </div>
  );
}
