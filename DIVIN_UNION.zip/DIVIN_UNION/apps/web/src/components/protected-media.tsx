'use client';

import { AuthenticatedMedia } from './authenticated-media';

export function ProtectedMedia({ src, type, alt }: { src: string; type: 'IMAGE' | 'AUDIO'; alt?: string }) {
  return <AuthenticatedMedia src={`/media/assets/${src}`} kind={type === 'AUDIO' ? 'audio' : 'image'} alt={alt} style={type === 'IMAGE' ? { maxWidth: '280px', borderRadius: 12 } : undefined} />;
}
