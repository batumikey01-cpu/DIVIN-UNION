import { landingDownloadConfig, type DownloadPlatform } from './landing-download-config';

function DownloadIcon({ platform }: { platform: DownloadPlatform }) {
  return <svg aria-hidden="true" className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><rect x="6.5" y="2.8" width="11" height="18.4" rx="2.2" /><path d={platform === 'android' ? 'M12 7v6m0 0 2.4-2.4M12 13 9.6 10.6' : 'M9.5 5.5h5M10 18.5h4'} strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function DownloadAction({ platform }: { platform: DownloadPlatform }) {
  const config = landingDownloadConfig[platform];
  const label = platform === 'android' ? 'Télécharger sur Android' : 'Télécharger sur iOS';
  if (config.url) {
    return <a href={config.url} target="_blank" rel="noreferrer" className="download-action inline-flex items-center justify-center gap-3 rounded-full bg-[#18366f] px-5 py-3 text-sm font-bold text-white shadow-[0_10px_22px_rgba(24,54,111,.16)] transition hover:-translate-y-0.5 hover:bg-[#102654]"><DownloadIcon platform={platform} /><span>{label}</span><span aria-hidden="true" className="text-base">↗</span></a>;
  }
  return <div className="download-action download-action-disabled inline-flex items-center justify-center gap-3 rounded-full border border-[#d7dfe6] bg-white px-5 py-3 text-sm font-bold text-[#586579]" aria-label={`${config.label}, lien officiel à configurer`}><DownloadIcon platform={platform} /><span>{config.label}</span><span className="text-[10px] font-semibold uppercase tracking-[.08em] text-[#9aa3ad]">Bientôt</span></div>;
}

export function LandingDownloadSection() {
  return <section id="download" className="bg-[#f7f4ed] px-5 py-14 sm:px-8 lg:px-10 lg:py-20"><div className="mx-auto grid max-w-7xl items-center gap-8 rounded-[1.75rem] border border-[#e6dcc9] bg-[#fffdf9] px-6 py-8 shadow-[0_16px_36px_rgba(23,35,61,.06)] sm:px-10 md:grid-cols-[1fr_auto] md:gap-12 md:px-12 md:py-10"><div><p className="text-[11px] font-bold uppercase tracking-[.18em] text-[#a17a35]">Votre prochaine étape</p><h2 className="mt-2 max-w-xl font-serif text-[clamp(1.9rem,3vw,2.8rem)] font-bold leading-[1.04] tracking-[-.04em] text-[#17233d]">Téléchargez l’application Divin’Union</h2><p className="mt-3 max-w-xl text-sm leading-6 text-[#6b7280]">Gardez vos échanges et vos rencontres à portée de main. Les liens officiels Android et iOS pourront être activés dès que les fichiers de distribution seront disponibles.</p></div><div className="flex flex-col gap-3 sm:flex-row md:flex-col lg:flex-row"><DownloadAction platform="android" /><DownloadAction platform="ios" /></div></div></section>;
}
