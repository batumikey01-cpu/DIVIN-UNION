'use client';

import { FormEvent, useState } from 'react';
import { blockUser, reportUser } from '../lib/moderation-api';

const REPORT_REASONS = [
  ['FAKE_PROFILE', 'Faux profil'],
  ['HARASSMENT', 'Harcèlement'],
  ['MONEY_REQUEST', 'Demande d’argent'],
  ['SEXUAL_CONTENT', 'Contenu sexuel'],
  ['SCAM', 'Arnaque'],
  ['IMPERSONATION', 'Usurpation d’identité'],
  ['MARRIED_OFF_PLATFORM', 'Situation matrimoniale problématique'],
  ['ABUSE', 'Abus'],
  ['OTHER', 'Autre'],
] as const;

interface ModerationActionsProps {
  targetId: string;
  token: string;
  onBlockedSuccess?: () => void;
}

export function ModerationActions({ targetId, token, onBlockedSuccess }: ModerationActionsProps) {
  const [showReportModal, setShowReportModal] = useState(false);
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  async function handleReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!reason) return;
    setLoading(true); setFeedback(null);
    try {
      await reportUser(targetId, reason, token);
      setFeedback('Signalement envoyé avec succès.'); setReason(''); setShowReportModal(false);
    } catch (error) { setFeedback(error instanceof Error ? error.message : 'Erreur lors du signalement.'); }
    finally { setLoading(false); }
  }

  async function handleBlock() {
    if (!window.confirm('Êtes-vous sûr de vouloir bloquer cet utilisateur ?')) return;
    setLoading(true); setFeedback(null);
    try { await blockUser(targetId, token); setFeedback('Utilisateur bloqué.'); onBlockedSuccess?.(); }
    catch (error) { setFeedback(error instanceof Error ? error.message : 'Erreur lors du blocage.'); }
    finally { setLoading(false); }
  }

  return (
    <div className="moderation-actions">
      <div className="moderation-actions-row">
        <button type="button" onClick={() => setShowReportModal(true)} disabled={loading} className="moderation-report">Signaler</button>
        <span className="muted">|</span>
        <button type="button" onClick={handleBlock} disabled={loading} className="moderation-block">Bloquer</button>
      </div>
      {feedback && <p className="moderation-feedback" role="status">{feedback}</p>}
      {showReportModal && (
        <div className="moderation-backdrop" role="presentation">
          <div className="moderation-modal" role="dialog" aria-modal="true" aria-labelledby="report-title">
            <h3 id="report-title">Signaler l’utilisateur</h3>
            <form onSubmit={handleReport}>
              <label htmlFor={`report-reason-${targetId}`}>Motif</label>
              <select id={`report-reason-${targetId}`} value={reason} onChange={(event) => setReason(event.target.value)} required>
                <option value="">Sélectionner un motif</option>
                {REPORT_REASONS.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
              </select>
              <div className="moderation-modal-actions">
                <button type="button" onClick={() => setShowReportModal(false)} className="btn">Annuler</button>
                <button type="submit" disabled={loading || !reason} className="btn primary">Envoyer</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
