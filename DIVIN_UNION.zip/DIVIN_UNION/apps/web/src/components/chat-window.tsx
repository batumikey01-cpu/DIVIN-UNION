'use client';

import { FormEvent, useState } from 'react';
import { useChat } from '../hooks/useChat';
import { ProtectedMedia } from './protected-media';

interface ChatWindowProps {
  currentUserId: string;
  partnerId: string;
}

export function ChatWindow({ currentUserId, partnerId }: ChatWindowProps) {
  const { messages, sendMessage, sendMedia, error } = useChat(currentUserId, partnerId);
  const [mediaError,setMediaError]=useState<string|null>(null);
  const [content, setContent] = useState('');

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (sendMessage(content)) setContent('');
  }

  return (
    <section className="chat-window card" aria-label="Conversation">
      <div className="chat-messages" aria-live="polite">
        {messages.length === 0 && <p className="muted">Aucun message. Commencez à faire connaissance.</p>}
        {messages.map((message) => (
          <article className={`chat-message ${message.senderId === currentUserId ? 'mine' : ''}`} key={message.id}>
            {message.type!=='TEXT'&&message.mediaUrl&&<ProtectedMedia src={message.mediaUrl} type={message.type} alt="Média envoyé" />}
            {message.type==='TEXT'&&<p>{message.content ?? message.body ?? ''}</p>}
            <time dateTime={message.createdAt}>{new Date(message.createdAt).toLocaleString('fr-FR')}</time>
          </article>
        ))}
      </div>
      {error && <p role="alert" className="chat-error">{error}</p>}
      {mediaError&&<p role="alert" className="chat-error">{mediaError}</p>}
      <div className="chat-composer"><label className="btn">Photo/audio<input type="file" accept="image/jpeg,image/png,image/webp,audio/mpeg,audio/wav,audio/ogg" hidden onChange={async e=>{const f=e.target.files?.[0];if(!f)return;setMediaError(null);try{await sendMedia(f);}catch(err){setMediaError(err instanceof Error?err.message:'Upload impossible.');}e.currentTarget.value='';}} /></label></div>
      <form onSubmit={submit} className="chat-composer">
        <input
          value={content}
          onChange={(event) => setContent(event.target.value)}
          placeholder="Écrire un message…"
          aria-label="Message"
          maxLength={2000}
        />
        <button className="btn primary" type="submit" disabled={!content.trim()}>Envoyer</button>
      </form>
    </section>
  );
}
