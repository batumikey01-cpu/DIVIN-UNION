'use client';

import { useEffect, useRef, useState } from 'react';
import { AuthenticatedMedia } from './authenticated-media';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

type Photo = { id: string; url: string; sortOrder: number; createdAt: string; mediaAssetId: string | null };

function token() { return typeof window !== 'undefined' ? sessionStorage.getItem('du_token') || '' : ''; }

function assetPath(photo: Photo) {
  const id = photo.mediaAssetId || photo.url.split('/').pop() || '';
  return `/media/assets/${id}`;
}

export function PhotoManager() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [zoom, setZoom] = useState(1);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  async function load() {
    const r = await fetch(`${API}/media/photos`, { headers: { Authorization: `Bearer ${token()}` }, credentials: 'include' });
    if (r.ok) setPhotos(await r.json());
  }

  useEffect(() => { void load(); }, []);
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  function selectFile(next: File | null) {
    setMessage('');
    if (!next) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(next.type)) return setMessage('Choisissez une image JPEG, PNG ou WebP.');
    if (next.size > 10 * 1024 * 1024) return setMessage('La photo dépasse 10 Mo.');
    if (preview) URL.revokeObjectURL(preview);
    setFile(next); setPreview(URL.createObjectURL(next)); setZoom(1);
  }

  async function crop() {
    if (!file || !preview) throw new Error('Photo absente.');
    const img = new Image();
    img.src = preview;
    await new Promise<void>((resolve, reject) => { img.onload = () => resolve(); img.onerror = () => reject(new Error('Image invalide.')); });
    const side = Math.min(img.naturalWidth, img.naturalHeight) / zoom;
    const sx = (img.naturalWidth - side) / 2;
    const sy = (img.naturalHeight - side) / 2;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = 1200; canvas.height = 1200;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Recadrage indisponible.');
    ctx.drawImage(img, sx, sy, side, side, 0, 0, 1200, 1200);
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.9));
    if (!blob) throw new Error('Impossible de préparer la photo.');
    return new File([blob], 'profile-photo.jpg', { type: 'image/jpeg' });
  }

  async function upload() {
    try {
      setBusy(true); setMessage('');
      const cropped = await crop();
      const fd = new FormData(); fd.append('file', cropped);
      const r = await fetch(`${API}/media/photos`, { method: 'POST', headers: { Authorization: `Bearer ${token()}` }, body: fd, credentials: 'include' });
      const j = await r.json();
      if (!r.ok) throw new Error(j.message || 'Envoi impossible.');
      setMessage('Photo envoyée. Elle sera visible après modération.');
      setFile(null); setPreview(''); setZoom(1); await load();
    } catch (e) { setMessage(e instanceof Error ? e.message : 'Envoi impossible.'); }
    finally { setBusy(false); }
  }

  async function call(path: string, init: RequestInit = {}) {
    const r = await fetch(`${API}${path}`, { ...init, headers: { Authorization: `Bearer ${token()}`, ...(init.headers || {}) }, credentials: 'include' });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.message || 'Action impossible.');
    return j;
  }

  async function primary(id: string) { setBusy(true); try { await call(`/media/photos/${id}/primary`, { method: 'PATCH' }); await load(); } catch (e) { setMessage(e instanceof Error ? e.message : 'Action impossible.'); } finally { setBusy(false); } }
  async function remove(photo: Photo) { if (!window.confirm('Supprimer cette photo ?')) return; setBusy(true); try { await call(`/media/photos/${photo.id}`, { method: 'DELETE' }); await load(); } catch (e) { setMessage(e instanceof Error ? e.message : 'Suppression impossible.'); } finally { setBusy(false); } }

  return <section className="card" style={{ display: 'grid', gap: 18 }}>
    <h1>Mes photos</h1>
    <p className="muted">Ajoutez une photo depuis votre téléphone ou votre ordinateur. Un recadrage carré est préparé avant l’envoi. La photo reste en attente jusqu’à sa modération.</p>
    <input type="file" accept="image/jpeg,image/png,image/webp" onChange={e => selectFile(e.target.files?.[0] || null)} />
    {preview && <div style={{ display: 'grid', gap: 10, maxWidth: 360 }}>
      <img src={preview} alt="Aperçu avant envoi" style={{ width: '100%', aspectRatio: '1', objectFit: 'cover', borderRadius: 16 }} />
      <label>Recadrage / zoom
        <input aria-label="Zoom du recadrage" type="range" min="1" max="3" step="0.05" value={zoom} onChange={e => setZoom(Number(e.target.value))} style={{ width: '100%' }} />
      </label>
      <button className="btn primary" disabled={busy} onClick={() => void upload()}>Envoyer cette photo</button>
    </div>}
    <canvas ref={canvasRef} width={1200} height={1200} hidden />
    {message && <p role="status">{message}</p>}
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))', gap: 12 }}>
      {photos.map((photo, index) => <article key={photo.id} style={{ border: '1px solid #e5e7eb', borderRadius: 16, overflow: 'hidden' }}>
        <AuthenticatedMedia src={assetPath(photo)} alt={`Photo ${index + 1}`} style={{ width: '100%', aspectRatio: '1', objectFit: 'cover' }} />
        <div style={{ padding: 10, display: 'grid', gap: 7 }}>
          <strong>{index === 0 ? 'Photo principale' : `Photo ${index + 1}`}</strong>
          {index !== 0 && <button className="btn" disabled={busy} onClick={() => void primary(photo.id)}>Mettre principale</button>}
          <button className="btn" disabled={busy} onClick={() => void remove(photo)}>Supprimer</button>
        </div>
      </article>)}
    </div>
  </section>;
}
