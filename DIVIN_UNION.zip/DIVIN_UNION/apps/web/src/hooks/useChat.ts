'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { fetchConversationHistory } from '../lib/chat-api';

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId?: string;
  type: 'TEXT' | 'IMAGE' | 'AUDIO';
  body?: string;
  /** Alias pratique pour l’interface texte ; le serveur persiste le champ body. */
  content?: string;
  mediaUrl?: string;
  createdAt: string;
}

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

function normalizeMessage(message: ChatMessage): ChatMessage {
  return { ...message, content: message.content ?? message.body ?? '' };
}

export function useChat(userId: string, receiverId: string, initialConversationId?: string) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversationId, setConversationId] = useState(initialConversationId);
  const [error, setError] = useState<string | null>(null);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    let cancelled = false;
    const storedToken = window.sessionStorage.getItem('du_token');
    if (!storedToken || !userId || !receiverId) {
      setError('Connexion requise pour ouvrir la conversation.');
      return;
    }
    const token = storedToken;

    async function prepareConversation() {
      try {
        let id = initialConversationId;
        if (!id) {
          const response = await fetch(`${API_URL}/messaging/conversations`, {
            method: 'POST',
            headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: receiverId }),
          });
          if (!response.ok) throw new Error('Impossible d’ouvrir la conversation.');
          const conversation = await response.json();
          id = conversation.id;
        }
        if (!id || cancelled) return;
        const conversationId = id;
        setConversationId(conversationId);

        const previous = await fetchConversationHistory(receiverId, token, API_URL);
        if (!cancelled) setMessages(previous.map(normalizeMessage));

        const socket = io(API_URL, { auth: { token } });
        socketRef.current = socket;
        socket.on('connect', () => socket.emit('conversation:join', { conversationId }));
        socket.on('new_message', (message: ChatMessage) => {
          if (message.conversationId === conversationId && !cancelled) {
            setMessages((current) => current.some((item) => item.id === message.id) ? current : [...current, normalizeMessage(message)]);
          }
        });
        socket.on('connect_error', () => setError('Connexion à la messagerie impossible.'));
      } catch (cause) {
        if (!cancelled) setError(cause instanceof Error ? cause.message : 'Erreur de messagerie.');
      }
    }

    void prepareConversation();
    return () => {
      cancelled = true;
      socketRef.current?.disconnect();
      socketRef.current = null;
    };
  }, [userId, receiverId, initialConversationId]);

  const sendMedia = useCallback(async (file: File) => {
    const token=window.sessionStorage.getItem('du_token'); if(!token||!conversationId)return false; const form=new FormData(); form.append('file',file); const r=await fetch(`${API_URL}/media/message-media`,{method:'POST',headers:{Authorization:`Bearer ${token}`},body:form}); if(!r.ok) throw new Error('Upload du média impossible.'); const asset=await r.json(); socketRef.current?.emit('send_message',{conversationId,type:file.type.startsWith('image/')?'IMAGE':'AUDIO',mediaUrl:asset.id}); return true;
  },[conversationId]);

  const sendMessage = useCallback((content: string) => {
    const socket = socketRef.current;
    const body = content.trim();
    if (!socket || !conversationId || !body) return false;
    socket.emit('send_message', { conversationId, type: 'TEXT', body });
    return true;
  }, [conversationId]);

  return { messages, setMessages, conversationId, error, sendMessage, sendMedia };
}
