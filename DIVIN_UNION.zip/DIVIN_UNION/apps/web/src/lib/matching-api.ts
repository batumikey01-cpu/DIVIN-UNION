const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export interface ProfileCardDto {
  id: string;
  name: string;
  bio?: string;
  age?: number;
  city?: string;
  country?: string;
  photoUrl?: string;
}

export async function fetchDiscoveryProfiles(token: string): Promise<ProfileCardDto[]> {
  const response = await fetch(`${API_BASE_URL}/profiles/discover`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw new Error('Erreur lors du chargement des profils.');
  const profiles = await response.json() as Array<Record<string, any>>;
  return profiles.map((profile) => ({
    id: profile.id,
    name: profile.name || [profile.firstName, profile.lastName].filter(Boolean).join(' '),
    bio: profile.bio ?? profile.profile?.bio,
    age: profile.age,
    city: profile.city,
    country: profile.country,
    photoUrl: profile.photoUrl || profile.profilePhotoUrl,
  }));
}

export async function submitSwipe(targetId: string, action: 'LIKE' | 'PASS', token: string) {
  const response = await fetch(`${API_BASE_URL}/profiles/${encodeURIComponent(targetId)}/swipe`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ action }),
  });
  if (!response.ok) throw new Error('Erreur lors du swipe.');
  return response.json();
}

export async function sendIntroduction(targetId:string, body:string, token:string){const r=await fetch(`${API_BASE_URL}/messaging/introductions`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({userId:targetId,body})});if(!r.ok)throw new Error("Impossible d'envoyer l'introduction.");return r.json();}
