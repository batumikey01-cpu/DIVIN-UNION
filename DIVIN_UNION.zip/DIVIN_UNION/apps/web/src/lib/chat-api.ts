import type { ChatMessage } from '../hooks/useChat';

export async function fetchConversationHistory(
  partnerId: string,
  token: string,
  baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000',
): Promise<ChatMessage[]> {
  const response = await fetch(`${baseUrl}/messaging/conversations/with/${encodeURIComponent(partnerId)}/messages`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Erreur lors du chargement de l’historique : ${response.statusText}`);
  }

  return response.json() as Promise<ChatMessage[]>;
}
