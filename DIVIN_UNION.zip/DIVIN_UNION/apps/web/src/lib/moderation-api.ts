const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

async function parseError(response: Response, fallback: string) {
  try {
    const payload = await response.json();
    const message = Array.isArray(payload.message) ? payload.message.join(', ') : payload.message;
    return message || fallback;
  } catch {
    return fallback;
  }
}

export async function reportUser(targetId: string, reason: string, token: string) {
  const response = await fetch(`${API_BASE_URL}/moderation/report`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ targetId, reason }),
  });
  if (!response.ok) throw new Error(await parseError(response, 'Erreur lors du signalement.'));
  return response.json();
}

export async function blockUser(blockedId: string, token: string) {
  const response = await fetch(`${API_BASE_URL}/moderation/block`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ blockedId }),
  });
  if (!response.ok) throw new Error(await parseError(response, 'Erreur lors du blocage.'));
  return response.json();
}

export async function unblockUser(blockedId: string, token: string) {
  const response = await fetch(`${API_BASE_URL}/moderation/block/${encodeURIComponent(blockedId)}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!response.ok) throw new Error(await parseError(response, 'Erreur lors du déblocage.'));
  return { ok: true };
}
