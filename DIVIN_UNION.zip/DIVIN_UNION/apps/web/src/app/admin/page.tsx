'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

type Stats = { users: number; paid: number; reports: number; pendingPayments: number };
type User = { id: string; firstName: string; lastName: string; email?: string; phone?: string; isActive: boolean; isDeleted: boolean; role: string; plan: string };
type Report = { id: string; reason: string; status: string; createdAt: string; reported?: { id: string; firstName: string; lastName: string } };

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [query, setQuery] = useState('');
  const [message, setMessage] = useState('');

  function authHeaders(): Record<string, string> {
    const token = window.sessionStorage.getItem('du_token');
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  async function load() {
    const headers = authHeaders();
    const [statsResponse, reportsResponse] = await Promise.all([
      fetch(`${API}/admin/stats`, { headers }),
      fetch(`${API}/moderation/reports`, { headers }),
    ]);
    if (!statsResponse.ok || !reportsResponse.ok) {
      setMessage('Accès administrateur refusé ou session expirée.');
      return;
    }
    setStats(await statsResponse.json());
    setReports(await reportsResponse.json());
  }

  async function searchUsers() {
    const response = await fetch(`${API}/admin/users?q=${encodeURIComponent(query)}`, { headers: authHeaders() });
    const data = await response.json();
    if (!response.ok) { setMessage(data.message || 'Recherche impossible.'); return; }
    setUsers(data);
  }

  async function setActive(user: User, isActive: boolean) {
    const response = await fetch(`${API}/admin/users/${user.id}/status`, {
      method: 'PATCH', headers: { ...authHeaders(), 'Content-Type': 'application/json' }, body: JSON.stringify({ isActive }),
    });
    if (!response.ok) { const data = await response.json(); setMessage(data.message || 'Action impossible.'); return; }
    setUsers((current) => current.map((item) => item.id === user.id ? { ...item, isActive } : item));
  }

  async function resolveReport(report: Report, status: 'RESOLVED' | 'DISMISSED') {
    const response = await fetch(`${API}/moderation/reports/${report.id}/resolve`, {
      method: 'PATCH', headers: { ...authHeaders(), 'Content-Type': 'application/json' }, body: JSON.stringify({ status }),
    });
    if (!response.ok) { const data = await response.json(); setMessage(data.message || 'Action impossible.'); return; }
    setReports((current) => current.filter((item) => item.id !== report.id));
    await load();
  }

  useEffect(() => { void load(); }, []);

  return (
    <main className="container" style={{ maxWidth: 1100 }}>
      <div className="discover-heading">
        <h1>Administration</h1>
        <p className="muted">Pilotage, modération, utilisateurs et paiements.</p>
      </div>
      {message && <p role="alert">{message}</p>}
      {stats && <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 12 }}>
        {([['Utilisateurs', stats.users], ['Premium / Elite', stats.paid], ['Signalements ouverts', stats.reports], ['Paiements en attente', stats.pendingPayments]] as const).map(([label, value]) => <div className="card" key={label}><p className="muted">{label}</p><strong style={{ fontSize: 28 }}>{value}</strong></div>)}
      </div>}

      <div className="card" style={{ marginTop: 16 }}>
        <h2>Accès rapides</h2>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
          <Link className="btn" href="/admin/media">Modération photos</Link>
          <Link className="btn" href="/admin/pricing">Tarifs</Link>
          <Link className="btn" href="/admin/payments">Paiements / fournisseurs</Link>
        </div>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h2>Utilisateurs</h2>
        <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Email, téléphone, nom…" style={{ flex: 1, padding: 12 }} />
          <button className="btn primary" onClick={() => void searchUsers()}>Rechercher</button>
        </div>
        <div style={{ display: 'grid', gap: 8, marginTop: 14 }}>
          {users.map((user) => <article key={user.id} style={{ borderTop: '1px solid #eee', paddingTop: 10 }}><strong>{user.firstName} {user.lastName}</strong> · {user.plan} · {user.role}<div className="muted">{user.email || user.phone || '—'}</div><button className="btn" onClick={() => void setActive(user, !user.isActive)}>{user.isActive ? 'Suspendre' : 'Réactiver'}</button></article>)}
        </div>
      </div>

      <div className="card" style={{ marginTop: 16 }}>
        <h2>Signalements</h2>
        {!reports.length && <p className="muted">Aucun signalement ouvert.</p>}
        <div style={{ display: 'grid', gap: 12 }}>
          {reports.map((report) => <article key={report.id} style={{ borderTop: '1px solid #eee', paddingTop: 10 }}><strong>{report.reported ? `${report.reported.firstName} ${report.reported.lastName}` : report.id}</strong><p>{report.reason}</p><div style={{ display: 'flex', gap: 8 }}><button className="btn primary" onClick={() => void resolveReport(report, 'RESOLVED')}>Résoudre</button><button className="btn" onClick={() => void resolveReport(report, 'DISMISSED')}>Classer sans suite</button></div></article>)}
        </div>
      </div>
    </main>
  );
}
