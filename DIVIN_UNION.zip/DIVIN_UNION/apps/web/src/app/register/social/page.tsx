'use client';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
const API=process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000';
export default function SocialRegister(){
 const router=useRouter();
 const [f,setF]=useState<any>({gender:'MALE',maritalStatus:'SINGLE',country:'CD',city:'Kinshasa',isChristian:false,seekingSerious:true,seekingMarriage:true});
 useEffect(()=>{try{if(sessionStorage.getItem('du_christian_gate')==='yes')setF((x:any)=>({...x,isChristian:true}));}catch{}} ,[]);
 const [photo,setPhoto]=useState<File|null>(null); const [preview,setPreview]=useState(''); const [msg,setMsg]=useState(''); const set=(k:string,v:any)=>setF((x:any)=>({...x,[k]:v}));
 async function submit(){if(f.isChristian!==true){setMsg('Vous devez confirmer que vous êtes chrétien(ne) pour créer un compte.');return}if(!photo){setMsg('Ajoutez une photo de profil pour continuer.');return}
  setMsg('');
  const r=await fetch(`${API}/auth/oauth/complete`,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(f)});
  const j=await r.json(); if(!r.ok){setMsg(j.message||'Impossible de terminer le compte.');return}
  sessionStorage.setItem('du_token',j.accessToken);
  if(photo){const fd=new FormData();fd.append('file',photo);const up=await fetch(`${API}/media/photos`,{method:'POST',headers:{Authorization:`Bearer ${j.accessToken}`},body:fd});if(!up.ok){setMsg('Compte créé. La photo n’a pas pu être envoyée. Vous pourrez la réessayer depuis votre profil.');return;}}
  router.push('/discover');
 }
 return <main className="container" style={{maxWidth:700}}><div className="card"><h1>Finaliser votre profil</h1><p className="muted">Votre compte social est reconnu. Complétez maintenant votre profil Divin’Union.</p><div style={{display:'grid',gap:10}}>
 {['firstName','lastName','dateOfBirth','country','city','bio'].map(k=><input key={k} type={k==='dateOfBirth'?'date':'text'} placeholder={k==='firstName'?'Prénom':k==='lastName'?'Nom':k==='dateOfBirth'?'Date de naissance':k==='country'?'Pays (code)':k==='city'?'Ville':'Présentation'} value={f[k]||''} onChange={e=>set(k,e.target.value)} style={{padding:12}}/>)}
 <label style={{display:'grid',gap:6}}><strong>Photo de profil</strong><input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>{const file=e.target.files?.[0]||null;setPhoto(file);setPreview(file?URL.createObjectURL(file):'')}}/></label>
 {preview&&<img src={preview} alt="Aperçu" style={{width:160,height:160,objectFit:'cover',borderRadius:16}}/>}
 <select value={f.gender} onChange={e=>set('gender',e.target.value)}><option value="MALE">Homme</option><option value="FEMALE">Femme</option></select><select value={f.maritalStatus} onChange={e=>set('maritalStatus',e.target.value)}><option value="SINGLE">Célibataire</option><option value="WIDOWED">Veuf/Veuve</option><option value="DIVORCED">Divorcé(e)</option><option value="SEPARATED">Séparé(e)</option></select><button className="btn primary" onClick={()=>void submit()}>Terminer mon inscription</button>{msg&&<p role="alert">{msg}</p>}</div></div></main>
}
