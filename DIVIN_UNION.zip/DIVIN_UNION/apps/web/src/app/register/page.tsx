'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
const API=process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000';
export default function Register(){
 const [mode,setMode]=useState<'choice'|'email'|'otp'>('choice'),[email,setEmail]=useState(''),[otp,setOtp]=useState(''),[verificationId,setVerificationId]=useState(''),[msg,setMsg]=useState(''); const router=useRouter();
 async function requestOtp(){const r=await fetch(`${API}/auth/otp/email/request`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})});const j=await r.json();if(!r.ok){setMsg(j.message||'Erreur');return}setVerificationId(j.verificationId||'');setMsg('Code envoyé à votre email.');setMode('otp')}
 async function verifyOtp(){const r=await fetch(`${API}/auth/otp/email/verify`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,code:otp})});const j=await r.json();if(!r.ok){setMsg(j.message||'Code invalide');return}sessionStorage.setItem('email_verified_id',j.verificationId||verificationId);setMsg('Email vérifié. Vous pouvez continuer votre inscription.');router.push(`/register/email?email=${encodeURIComponent(email)}&verificationId=${encodeURIComponent(j.verificationId||verificationId)}`)}
 return <main className="container" style={{maxWidth:620}}><div className="card"><h1>Créer votre compte</h1><p className="muted">Choisissez votre méthode principale ou l’option email secondaire. Avec l’email, vous définirez votre mot de passe après vérification du code.</p>
 {mode==='choice'&&<div style={{display:'grid',gap:10}}><a className="btn primary" href={`${API}/auth/oauth/google/start`}>Créer avec Google</a><a className="btn" href={`${API}/auth/oauth/apple/start`}>Créer avec Apple</a><a className="btn" href={`${API}/auth/oauth/microsoft/start`}>Créer avec Microsoft</a><button className="btn" onClick={()=>setMode('email')}>Créer avec mon email</button></div>}
 {mode==='email'&&<div><input type="email" placeholder="Votre email" value={email} onChange={e=>setEmail(e.target.value)} style={{padding:12,width:'100%',marginBottom:10}}/><button className="btn primary" onClick={()=>void requestOtp()}>Recevoir mon code email</button></div>}
 {mode==='otp'&&<div><p>{msg}</p><input inputMode="numeric" maxLength={6} placeholder="Code à 6 chiffres" value={otp} onChange={e=>setOtp(e.target.value)} style={{padding:12,width:'100%',marginBottom:10}}/><button className="btn primary" onClick={()=>void verifyOtp()}>Vérifier mon email</button></div>}
 {msg&&mode!=='otp'&&<p role="alert">{msg}</p>}</div></main>
}
