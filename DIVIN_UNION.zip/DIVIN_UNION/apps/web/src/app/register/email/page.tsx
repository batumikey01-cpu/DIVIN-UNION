'use client';

import { Suspense, useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

type ProfileForm = {
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth?: string;
  gender: 'MALE' | 'FEMALE';
  maritalStatus: 'SINGLE' | 'WIDOWED' | 'DIVORCED' | 'SEPARATED';
  country: string;
  city: string;
  bio?: string;
  isChristian: boolean;
  seekingSerious: boolean;
  seekingMarriage: boolean;
};

function EmailRegisterForm() {
  const params = useSearchParams();
  const router = useRouter();
  const email = params.get('email') || '';
  const verificationId = params.get('verificationId') || '';
  const [form, setForm] = useState<ProfileForm>({ firstName: '', lastName: '', email, gender: 'MALE', maritalStatus: 'SINGLE', country: 'CD', city: 'Kinshasa', isChristian: false, seekingSerious: true, seekingMarriage: true });
  const [password, setPassword] = useState('');
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    setForm((current) => ({ ...current, email }));
    try {
      if (sessionStorage.getItem('du_christian_gate') === 'yes') setForm((current) => ({ ...current, email, isChristian: true }));
    } catch { /* sessionStorage peut être indisponible */ }
  }, [email]);

  const update = <K extends keyof ProfileForm>(key: K, value: ProfileForm[K]) => setForm((current) => ({ ...current, [key]: value }));

  async function submit() {
    if (form.isChristian !== true) { setMessage('Vous devez confirmer que vous êtes chrétien(ne) pour créer un compte.'); return; }
    if (!photo) { setMessage('Ajoutez une photo de profil pour continuer.'); return; }
    const response = await fetch(`${API}/auth/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify({ ...form, password, otpVerificationId: verificationId }) });
    const result = await response.json();
    if (!response.ok) { setMessage(result.message || 'Erreur lors de la création du compte.'); return; }
    sessionStorage.setItem('du_token', result.accessToken);
    const data = new FormData();
    data.append('file', photo);
    const upload = await fetch(`${API}/media/photos`, { method: 'POST', headers: { Authorization: `Bearer ${result.accessToken}` }, body: data });
    if (!upload.ok) { setMessage('Compte créé. La photo n’a pas pu être envoyée. Vous pourrez la réessayer depuis votre profil.'); return; }
    router.push('/discover');
  }

  return <main className="container" style={{ maxWidth: 700 }}><div className="card"><h1>Finaliser avec votre email</h1><p>Email vérifié : <strong>{email}</strong></p><div style={{ display: 'grid', gap: 10 }}>
    {([['firstName', 'Prénom', 'text'], ['lastName', 'Nom', 'text'], ['dateOfBirth', 'Date de naissance', 'date'], ['country', 'Pays (code)', 'text'], ['city', 'Ville', 'text'], ['bio', 'Présentation', 'text']] as const).map(([key, label, type]) => <input key={key} type={type} placeholder={label} value={String(form[key] || '')} onChange={(event) => update(key, event.target.value)} style={{ padding: 12 }} />)}
    <label style={{ display: 'grid', gap: 6 }}><strong>Photo de profil</strong><input type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => { const file = event.target.files?.[0] || null; setPhoto(file); setPreview(file ? URL.createObjectURL(file) : ''); }} /></label>
    {preview && <img src={preview} alt="Aperçu" style={{ width: 160, height: 160, objectFit: 'cover', borderRadius: 16 }} />}
    <input type="password" placeholder="Mot de passe fort" value={password} onChange={(event) => setPassword(event.target.value)} style={{ padding: 12 }} />
    <select value={form.gender} onChange={(event) => update('gender', event.target.value as ProfileForm['gender'])}><option value="MALE">Homme</option><option value="FEMALE">Femme</option></select>
    <select value={form.maritalStatus} onChange={(event) => update('maritalStatus', event.target.value as ProfileForm['maritalStatus'])}><option value="SINGLE">Célibataire</option><option value="WIDOWED">Veuf/Veuve</option><option value="DIVORCED">Divorcé(e)</option><option value="SEPARATED">Séparé(e)</option></select>
    <button className="btn primary" onClick={() => void submit()}>Créer mon compte</button>{message && <p role="alert">{message}</p>}
  </div></div></main>;
}

export default function EmailRegisterPage() {
  return <Suspense fallback={<main className="container"><div className="card">Chargement du formulaire…</div></main>}><EmailRegisterForm /></Suspense>;
}
