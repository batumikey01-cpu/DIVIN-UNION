'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { SwipeDeck } from '../../components/swipe-deck';

export default function Discover() {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const currentToken = window.sessionStorage.getItem('du_token');
    if (!currentToken) {
      router.replace('/login');
      return;
    }
    setToken(currentToken);
  }, [router]);

  return (
    <>
      <header className="nav"><div className="brand">Divin<span>'</span>Union</div><span className="muted">Découvrir</span></header>
      <main className="container">
        <div className="discover-heading">
          <h1>Découverte</h1>
          <p className="muted">Trouvez votre affinité sur Divin’Union</p>
        </div>
        {message && <p role="status">{message}</p>}
        {token && <SwipeDeck token={token} />}
      </main>
    </>
  );
}
