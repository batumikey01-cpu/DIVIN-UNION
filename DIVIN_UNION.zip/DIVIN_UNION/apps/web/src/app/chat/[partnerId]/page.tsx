import { ChatPageClient } from '../../../components/chat-page-client';

interface ChatPageProps {
  params: Promise<{ partnerId: string }>;
}

export default async function ChatPage({ params }: ChatPageProps) {
  const { partnerId } = await params;
  return <ChatPageClient partnerId={partnerId} />;
}
