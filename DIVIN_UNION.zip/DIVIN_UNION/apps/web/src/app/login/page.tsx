'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';

export default function Login() {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const router = useRouter();
  async function submit() {
    setMessage('');
    const response = await fetch(`${API}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify({ identifier, password }) });
    const result = await response.json();
    if (!response.ok) return setMessage(result.message || 'Identifiants invalides.');
    sessionStorage.setItem('du_token', result.accessToken); router.push('/discover');
  }
  return <main className="container" style={{ maxWidth: 520 }}><div className="card">
    <h1>Se connecter</h1>
    <p className="muted">La connexion principale se fait avec votre compte Google, Apple ou Microsoft.</p>
    <div style={{ display:'grid', gap:10 }}>
      <a className="btn primary" href={`${API}/auth/oauth/google/start`}>Continuer avec Google</a>
      <a className="btn" href={`${API}/auth/oauth/apple/start`}>Continuer avec Apple</a>
      <a className="btn" href={`${API}/auth/oauth/microsoft/start`}>Continuer avec Microsoft</a>
    </div>
    <hr style={{ margin:'22px 0' }}/>
    <p><strong>Option secondaire : email + mot de passe</strong></p>
    <input placeholder="Email" value={identifier} onChange={e=>setIdentifier(e.target.value)} style={{ padding:12, width:'100%', marginBottom:10 }}/>
    <input type="password" placeholder="Mot de passe" value={password} onChange={e=>setPassword(e.target.value)} style={{ padding:12, width:'100%', marginBottom:10 }}/>
    <button className="btn" onClick={()=>void submit()} type="button">Se connecter avec mon email</button>
    <a href="/password-reset" className="muted">Mot de passe oublié ?</a>{message && <p role="alert">{message}</p>}
  </div></main>;
}
