'use client';
import { PhotoManager } from '../../../components/photo-manager';

export default function MyProfilePhotos() {
  return <main className="container" style={{ maxWidth: 900 }}><PhotoManager /></main>;
}
