export default function CookiesPage() {
  return <main className="container" style={{ maxWidth: 820 }}><div className="card"><h1>Politique de cookies</h1><p className="muted">Dernière mise à jour : 28 septembre 2026</p><h2>Cookies essentiels</h2><p>Les cookies de session et le stockage local nécessaires à l’authentification et à la sécurité sont indispensables au fonctionnement du service.</p><h2>Choix</h2><p>Nous n’utilisons pas de cookies publicitaires dans cette version. Les préférences peuvent être gérées depuis votre navigateur.</p></div></main>;
}
