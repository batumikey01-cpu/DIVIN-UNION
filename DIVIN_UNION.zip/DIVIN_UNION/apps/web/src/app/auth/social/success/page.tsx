'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
const API=process.env.NEXT_PUBLIC_API_URL||'http://localhost:4000';
export default function SocialSuccess(){const router=useRouter();useEffect(()=>{fetch(`${API}/auth/refresh`,{method:'POST',credentials:'include'}).then(async r=>{const j=await r.json();if(!r.ok) throw new Error(j.message||'Connexion impossible');sessionStorage.setItem('du_token',j.accessToken);router.replace('/discover')}).catch(()=>router.replace('/login'));},[router]);return <main className="container"><div className="card"><p>Connexion sécurisée en cours…</p></div></main>}
