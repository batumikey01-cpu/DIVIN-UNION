import './globals.css'; import { ChristianGate } from '../components/christian-gate'; import type {Metadata} from 'next';
export const metadata:Metadata={title:"Divin'Union — Rencontres chrétiennes",description:"Rencontres chrétiennes sérieuses dans l'espace francophone."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}<ChristianGate /></body></html>}
