import Image from 'next/image';
import Link from 'next/link';
import { LandingHeader } from '../components/landing-header';
import { LandingFooter } from '../components/landing-footer';
import { LandingDownloadSection } from '../components/landing-download-section';
import { ProfileCarousel } from '../components/profile-carousel';
import { TestimonialCarousel } from '../components/testimonial-carousel';
import { FaithIcon, HeartIcon, ShieldIcon, GroupIcon } from '../components/landing-icons';
import { heroImage } from '../components/landing-data';

const values = [
  { title: 'Une foi commune', text: 'Rencontrez des personnes qui partagent votre foi chrétienne et vos convictions.', Icon: FaithIcon },
  { title: 'Des intentions sérieuses', text: 'Une plateforme pensée pour celles et ceux qui souhaitent construire une relation durable.', Icon: HeartIcon },
  { title: 'Un environnement de confiance', text: 'Des outils et des règles conçus pour favoriser des rencontres respectueuses.', Icon: ShieldIcon },
  { title: 'Des valeurs compatibles', text: 'Famille, projets de vie, convictions : découvrez ce qui compte réellement pour vous.', Icon: GroupIcon },
];

const steps = [
  ['01', 'Créez votre profil', 'Présentez-vous, votre foi, vos valeurs et ce que vous recherchez.', FaithIcon],
  ['02', 'Découvrez des profils compatibles', 'Explorez des personnes correspondant à vos critères et à vos valeurs.', GroupIcon],
  ['03', 'Échangez', 'Commencez une conversation et prenez le temps de vous découvrir.', HeartIcon],
  ['04', 'Construisez votre histoire', 'Parce qu’une belle rencontre mérite du temps et de l’authenticité.', ShieldIcon],
] as const;

const sectionTitle = 'font-serif text-[clamp(1.9rem,3vw,2.8rem)] font-bold leading-[1.05] tracking-[-.04em] text-[#17233d]';
const sectionIntro = 'mx-auto mt-4 max-w-2xl text-[15px] leading-7 text-[#6b7280]';

export default function Home() {
  return <div className="min-h-screen overflow-hidden bg-[#fbfaf7] text-[#17233d]">
    <LandingHeader />
    <main>
      <section id="accueil" className="relative isolate overflow-hidden border-b border-white/70 bg-[#e8f0f6]">
        <Image src={heroImage} alt="Couple regardant la ville depuis une terrasse" fill priority sizes="100vw" className="object-cover object-[58%_center] lg:object-center" />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(251,250,247,.98)_0%,rgba(251,250,247,.89)_31%,rgba(251,250,247,.48)_55%,rgba(251,250,247,.08)_100%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(23,35,61,.04),transparent_35%,rgba(23,35,61,.08))]" />
        <div className="relative z-10 mx-auto flex min-h-[570px] max-w-7xl items-center px-5 py-20 sm:px-8 lg:min-h-[610px] lg:px-12 lg:py-24">
          <div className="max-w-[470px] lg:ml-4">
            <div className="h-1 w-12 rounded-full bg-[#b9975b]" />
            <h1 className="mt-6 max-w-[520px] font-serif text-[clamp(2.7rem,5vw,4.15rem)] font-bold leading-[.96] tracking-[-.055em] text-[#17233d]">Deux cœurs.<br /><span className="whitespace-nowrap">Une foi. Une union.</span></h1>
            <p className="mt-7 max-w-[390px] text-[15px] leading-7 text-[#43566e] sm:text-base">Des rencontres chrétiennes authentiques pour construire une relation fondée sur la foi, les valeurs et l’amour.</p>
            <Link href="/register" className="landing-button mt-8 inline-flex min-w-[218px] items-center justify-center gap-3 whitespace-nowrap rounded-full bg-[#18366f] px-6 py-3.5 text-sm font-bold text-white shadow-[0_14px_28px_rgba(24,54,111,.22)] transition duration-200 hover:-translate-y-0.5 hover:bg-[#102654]">Commencer gratuitement <span aria-hidden="true" className="text-lg leading-none">→</span></Link>
            
          </div>
        </div>
      </section>

      <section id="essentials" className="bg-white px-5 py-14 sm:px-8 lg:px-10 lg:py-24">
        <div className="mx-auto max-w-7xl text-center"><h2 className={`${sectionTitle} mx-auto max-w-4xl`}>Quand la foi unit les cœurs, l’amour prend un autre sens.</h2><p className={sectionIntro}>Plus qu’une application, une communauté de personnes qui partagent la même foi et les mêmes valeurs.</p>
          <div className="mt-10 grid overflow-hidden rounded-[1.75rem] border border-[#ebe6dc] bg-[#fbfaf7] sm:grid-cols-2 md:grid-cols-4 md:divide-x md:divide-[#ebe6dc]">{values.map(({ title, text, Icon }) => <a key={title} href="#how-it-works" className="group border-b border-[#ebe6dc] px-5 py-6 text-center transition duration-200 hover:bg-white md:border-b-0 md:px-5 lg:px-7 lg:py-9"><span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-[#d8bd82] bg-white text-[#18366f] shadow-[0_5px_14px_rgba(23,35,61,.05)] transition group-hover:-translate-y-0.5 group-hover:bg-[#f7efdf]"><Icon className="h-6 w-6" /></span><h3 className="mx-auto mt-5 min-h-[2.5rem] max-w-[190px] font-serif text-[15px] font-bold leading-5 text-[#17233d]">{title}</h3><p className="mx-auto mt-3 max-w-[215px] text-xs leading-6 text-[#777f8a]">{text}</p></a>)}</div>
        </div>
      </section>

      <section id="how-it-works" className="relative overflow-hidden bg-[#edf4f8] px-5 py-14 sm:px-8 lg:px-10 lg:py-24">
        <div className="absolute inset-x-0 top-0 h-px bg-[#dbe5ec]" /><div className="mx-auto max-w-7xl text-center"><h2 className={sectionTitle}>Comment ça marche ?</h2><p className={sectionIntro}>En quelques étapes simples, trouvez la personne qui vous correspond.</p>
          <div className="journey-steps relative mt-10 grid gap-0 sm:grid-cols-2 md:grid-cols-4"><div className="journey-line pointer-events-none absolute left-[12%] right-[12%] top-[4.45rem] hidden h-px bg-[#d8bd82] md:block" />{steps.map(([number, title, text, Icon]) => <div key={number} className="journey-step relative z-10 border-b border-[#d9e3ea] px-5 py-6 md:border-b-0 md:px-5 lg:px-6 lg:py-10"><span className="relative z-10 inline-flex h-9 min-w-9 items-center justify-center rounded-full bg-[#d8bd82] px-2 font-serif text-sm font-bold text-[#17233d]">{number}</span><span className="relative z-10 mx-auto mt-3 flex h-11 w-11 items-center justify-center rounded-full border border-[#d8bd82] bg-white text-[#18366f]"><Icon className="h-5 w-5" /></span><h3 className="mx-auto mt-3 min-h-[2.6rem] max-w-[190px] font-serif text-[15px] font-bold leading-5 text-[#17233d]">{title}</h3><p className="mx-auto mt-3 max-w-[210px] text-xs leading-5 text-[#777f8a]">{text}</p></div>)}</div><Link href="/register" className="landing-button mt-8 inline-flex items-center gap-3 rounded-full bg-[#18366f] px-7 py-3.5 text-sm font-bold text-white shadow-[0_12px_26px_rgba(24,54,111,.18)] transition hover:-translate-y-0.5 hover:bg-[#102654]">Créer mon profil gratuitement <span aria-hidden="true" className="text-lg leading-none">→</span></Link>
        </div>
      </section>

      <section id="community" className="bg-white px-5 py-20 sm:px-8 lg:px-10 lg:py-24"><div className="mx-auto max-w-7xl"><h2 className={`${sectionTitle} text-center`}>Des célibataires chrétiens qui cherchent quelque chose de vrai</h2><p className="mx-auto mt-3 max-w-xl text-center text-[15px] leading-7 text-[#6b7280]">Découvrez des personnes qui partagent vos valeurs et vos intentions.</p><div className="mt-9"><ProfileCarousel /></div></div></section>

      <section id="testimonials"><TestimonialCarousel /></section>

      <LandingDownloadSection />

      <section className="relative isolate overflow-hidden bg-[#17366f] px-5 py-20 sm:px-8 lg:px-10 lg:py-24"><Image src={heroImage} alt="Couple regardant la ville" fill sizes="100vw" className="object-cover object-right opacity-75" /><div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(10,31,65,.98)_0%,rgba(19,54,111,.88)_37%,rgba(19,54,111,.32)_72%,rgba(19,54,111,.2)_100%)]" /><div className="relative mx-auto max-w-7xl"><div className="max-w-[520px]"><h2 className="font-serif text-[clamp(2rem,3.5vw,3.2rem)] font-bold leading-[1.02] tracking-[-.04em] text-white">Et si cette rencontre était la bonne ?</h2><p className="mt-5 max-w-md text-[15px] leading-7 text-white/75">Vous n’avez pas besoin de savoir où cette histoire vous mènera. Commencez simplement par une rencontre.</p><Link href="/register" className="landing-button mt-8 inline-flex items-center gap-3 rounded-full bg-white px-7 py-3.5 text-sm font-bold !text-[#18366f] shadow-[0_12px_28px_rgba(0,0,0,.18)] transition hover:-translate-y-0.5 hover:bg-[#f7efdf]">Commencer gratuitement <span aria-hidden="true" className="text-lg leading-none">→</span></Link></div></div></section>
    </main>
    <LandingFooter />
  </div>;
}
