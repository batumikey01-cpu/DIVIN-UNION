import { PrismaClient, Gender, MaritalStatus, Plan, Role, SwipeAction, MessageType } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();
const DEMO_PASSWORD = process.env.DEMO_PASSWORD || 'DivinDemo!2026';

const profiles = [
  {
    id: 'demo-alice',
    email: 'alice.demo@divinunion.test',
    phone: '+243811000001',
    firstName: 'Alice',
    lastName: 'Mukendi',
    dateOfBirth: '1995-04-12',
    gender: Gender.FEMALE,
    city: 'Kinshasa',
    bio: 'Chrétienne engagée, j’aime la lecture, le service et les conversations profondes.',
    interests: ['prière', 'lecture', 'musique'],
    photo: 'https://placehold.co/640x800/f4d7c5/4a2c2a?text=Alice',
  },
  {
    id: 'demo-david',
    email: 'david.demo@divinunion.test',
    phone: '+243811000002',
    firstName: 'David',
    lastName: 'Kabeya',
    dateOfBirth: '1991-09-03',
    gender: Gender.MALE,
    city: 'Kinshasa',
    bio: 'Serviteur dans mon église, passionné de musique gospel et de projets utiles.',
    interests: ['gospel', 'service', 'entrepreneuriat'],
    photo: 'https://placehold.co/640x800/d4e5f7/243447?text=David',
  },
  {
    id: 'demo-grace',
    email: 'grace.demo@divinunion.test',
    phone: '+243811000003',
    firstName: 'Grâce',
    lastName: 'Ilunga',
    dateOfBirth: '1997-01-28',
    gender: Gender.FEMALE,
    city: 'Lubumbashi',
    bio: 'J’apprécie la simplicité, la foi vécue au quotidien et les découvertes culturelles.',
    interests: ['voyage', 'cuisine', 'famille'],
    photo: 'https://placehold.co/640x800/e7d8f5/3d2d52?text=Grace',
  },
  {
    id: 'demo-jonathan',
    email: 'jonathan.demo@divinunion.test',
    phone: '+243811000004',
    firstName: 'Jonathan',
    lastName: 'Mbuyi',
    dateOfBirth: '1989-11-19',
    gender: Gender.MALE,
    city: 'Goma',
    bio: 'Homme de foi, amateur de randonnée et de discussions honnêtes orientées vers le mariage.',
    interests: ['randonnée', 'bible', 'photographie'],
    photo: 'https://placehold.co/640x800/d5eadf/244434?text=Jonathan',
  },
  {
    id: 'demo-esther',
    email: 'esther.demo@divinunion.test',
    phone: '+243811000005',
    firstName: 'Esther',
    lastName: 'Banza',
    dateOfBirth: '1993-06-07',
    gender: Gender.FEMALE,
    city: 'Kisangani',
    bio: 'J’aime apprendre, encourager les autres et construire une relation fondée sur la confiance.',
    interests: ['formation', 'chant', 'famille'],
    photo: 'https://placehold.co/640x800/f6e4b8/493d1d?text=Esther',
  },
];

async function main() {
  const passwordHash = await argon2.hash(DEMO_PASSWORD);
  const users: Record<string, { id: string }> = {};

  for (const profile of profiles) {
    const user = await prisma.user.upsert({
      where: { phone: profile.phone },
      update: {
        email: profile.email,
        passwordHash,
        firstName: profile.firstName,
        lastName: profile.lastName,
        dateOfBirth: new Date(profile.dateOfBirth),
        gender: profile.gender,
        city: profile.city,
        bio: profile.bio,
        interests: profile.interests,
        profilePhotoUrl: profile.photo,
        isChristian: true,
        christianCriteriaVerified: true,
        phoneVerified: true,
        isActive: true,
        isDeleted: false,
        plan: Plan.FREE,
      },
      create: {
        id: profile.id,
        email: profile.email,
        phone: profile.phone,
        passwordHash,
        firstName: profile.firstName,
        lastName: profile.lastName,
        dateOfBirth: new Date(profile.dateOfBirth),
        gender: profile.gender,
        country: 'CD',
        city: profile.city,
        maritalStatus: MaritalStatus.SINGLE,
        isChristian: true,
        christianCriteriaVerified: true,
        phoneVerified: true,
        profilePhotoUrl: profile.photo,
        bio: profile.bio,
        interests: profile.interests,
        plan: Plan.FREE,
      },
      select: { id: true },
    });
    users[profile.email] = user;
    await prisma.photo.deleteMany({ where: { userId: user.id } });
    await prisma.photo.create({ data: { userId: user.id, url: profile.photo, sortOrder: 0 } });
  }

  const adminEmail = process.env.SUPERADMIN_EMAIL || 'admin.demo@divinunion.test';
  const admin = await prisma.user.upsert({
    where: { phone: '+243811000000' },
    update: { email: adminEmail, passwordHash, role: Role.SUPER_ADMIN, phoneVerified: true, isActive: true, isDeleted: false },
    create: {
      id: 'demo-admin',
      email: adminEmail,
      phone: '+243811000000',
      passwordHash,
      firstName: 'Admin',
      lastName: 'Demo',
      dateOfBirth: new Date('1985-01-01'),
      gender: Gender.MALE,
      country: 'CD',
      city: 'Kinshasa',
      maritalStatus: MaritalStatus.SINGLE,
      isChristian: true,
      christianCriteriaVerified: true,
      phoneVerified: true,
      profilePhotoUrl: 'https://placehold.co/640x800/e8e8e8/333?text=Admin',
      bio: 'Compte de démonstration administrateur.',
      role: Role.SUPER_ADMIN,
    },
    select: { id: true },
  });

  const alice = users['alice.demo@divinunion.test'];
  const david = users['david.demo@divinunion.test'];
  const grace = users['grace.demo@divinunion.test'];
  const jonathan = users['jonathan.demo@divinunion.test'];
  const esther = users['esther.demo@divinunion.test'];

  await prisma.like.upsert({ where: { giverId_receiverId: { giverId: alice.id, receiverId: david.id } }, update: {}, create: { giverId: alice.id, receiverId: david.id } });
  await prisma.like.upsert({ where: { giverId_receiverId: { giverId: david.id, receiverId: alice.id } }, update: {}, create: { giverId: david.id, receiverId: alice.id } });
  await prisma.swipe.upsert({ where: { giverId_receiverId: { giverId: alice.id, receiverId: david.id } }, update: { action: SwipeAction.LIKE }, create: { giverId: alice.id, receiverId: david.id, action: SwipeAction.LIKE } });
  await prisma.swipe.upsert({ where: { giverId_receiverId: { giverId: david.id, receiverId: alice.id } }, update: { action: SwipeAction.LIKE }, create: { giverId: david.id, receiverId: alice.id, action: SwipeAction.LIKE } });
  await prisma.swipe.upsert({ where: { giverId_receiverId: { giverId: grace.id, receiverId: jonathan.id } }, update: { action: SwipeAction.PASS }, create: { giverId: grace.id, receiverId: jonathan.id, action: SwipeAction.PASS } });

  let conversation = await prisma.conversation.findFirst({
    where: { AND: [{ members: { some: { userId: alice.id } } }, { members: { some: { userId: david.id } } }] },
    include: { members: true },
  });
  if (!conversation) {
    conversation = await prisma.conversation.create({ data: { members: { create: [{ userId: alice.id }, { userId: david.id }] } }, include: { members: true } });
  }
  const existingMessage = await prisma.message.findFirst({ where: { conversationId: conversation.id } });
  if (!existingMessage) {
    await prisma.message.createMany({ data: [
      { conversationId: conversation.id, senderId: alice.id, receiverId: david.id, type: MessageType.TEXT, body: 'Bonjour David, heureuse de faire connaissance.' },
      { conversationId: conversation.id, senderId: david.id, receiverId: alice.id, type: MessageType.TEXT, body: 'Bonjour Alice, moi aussi. Que Dieu te bénisse !' },
    ] });
  }

  for (const price of [
    {plan:Plan.PREMIUM,months:1,amount:4.99,currency:'USD'},{plan:Plan.PREMIUM,months:3,amount:12,currency:'USD'},{plan:Plan.PREMIUM,months:6,amount:23.94,currency:'USD'},
    {plan:Plan.ELITE,months:1,amount:9.99,currency:'USD'},{plan:Plan.ELITE,months:3,amount:24,currency:'USD'},{plan:Plan.ELITE,months:6,amount:47.94,currency:'USD'},
  ]) await prisma.subscriptionPrice.upsert({where:{plan_months:{plan:price.plan,months:price.months}},update:{amount:price.amount,currency:price.currency,active:true},create:price});

  console.log(`Seed terminé : ${profiles.length} profils, 1 admin, likes et conversation de démonstration.`);
  console.log(`Comptes de test : alice.demo@divinunion.test et david.demo@divinunion.test / mot de passe : ${DEMO_PASSWORD}`);
  void esther;
  void admin;
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(async () => { await prisma.$disconnect(); });
