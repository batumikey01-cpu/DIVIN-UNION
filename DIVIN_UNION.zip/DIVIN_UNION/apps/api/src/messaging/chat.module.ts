import { Module } from '@nestjs/common';
import { MessagingModule } from './messaging.module';
import { PrismaModule } from '../common/prisma.module';
import { ModerationModule } from '../moderation/moderation.module';
import { NotificationModule } from '../notifications/notification.module';

/**
 * Façade de compatibilité pour le nom ChatModule.
 * Les contrôleurs, le gateway et le service restent centralisés dans MessagingModule.
 */
@Module({
  imports: [PrismaModule, ModerationModule, NotificationModule, MessagingModule],
  exports: [MessagingModule],
})
export class ChatModule {}
