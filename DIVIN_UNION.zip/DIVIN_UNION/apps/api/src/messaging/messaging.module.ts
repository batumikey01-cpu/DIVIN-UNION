import { Module } from '@nestjs/common';
import { MessagingController } from './messaging.controller';
import { MessagingService } from './messaging.service';
import { MessagingGateway } from './messaging.gateway';
import { AuthModule } from '../auth/auth.module';
import { PrismaModule } from '../common/prisma.module';
import { ModerationModule } from '../moderation/moderation.module';
import { NotificationModule } from '../notifications/notification.module';

@Module({ imports: [AuthModule, PrismaModule, ModerationModule, NotificationModule], controllers: [MessagingController], providers: [MessagingService, MessagingGateway] })
export class MessagingModule {}
