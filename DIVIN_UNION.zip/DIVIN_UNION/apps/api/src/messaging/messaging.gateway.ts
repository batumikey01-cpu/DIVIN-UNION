import {
  ConnectedSocket,
  MessageBody,
  OnGatewayConnection,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { JwtService } from '@nestjs/jwt';
import { ForbiddenException, UnauthorizedException } from '@nestjs/common';
import { Server, Socket } from 'socket.io';
import { PrismaService } from '../common/prisma.service';
import { MessagingService } from './messaging.service';
import { ModerationService } from '../moderation/moderation.service';
import { NotificationService } from '../notifications/notification.service';
import { SendMessageDto } from './messaging.dto';

type AuthenticatedSocket = Socket & { data: { userId?: string } };
type SendMessagePayload = { conversationId?: string; type?: 'TEXT' | 'IMAGE' | 'AUDIO'; body?: string; mediaUrl?: string };

const origins = (process.env.WEB_ORIGIN || process.env.CLIENT_URL || 'http://localhost:3000')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);

@WebSocketGateway({ cors: { origin: origins, credentials: true } })
export class MessagingGateway implements OnGatewayConnection {
  @WebSocketServer() server!: Server;

  constructor(
    private readonly jwt: JwtService,
    private readonly db: PrismaService,
    private readonly messaging: MessagingService,
    private readonly moderation: ModerationService,
    private readonly notifications: NotificationService,
  ) {}

  async handleConnection(socket: AuthenticatedSocket) {
    const raw = socket.handshake.auth?.token || socket.handshake.headers.authorization?.replace(/^Bearer\s+/i, '');
    if (!raw) return socket.disconnect(true);
    try {
      const payload = await this.jwt.verifyAsync<{ sub: string }>(raw);
      const user = await this.db.user.findFirst({ where: { id: payload.sub, isActive: true, isDeleted: false }, select: { id: true } });
      if (!user) throw new UnauthorizedException();
      socket.data.userId = user.id;
      await socket.join(`user_${user.id}`);
    } catch {
      socket.disconnect(true);
    }
  }

  @SubscribeMessage('conversation:join')
  async join(@MessageBody() data: { conversationId?: string }, @ConnectedSocket() socket: AuthenticatedSocket) {
    const userId = socket.data.userId;
    if (!userId || !data.conversationId) throw new UnauthorizedException();
    const member = await this.db.conversationMember.findUnique({ where: { conversationId_userId: { conversationId: data.conversationId, userId } } });
    if (!member) throw new ForbiddenException('Vous ne participez pas à cette conversation.');
    await socket.join([`conversation:${data.conversationId}`, `room_${data.conversationId}`]);
    return { joined: true, roomId: data.conversationId };
  }

  @SubscribeMessage('join_chat_room')
  async joinChatRoom(@MessageBody() data: { roomId?: string }, @ConnectedSocket() socket: AuthenticatedSocket) {
    return this.join({ conversationId: data.roomId }, socket);
  }

  @SubscribeMessage('send_message')
  async sendMessage(@MessageBody() data: SendMessagePayload, @ConnectedSocket() socket: AuthenticatedSocket) {
    const senderId = socket.data.userId;
    if (!senderId) throw new UnauthorizedException();
    if (!data.conversationId || !data.type) throw new ForbiddenException('Données de message incomplètes.');

    const members = await this.db.conversationMember.findMany({ where: { conversationId: data.conversationId }, select: { userId: true } });
    const receiverId = members.find((member: { userId: string }) => member.userId !== senderId)?.userId;
    if (receiverId && await this.moderation.isBlocked(senderId, receiverId)) {
      socket.emit('error_message', { message: 'Communication bloquée entre ces utilisateurs.' });
      return { status: 'blocked' };
    }

    const message: SendMessageDto = {
      conversationId: data.conversationId,
      type: data.type,
      body: data.body,
      mediaUrl: data.mediaUrl,
    };
    const savedMessage = await this.messaging.send(senderId, message);
    this.server.to(`conversation:${data.conversationId}`).emit('new_message', savedMessage);
    socket.emit('new_message', savedMessage);
    if (receiverId) {
      this.server.to(`user_${receiverId}`).emit('notification_message', savedMessage);
      const sender = await this.db.user.findUnique({ where: { id: senderId }, select: { firstName: true } });
      void this.notifications.notifyNewMessage(receiverId, sender?.firstName || senderId, data.body || '').catch(() => undefined);
    }
    return { status: 'sent', data: savedMessage };
  }

  @SubscribeMessage('typing')
  async typing(@MessageBody() data: { conversationId?: string }, @ConnectedSocket() socket: AuthenticatedSocket) {
    const userId = socket.data.userId;
    if (!userId || !data.conversationId) throw new UnauthorizedException();
    const member = await this.db.conversationMember.findUnique({ where: { conversationId_userId: { conversationId: data.conversationId, userId } } });
    if (!member) throw new ForbiddenException('Vous ne participez pas à cette conversation.');
    socket.to(`conversation:${data.conversationId}`).emit('typing', { conversationId: data.conversationId, userId });
    return { ok: true };
  }
}
