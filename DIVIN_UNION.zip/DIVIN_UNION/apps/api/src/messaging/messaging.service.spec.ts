import { MessagingService } from './messaging.service';

describe('MessagingService conversation isolation', () => {
  const prisma: any = {
    conversation: { findFirst: jest.fn() },
    message: { findMany: jest.fn() },
  };
  const service = new MessagingService(prisma);

  beforeEach(() => jest.clearAllMocks());

  it('requires both users and excludes conversations with a third member', async () => {
    prisma.conversation.findFirst.mockResolvedValue(null);
    await expect(service.conversationHistory('user-a', 'user-b')).resolves.toEqual([]);
    expect(prisma.conversation.findFirst).toHaveBeenCalledWith({
      where: {
        AND: [
          { members: { some: { userId: 'user-a' } } },
          { members: { some: { userId: 'user-b' } } },
          { members: { every: { userId: { in: ['user-a', 'user-b'] } } } },
        ],
      },
      select: { id: true, status: true },
    });
    expect(prisma.message.findMany).not.toHaveBeenCalled();
  });

  it('caps history requests at one hundred messages', async () => {
    prisma.conversation.findFirst.mockResolvedValue({ id: 'conversation-1' });
    prisma.message.findMany.mockResolvedValue([]);
    await service.conversationHistory('user-a', 'user-b', 1000);
    expect(prisma.message.findMany).toHaveBeenCalledWith(expect.objectContaining({ take: 100 }));
  });
});

describe('MessagingService introductions',()=>{const db:any={user:{findUniqueOrThrow:jest.fn()},block:{findFirst:jest.fn()},conversation:{findFirst:jest.fn(),create:jest.fn(),findUnique:jest.fn(),updateMany:jest.fn()},conversationMember:{findMany:jest.fn()},message:{count:jest.fn(),create:jest.fn()},like:{findUnique:jest.fn()}};const service=new MessagingService(db);beforeEach(()=>{jest.clearAllMocks();db.user.findUniqueOrThrow.mockResolvedValue({id:'a',plan:'FREE'});db.block.findFirst.mockResolvedValue(null);db.conversation.findFirst.mockResolvedValue(null);db.conversation.create.mockResolvedValue({id:'c1',status:'PRE_MATCH',initiatorId:'a'});db.message.count.mockResolvedValue(0);db.message.create.mockResolvedValue({id:'m1'});});it('allows one controlled introduction before match',async()=>{await expect(service.createIntroduction('a','b','Bonjour Marie')).resolves.toEqual({id:'m1'});expect(db.conversation.create).toHaveBeenCalled();});it('masks coordinates for free users instead of blocking the whole message',async()=>{db.conversationMember.findMany.mockResolvedValue([{userId:'a'},{userId:'b'}]);db.conversation.findUnique.mockResolvedValue({id:'c1',status:'OPEN',initiatorId:null});db.message.create.mockResolvedValue({id:'m2'});const r=await service.send('a',{conversationId:'c1',type:'TEXT',body:'Mon WhatsApp est +243811234567'} as any);expect(r).toEqual({id:'m2'});expect(db.message.create).toHaveBeenCalledWith(expect.objectContaining({data:expect.objectContaining({body:expect.stringContaining('[numéro masqué]')})}));});});
