import { IsEnum, IsOptional, IsString, Length, MaxLength, MinLength } from 'class-validator';
import { MessageType } from '@prisma/client';

export class CreateConversationDto {
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  userId!: string;
}

export class SendMessageDto {
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  conversationId!: string;

  @IsEnum(MessageType)
  type!: MessageType;

  @IsOptional()
  @IsString()
  @MaxLength(5000)
  body?: string;

  @IsOptional()
  @IsString()
  @MaxLength(2048)
  mediaUrl?: string;
}

export class UserIdParamDto {
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  userId!: string;
}

export class ConversationIdParamDto {
  @IsString()
  @MinLength(1)
  @MaxLength(64)
  id!: string;
}

export class HistoryQueryDto {
  @IsOptional()
  @IsString()
  @Length(1, 3)
  limit?: string;
}
