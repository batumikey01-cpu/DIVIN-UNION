import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { JwtGuard } from '../auth/jwt.guard';
import { MessagingService } from './messaging.service';
import { ConversationIdParamDto, CreateConversationDto, HistoryQueryDto, SendMessageDto, UserIdParamDto } from './messaging.dto';

@Controller('messaging')
@UseGuards(JwtGuard)
export class MessagingController {
  constructor(private readonly messaging: MessagingService) {}

  @Post('introductions')
  introduction(@Req() request: any, @Body() body: { userId: string; body: string }) { return this.messaging.createIntroduction(request.user.sub || request.user.id, body.userId, body.body); }

  @Post('conversations')
  create(@Req() request: any, @Body() body: CreateConversationDto) {
    return this.messaging.createConversation(request.user.sub || request.user.id, body.userId);
  }

  @Get('conversations/with/:userId/messages')
  history(@Req() request: any, @Param() params: UserIdParamDto, @Query() query: HistoryQueryDto) {
    const limit = query.limit ? Number(query.limit) : 50;
    return this.messaging.conversationHistory(request.user.sub || request.user.id, params.userId, limit);
  }

  @Get('conversations/:id/messages')
  messages(@Req() request: any, @Param() params: ConversationIdParamDto) {
    return this.messaging.messages(request.user.sub || request.user.id, params.id);
  }

  @Post('messages')
  send(@Req() request: any, @Body() body: SendMessageDto) {
    return this.messaging.send(request.user.sub || request.user.id, body);
  }
}
