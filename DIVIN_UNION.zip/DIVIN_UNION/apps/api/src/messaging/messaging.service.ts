import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { ConversationStatus, Plan } from '@prisma/client';
import { PrismaService } from '../common/prisma.service';
import { SendMessageDto } from './messaging.dto';

const PHONE = /(?:\+?\d[\d\s().-]{7,}\d)|(?:\b(?:zero|un|deux|trois|quatre|cinq|six|sept|huit|neuf)(?:[\s-]+(?:zero|un|deux|trois|quatre|cinq|six|sept|huit|neuf)){5,}\b)/i;
const SOCIAL = /(whats?\s*app|w\s*a|telegram|instagram|insta|snap(?:chat)?|facebook|tiktok|mon\s+wa|contacte[- ]?moi|e[- ]?mail|gmail|@)/i;
const URL = /https?:\/\/[^\s]+|www\.[^\s]+/i;
const PHONE_MASK = /(?:\+?\d[\d\s().-]{7,}\d)|(?:\b(?:zero|un|deux|trois|quatre|cinq|six|sept|huit|neuf)(?:[\s-]+(?:zero|un|deux|trois|quatre|cinq|six|sept|huit|neuf)){5,}\b)/gi;
const SOCIAL_MASK = /(whats?\s*app|w\s*a|telegram|instagram|insta|snap(?:chat)?|facebook|tiktok|mon\s+wa|contacte[- ]?moi|e[- ]?mail|gmail|@)/gi;
const URL_MASK = /https?:\/\/[^\s]+|www\.[^\s]+/gi;

@Injectable()
export class MessagingService {
  constructor(private readonly db: PrismaService) {}

  private unsafe(text: string) {
    return PHONE.test(text) || SOCIAL.test(text) || URL.test(text);
  }

  /** Free-plan anti-circumvention filter. Premium messages are never masked. */
  private maskCoordinates(text: string) {
    return text
      .replace(PHONE_MASK, '[numéro masqué]')
      .replace(SOCIAL_MASK, '[contact externe masqué]')
      .replace(URL_MASK, '[lien masqué]')
      .replace(/\s{2,}/g, ' ')
      .trim();
  }

  private async members(conversationId: string) {
    return this.db.conversationMember.findMany({ where: { conversationId }, select: { userId: true } });
  }

  private async dailyFreeMessageCount(senderId: string) {
    const start = new Date();
    start.setUTCHours(0, 0, 0, 0);
    return this.db.message.count({ where: { senderId, createdAt: { gte: start }, blocked: false } });
  }

  async createIntroduction(senderId: string, otherId: string, body: string) {
    const sender = await this.db.user.findUniqueOrThrow({ where: { id: senderId } });
    if (senderId === otherId) throw new BadRequestException('Vous ne pouvez pas vous contacter vous-même.');
    if (!body?.trim()) throw new BadRequestException('Une introduction ne peut pas être vide.');

    if (sender.plan === Plan.FREE && await this.dailyFreeMessageCount(senderId) >= 5) {
      throw new ForbiddenException('Limite gratuite de 5 messages par jour atteinte.');
    }

    const blocked = await this.db.block.findFirst({
      where: { OR: [{ blockerId: senderId, blockedId: otherId }, { blockerId: otherId, blockedId: senderId }] },
    });
    if (blocked) throw new ForbiddenException('Cette interaction est bloquée.');

    const safeBody = sender.plan === Plan.FREE && this.unsafe(body) ? this.maskCoordinates(body) : body.trim();
    if (!safeBody) throw new BadRequestException('Une introduction ne peut pas être vide.');

    let conversation = await this.db.conversation.findFirst({
      where: {
        AND: [
          { members: { some: { userId: senderId } } },
          { members: { some: { userId: otherId } } },
          { members: { every: { userId: { in: [senderId, otherId] } } } },
        ],
      },
    });

    if (!conversation) {
      conversation = await this.db.conversation.create({
        data: {
          status: ConversationStatus.PRE_MATCH,
          initiatorId: senderId,
          members: { create: [{ userId: senderId }, { userId: otherId }] },
        },
      });
    } else if (conversation.status !== ConversationStatus.PRE_MATCH) {
      throw new BadRequestException('Une conversation est déjà ouverte.');
    }

    const already = await this.db.message.count({ where: { conversationId: conversation.id, senderId, isIntroduction: true } });
    if (already > 0) throw new ForbiddenException('Vous avez déjà envoyé une introduction en attente de réponse.');

    return this.db.message.create({
      data: {
        conversationId: conversation.id,
        senderId,
        receiverId: otherId,
        type: 'TEXT',
        body: safeBody.slice(0, 2000),
        isIntroduction: true,
      },
    });
  }

  async send(senderId: string, body: SendMessageDto) {
    const user = await this.db.user.findUniqueOrThrow({ where: { id: senderId } });
    if (!['TEXT', 'IMAGE', 'AUDIO'].includes(body.type)) throw new BadRequestException('Type de message invalide');

    if (user.plan === Plan.FREE && body.type !== 'TEXT') {
      throw new ForbiddenException('Photos et vocaux réservés aux abonnés.');
    }
    if (user.plan === Plan.FREE && await this.dailyFreeMessageCount(senderId) >= 5) {
      throw new ForbiddenException('Limite gratuite de 5 messages par jour atteinte.');
    }

    const members = await this.members(body.conversationId);
    if (!members.some((m) => m.userId === senderId)) throw new ForbiddenException('Vous ne participez pas à cette conversation.');
    const receiverId = members.find((member) => member.userId !== senderId)?.userId;

    if (receiverId) {
      const blocked = await this.db.block.findFirst({
        where: { OR: [{ blockerId: senderId, blockedId: receiverId }, { blockerId: receiverId, blockedId: senderId }] },
      });
      if (blocked) throw new ForbiddenException('Cette interaction est bloquée.');
    }

    const conversation = await this.db.conversation.findUnique({ where: { id: body.conversationId } });
    if (!conversation) throw new BadRequestException('Conversation introuvable.');

    if (conversation.status === ConversationStatus.PRE_MATCH) {
      // Only the recipient of the introduction may reply and open the conversation.
      if (conversation.initiatorId !== receiverId) throw new ForbiddenException('Cette introduction est en attente de réponse.');
      const updated = await this.db.conversation.updateMany({
        where: { id: conversation.id, status: ConversationStatus.PRE_MATCH },
        data: { status: ConversationStatus.OPEN, openedAt: new Date() },
      });
      if (updated.count !== 1) throw new ForbiddenException('La conversation a déjà été ouverte.');
    }

    let mediaAssetId: string | undefined;
    if (body.mediaUrl) {
      const asset = await this.db.mediaAsset.findFirst({ where: { id: body.mediaUrl, userId: senderId, status: 'APPROVED' } });
      if (!asset) throw new ForbiddenException('Média non autorisé.');
      mediaAssetId = asset.id;
    }

    const safeBody = body.type === 'TEXT' && body.body && user.plan === Plan.FREE && this.unsafe(body.body)
      ? this.maskCoordinates(body.body)
      : body.body;

    return this.db.message.create({
      data: {
        conversationId: body.conversationId,
        senderId,
        receiverId,
        type: body.type,
        body: safeBody,
        mediaUrl: body.mediaUrl,
        mediaAssetId,
      },
    });
  }

  async createConversation(userId: string, otherId: string) {
    if (userId === otherId) throw new BadRequestException();
    const blocked = await this.db.block.findFirst({ where: { OR: [{ blockerId: userId, blockedId: otherId }, { blockerId: otherId, blockedId: userId }] } });
    if (blocked) throw new ForbiddenException('Cette interaction est bloquée.');

    const existing = await this.db.conversation.findFirst({
      where: {
        AND: [
          { members: { some: { userId } } },
          { members: { some: { userId: otherId } } },
          { members: { every: { userId: { in: [userId, otherId] } } } },
        ],
      },
    });
    if (existing) return existing;

    throw new ForbiddenException('Une introduction doit être envoyée avant de pouvoir ouvrir cette conversation.');
  }

  async conversationHistory(userA: string, userB: string, limit = 50) {
    if (userA === userB) throw new BadRequestException();
    const c = await this.db.conversation.findFirst({
      where: {
        AND: [
          { members: { some: { userId: userA } } },
          { members: { some: { userId: userB } } },
          { members: { every: { userId: { in: [userA, userB] } } } },
        ],
      },
      select: { id: true, status: true },
    });
    if (!c) return [];
    return this.db.message.findMany({ where: { conversationId: c.id }, orderBy: { createdAt: 'asc' }, take: Math.min(Math.max(Math.trunc(limit) || 50, 1), 100) });
  }

  async messages(userId: string, conversationId: string) {
    const member = await this.db.conversationMember.findUnique({ where: { conversationId_userId: { conversationId, userId } } });
    if (!member) throw new ForbiddenException();
    return this.db.message.findMany({ where: { conversationId }, orderBy: { createdAt: 'asc' }, take: 100 });
  }
}
