import { Test, TestingModule } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { MessagingGateway } from './messaging.gateway';
import { MessagingService } from './messaging.service';
import { PrismaService } from '../common/prisma.service';
import { ModerationService } from '../moderation/moderation.service';
import { NotificationService } from '../notifications/notification.service';

describe('MessagingGateway', () => {
  let gateway: MessagingGateway;
  let prisma: any;
  let moderationService: any;
  let messagingService: any;
  let notificationService: any;
  const room = { emit: jest.fn() };
  const mockServer = { to: jest.fn(() => room) };
  const mockSocket: any = { data: { userId: 'u1' }, emit: jest.fn() };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MessagingGateway,
        { provide: JwtService, useValue: { verifyAsync: jest.fn() } },
        { provide: PrismaService, useValue: { conversationMember: { findMany: jest.fn() }, user: { findFirst: jest.fn(), findUnique: jest.fn() } } },
        { provide: MessagingService, useValue: { send: jest.fn() } },
        { provide: ModerationService, useValue: { isBlocked: jest.fn() } },
        { provide: NotificationService, useValue: { notifyNewMessage: jest.fn().mockResolvedValue({ sent: false }) } },
      ],
    }).compile();

    gateway = module.get<MessagingGateway>(MessagingGateway);
    prisma = module.get(PrismaService);
    moderationService = module.get(ModerationService);
    messagingService = module.get(MessagingService);
    notificationService = module.get(NotificationService);
    gateway.server = mockServer as any;
    prisma.conversationMember.findMany.mockResolvedValue([{ userId: 'u1' }, { userId: 'u2' }]);
    prisma.user.findUnique.mockResolvedValue({ firstName: 'Jean' });
  });

  afterEach(() => jest.clearAllMocks());

  it('should be defined', () => {
    expect(gateway).toBeDefined();
  });

  it('should block transmission when users are blocked', async () => {
    moderationService.isBlocked.mockResolvedValue(true);

    const result = await gateway.sendMessage({ conversationId: 'c1', type: 'TEXT', body: 'Hello' }, mockSocket);

    expect(result).toEqual({ status: 'blocked' });
    expect(moderationService.isBlocked).toHaveBeenCalledWith('u1', 'u2');
    expect(mockSocket.emit).toHaveBeenCalledWith('error_message', { message: 'Communication bloquée entre ces utilisateurs.' });
    expect(messagingService.send).not.toHaveBeenCalled();
    expect(room.emit).not.toHaveBeenCalled();
  });

  it('should send and broadcast only to the conversation room when not blocked', async () => {
    moderationService.isBlocked.mockResolvedValue(false);
    const savedMessage = { id: 'm1', conversationId: 'c1', senderId: 'u1', receiverId: 'u2', body: 'Hello' };
    messagingService.send.mockResolvedValue(savedMessage);

    const result = await gateway.sendMessage({ conversationId: 'c1', type: 'TEXT', body: 'Hello' }, mockSocket);

    expect(result).toEqual({ status: 'sent', data: savedMessage });
    expect(messagingService.send).toHaveBeenCalledWith('u1', { conversationId: 'c1', type: 'TEXT', body: 'Hello' });
    expect(mockServer.to).toHaveBeenCalledWith('conversation:c1');
    expect(room.emit).toHaveBeenCalledWith('new_message', savedMessage);
    expect(mockSocket.emit).toHaveBeenCalledWith('new_message', savedMessage);
    expect(notificationService.notifyNewMessage).toHaveBeenCalledWith('u2', 'Jean', 'Hello');
  });
});
