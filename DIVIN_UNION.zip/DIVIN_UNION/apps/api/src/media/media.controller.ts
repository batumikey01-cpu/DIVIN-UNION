import { Body, Controller, Delete, Get, Param, Patch, Post, Req, Res, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import type { Response } from 'express';
import { JwtGuard } from '../auth/jwt.guard';
import { MediaService } from './media.service';
import { ReorderPhotosDto } from './media-gallery.dto';

@Controller('media')
@UseGuards(JwtGuard)
export class MediaController {
  constructor(private readonly media: MediaService) {}


  @Get('photos')
  listPhotos(@Req() request: any) {
    return this.media.listOwnedPhotos(request.user.sub || request.user.id);
  }

  @Patch('photos/:id/primary')
  setPrimary(@Req() request: any, @Param('id') id: string) {
    return this.media.setPrimary(request.user.sub || request.user.id, id);
  }

  @Patch('photos/reorder')
  reorder(@Req() request: any, @Body() body: ReorderPhotosDto) {
    return this.media.reorderPhotos(request.user.sub || request.user.id, body.photoIds);
  }

  @Post('message-media')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 10 * 1024 * 1024, files: 1 } }))
  uploadMessageMedia(@Req() request: any, @UploadedFile() file: any) { return this.media.uploadMessageMedia(request.user.sub || request.user.id, file); }

  @Post('photos')
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: 10 * 1024 * 1024, files: 1 } }))
  uploadPhoto(@Req() request: any, @UploadedFile() file: any) {
    return this.media.uploadImage(request.user.sub || request.user.id, file);
  }

  @Get('assets/:id')
  async getAsset(@Req() request: any, @Param('id') id: string, @Res() response: Response) {
    const asset = await this.media.getApprovedForUser(id, request.user.sub || request.user.id);
    response.setHeader('Content-Type', asset.contentType);
    response.setHeader('Cache-Control', 'private, max-age=300');
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.send(asset.buffer);
  }

  @Delete('photos/:id')
  deletePhoto(@Req() request: any, @Param('id') id: string) {
    return this.media.deleteOwnedPhoto(request.user.sub || request.user.id, id);
  }

  @Delete('assets/:id')
  delete(@Req() request: any, @Param('id') id: string) {
    return this.media.deleteOwned(request.user.sub || request.user.id, id);
  }
}
