import { IsIn, IsInt, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';

export const MEDIA_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'audio/mpeg', 'audio/wav', 'audio/ogg'] as const;
export type MediaContentType = typeof MEDIA_TYPES[number];

export class CreateMediaUploadDto {
  @IsIn(MEDIA_TYPES)
  contentType!: MediaContentType;

  @IsInt()
  @Min(1)
  @Max(10 * 1024 * 1024)
  sizeBytes!: number;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  extension?: string;
}
