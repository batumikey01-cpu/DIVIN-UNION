import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { RolesGuard } from '../common/roles.guard';
import { PrismaModule } from '../common/prisma.module';
import { InMemoryStorageProvider } from '../providers/in-memory-storage.provider';
import { MediaController } from './media.controller';
import { MediaAdminController } from './media-admin.controller';
import { LocalStorageProvider } from '../providers/local-storage.provider';
import { MediaService } from './media.service';

@Module({
  imports: [AuthModule, PrismaModule],
  controllers: [MediaController, MediaAdminController],
  providers: [MediaService, RolesGuard, { provide: 'STORAGE_PROVIDER', useClass: process.env.NODE_ENV === 'test' ? InMemoryStorageProvider : LocalStorageProvider }, { provide: 'StorageProvider', useExisting: 'STORAGE_PROVIDER' }],
  exports: [MediaService],
})
export class MediaModule {}
