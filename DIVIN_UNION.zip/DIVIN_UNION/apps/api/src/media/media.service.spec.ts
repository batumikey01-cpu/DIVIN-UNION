import { MediaStatus } from '@prisma/client';
import { InMemoryStorageProvider } from '../providers/in-memory-storage.provider';
import { MediaService } from './media.service';

describe('MediaService', () => {
  const db: any = { mediaAsset: { create: jest.fn(), findFirst: jest.fn(), update: jest.fn(), updateMany: jest.fn() } };
  const storage = new InMemoryStorageProvider();
  const service = new MediaService(db, storage);

  beforeEach(() => jest.clearAllMocks());

  it('creates an owned expiring upload intent with an unguessable key', async () => {
    db.mediaAsset.create.mockResolvedValue({ id: 'm1' });
    const result = await service.createUploadIntent('u1', { contentType: 'image/jpeg', sizeBytes: 1000 });
    expect(result.status).toBe(MediaStatus.PENDING);
    expect(result.objectKey).toMatch(/^users\/u1\//);
    expect(db.mediaAsset.create).toHaveBeenCalledWith(expect.objectContaining({ data: expect.objectContaining({ userId: 'u1', status: MediaStatus.PENDING }) }));
  });

  it('deletes only an owned asset and records the physical deletion', async () => {
    db.mediaAsset.findFirst.mockResolvedValue({ id: 'm1', objectKey: 'users/u1/a' });
    db.mediaAsset.update.mockResolvedValue({});
    await expect(service.deleteOwned('u1', 'users/u1/a')).resolves.toEqual({ deleted: true });
    expect(storage.deleted).toContain('users/u1/a');
    expect(db.mediaAsset.update).toHaveBeenCalledWith({ where: { id: 'm1' }, data: { status: MediaStatus.DELETED } });
  });
});

