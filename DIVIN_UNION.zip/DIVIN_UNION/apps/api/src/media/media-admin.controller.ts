import { Body, Controller, Get, Param, Patch, Query, Req, Res, UseGuards } from '@nestjs/common';
import type { Response } from 'express';
import { Role } from '@prisma/client';
import { JwtGuard } from '../auth/jwt.guard';
import { Roles, RolesGuard } from '../common/roles.guard';
import { MediaService } from './media.service';

@Controller('admin/media')
@UseGuards(JwtGuard, RolesGuard)
export class MediaAdminController {
  constructor(private readonly media: MediaService) {}

  @Get('pending')
  @Roles(Role.MODERATOR, Role.SUPER_ADMIN)
  pending(@Query('limit') limit?: string) { return this.media.pending(Number(limit || 50)); }

  @Get(':id/preview')
  @Roles(Role.MODERATOR, Role.SUPER_ADMIN)
  async preview(@Param('id') id: string, @Res() response: Response) { const asset = await this.media.getAssetForModerator(id); response.setHeader('Content-Type', asset.contentType); response.setHeader('Cache-Control', 'private, no-store'); response.setHeader('X-Content-Type-Options', 'nosniff'); response.send(asset.buffer); }

  @Patch(':id/approve')
  @Roles(Role.MODERATOR, Role.SUPER_ADMIN)
  approve(@Req() request: any, @Param('id') id: string) { return this.media.approve(id, request.user.sub || request.user.id); }

  @Patch(':id/reject')
  @Roles(Role.MODERATOR, Role.SUPER_ADMIN)
  reject(@Req() request: any, @Param('id') id: string, @Body() body: { reason?: string }) { return this.media.reject(id, request.user.sub || request.user.id, body?.reason); }
}
