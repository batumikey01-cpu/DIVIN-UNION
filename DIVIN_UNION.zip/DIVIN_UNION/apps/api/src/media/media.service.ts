import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { createHash, randomUUID } from 'node:crypto';
import { MediaStatus } from '@prisma/client';
import { PrismaService } from '../common/prisma.service';
import { StorageProvider } from '../providers/provider.types';
import { MEDIA_TYPES } from './media.dto';

const MAX_IMAGE_BYTES = 10 * 1024 * 1024;
const MAX_DIMENSION = 6000;
const MIN_DIMENSION = 200;

function dimensions(buffer: Buffer, contentType: string) {
  if (contentType === 'image/png') {
    if (buffer.length < 24 || buffer.toString('ascii', 0, 8) !== '\x89PNG\r\n\x1a\n') return null;
    return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
  }
  if (contentType === 'image/webp') {
    if (buffer.length < 30 || buffer.toString('ascii', 0, 4) !== 'RIFF' || buffer.toString('ascii', 8, 12) !== 'WEBP') return null;
    const subtype = buffer.toString('ascii', 12, 16);
    if (subtype === 'VP8X') return { width: 1 + buffer.readUIntLE(24, 3), height: 1 + buffer.readUIntLE(27, 3) };
    return { width: MIN_DIMENSION, height: MIN_DIMENSION };
  }
  if (contentType === 'image/jpeg') {
    if (buffer.length < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8) return null;
    let offset = 2;
    while (offset + 9 < buffer.length) {
      if (buffer[offset] !== 0xff) { offset++; continue; }
      const marker = buffer[offset + 1]; offset += 2;
      if (marker === 0xd8 || marker === 0xd9) continue;
      if (offset + 2 > buffer.length) return null;
      const length = buffer.readUInt16BE(offset);
      if (length < 2 || offset + length > buffer.length) return null;
      if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
        return { height: buffer.readUInt16BE(offset + 3), width: buffer.readUInt16BE(offset + 5) };
      }
      offset += length;
    }
  }
  return null;
}

function validMagic(buffer: Buffer, contentType: string) {
  if (contentType === 'image/jpeg') return buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  if (contentType === 'image/png') return buffer.length >= 8 && buffer.toString('hex', 0, 8) === '89504e470d0a1a0a';
  if (contentType === 'image/webp') return buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP';
  return false;
}

@Injectable()
export class MediaService {
  constructor(private readonly db: PrismaService, @Inject('STORAGE_PROVIDER') private readonly storage: StorageProvider) {}

  async createUploadIntent(userId: string, dto: { contentType: string; sizeBytes: number }) {
    if (dto.sizeBytes > MAX_IMAGE_BYTES) throw new BadRequestException('Fichier trop volumineux.');
    const objectKey = `users/${userId}/${randomUUID()}`;
    const expiresAt = new Date(Date.now() + 15 * 60_000);
    const intent = await this.storage.createUploadIntent({ userId, objectKey, contentType: dto.contentType, maxBytes: dto.sizeBytes });
    await this.db.mediaAsset.create({ data: { userId, objectKey, contentType: dto.contentType, sizeBytes: dto.sizeBytes, status: MediaStatus.PENDING, expiresAt } });
    return { ...intent, objectKey, expiresAt, status: MediaStatus.PENDING };
  }

  async markApproved(userId: string, objectKey: string) {
    return this.db.mediaAsset.updateMany({ where: { userId, objectKey, status: MediaStatus.PENDING, expiresAt: { gt: new Date() } }, data: { status: MediaStatus.APPROVED } });
  }

  async uploadMessageMedia(userId: string, file: any) {
    if (!file?.buffer) throw new BadRequestException('Un média est requis.');
    const allowed = ['image/jpeg','image/png','image/webp','audio/mpeg','audio/wav','audio/ogg'];
    if (!allowed.includes(file.mimetype)) throw new BadRequestException('Format média non autorisé.');
    if (file.size < 1 || file.size > MAX_IMAGE_BYTES) throw new BadRequestException('Média trop volumineux ou vide.');
    if (file.mimetype.startsWith('image/') && !validMagic(file.buffer,file.mimetype)) throw new BadRequestException('Contenu image invalide.');
    if (file.mimetype === 'audio/mpeg' && !(file.buffer.subarray(0,3).toString('ascii') === 'ID3' || file.buffer[0] === 0xff)) throw new BadRequestException('Audio MP3 invalide.');
    if (file.mimetype === 'audio/wav' && file.buffer.toString('ascii',0,4) !== 'RIFF') throw new BadRequestException('Audio WAV invalide.');
    if (file.mimetype === 'audio/ogg' && file.buffer.toString('ascii',0,4) !== 'OggS') throw new BadRequestException('Audio OGG invalide.');
    const objectKey=`users/${userId}/messages/${randomUUID()}`; const hash=createHash('sha256').update(file.buffer).digest('hex'); const expiresAt=new Date(Date.now()+7*24*60*60_000);
    if(!this.storage.putObject) throw new BadRequestException('Stockage non configuré.'); await this.storage.putObject(objectKey,file.buffer);
    const asset=await this.db.mediaAsset.create({data:{userId,objectKey,contentType:file.mimetype,sizeBytes:file.size,status:MediaStatus.APPROVED,expiresAt,sha256:hash}});
    return {id:asset.id,status:asset.status,contentType:asset.contentType};
  }

  async uploadImage(userId: string, file: any) {
    if (!file?.buffer) throw new BadRequestException('Une image est requise.');
    if (!MEDIA_TYPES.includes(file.mimetype)) throw new BadRequestException('Format d’image non autorisé.');
    if (file.size < 1 || file.size > MAX_IMAGE_BYTES) throw new BadRequestException('Image trop grande ou vide.');
    if (!validMagic(file.buffer, file.mimetype)) throw new BadRequestException('Le contenu du fichier ne correspond pas à son type.');
    const size = dimensions(file.buffer, file.mimetype);
    if (!size || size.width < MIN_DIMENSION || size.height < MIN_DIMENSION || size.width > MAX_DIMENSION || size.height > MAX_DIMENSION) {
      throw new BadRequestException(`Les dimensions doivent être comprises entre ${MIN_DIMENSION}px et ${MAX_DIMENSION}px.`);
    }

    const objectKey = `users/${userId}/${randomUUID()}`;
    const hash = createHash('sha256').update(file.buffer).digest('hex');
    const expiresAt = new Date(Date.now() + 24 * 60 * 60_000);
    if (!this.storage.putObject) throw new BadRequestException('Le stockage de fichiers n’est pas configuré.');
    await this.storage.putObject(objectKey, file.buffer);
    const asset = await this.db.mediaAsset.create({ data: { userId, objectKey, contentType: file.mimetype, sizeBytes: file.size, status: MediaStatus.PENDING, expiresAt, sha256: hash, width: size.width, height: size.height } });
    return { id: asset.id, status: asset.status, objectKey: asset.objectKey, width: size.width, height: size.height };
  }


  async listOwnedPhotos(userId: string) {
    return this.db.photo.findMany({
      where: { userId, mediaAsset: { status: MediaStatus.APPROVED, expiresAt: { gt: new Date() } } },
      orderBy: { sortOrder: 'asc' },
      select: { id: true, url: true, sortOrder: true, createdAt: true, mediaAssetId: true },
    });
  }

  async setPrimary(userId: string, photoId: string) {
    const photo = await this.db.photo.findFirst({ where: { id: photoId, userId, mediaAsset: { status: MediaStatus.APPROVED, expiresAt: { gt: new Date() } } } });
    if (!photo) throw new NotFoundException('Photo introuvable.');
    await this.db.$transaction(async (tx: any) => {
      const others = await tx.photo.findMany({ where: { userId }, orderBy: { sortOrder: 'asc' }, select: { id: true } });
      const ids = [photoId, ...others.map((p: any) => p.id).filter((id: string) => id !== photoId)];
      for (let i = 0; i < ids.length; i++) await tx.photo.update({ where: { id: ids[i] }, data: { sortOrder: i } });
      await tx.user.update({ where: { id: userId }, data: { profilePhotoUrl: `/media/assets/${photo.mediaAssetId}` } });
    });
    return { ok: true, photoId };
  }

  async reorderPhotos(userId: string, photoIds: string[]) {
    const photos = await this.db.photo.findMany({ where: { userId, mediaAsset: { status: MediaStatus.APPROVED, expiresAt: { gt: new Date() } } }, select: { id: true, mediaAssetId: true } });
    const known = new Set(photos.map((p) => p.id));
    if (photoIds.length !== photos.length || new Set(photoIds).size !== photoIds.length || photoIds.some((id) => !known.has(id))) {
      throw new BadRequestException('La liste des photos est invalide.');
    }
    await this.db.$transaction(async (tx: any) => {
      for (let i = 0; i < photoIds.length; i++) await tx.photo.update({ where: { id: photoIds[i] }, data: { sortOrder: i } });
      const first = photos.find((p) => p.id === photoIds[0]);
      await tx.user.update({ where: { id: userId }, data: { profilePhotoUrl: first?.mediaAssetId ? `/media/assets/${first.mediaAssetId}` : '' } });
    });
    return this.listOwnedPhotos(userId);
  }

  async approve(assetId: string, moderatorId: string) {
    const asset = await this.db.mediaAsset.findUnique({ where: { id: assetId } });
    if (!asset || asset.status !== MediaStatus.PENDING) throw new NotFoundException('Photo à modérer introuvable.');
    const count = await this.db.mediaAsset.updateMany({ where: { id: assetId, status: MediaStatus.PENDING, expiresAt: { gt: new Date() } }, data: { status: MediaStatus.APPROVED } });
    if (count.count !== 1) throw new BadRequestException('La photo a déjà été traitée.');
    let photo:any = null;
    if (asset.contentType.startsWith('image/')) {
      photo = await this.db.photo.create({ data: { userId: asset.userId, url: `/media/assets/${asset.id}`, sortOrder: 0, mediaAssetId: asset.id } });
      await this.db.user.update({ where: { id: asset.userId }, data: { profilePhotoUrl: photo.url } });
    }
    await this.db.auditLog.create({ data: { actorId: moderatorId, action: 'MEDIA_APPROVED', targetType: 'MediaAsset', targetId: asset.id } });
    return photo || { id: asset.id, status: MediaStatus.APPROVED, contentType: asset.contentType };
  }

  async reject(assetId: string, moderatorId: string, reason?: string) {
    const asset = await this.db.mediaAsset.findUnique({ where: { id: assetId } });
    if (!asset || asset.status !== MediaStatus.PENDING) throw new NotFoundException('Photo à modérer introuvable.');
    await this.db.mediaAsset.update({ where: { id: assetId }, data: { status: MediaStatus.REJECTED } });
    await this.storage.deleteObject(asset.objectKey);
    await this.db.auditLog.create({ data: { actorId: moderatorId, action: 'MEDIA_REJECTED', targetType: 'MediaAsset', targetId: asset.id, metadata: { reason: reason?.slice(0, 500) || null } } });
    return { rejected: true };
  }

  async pending(limit = 50) {
    return this.db.mediaAsset.findMany({ where: { status: MediaStatus.PENDING }, orderBy: { createdAt: 'asc' }, take: Math.min(Math.max(limit, 1), 100), select: { id: true, userId: true, objectKey: true, contentType: true, sizeBytes: true, createdAt: true, expiresAt: true } });
  }

  async getAssetForModerator(assetId: string) {
    const asset = await this.db.mediaAsset.findUnique({ where: { id: assetId }, select: { objectKey: true, contentType: true, status: true } });
    if (!asset || (asset.status !== MediaStatus.PENDING && asset.status !== MediaStatus.APPROVED)) throw new NotFoundException('Photo introuvable.');
    if (!this.storage.getObject) throw new NotFoundException('Stockage non configuré.');
    return { buffer: await this.storage.getObject(asset.objectKey), contentType: asset.contentType };
  }

  async getApprovedForUser(assetId:string,userId:string){
    const asset=await this.db.mediaAsset.findUnique({where:{id:assetId},include:{message:{include:{conversation:{include:{members:true}}}}}});
    if(!asset||asset.status!==MediaStatus.APPROVED||asset.expiresAt<=new Date())throw new NotFoundException('Média introuvable.');
    if(asset.objectKey.includes('/messages/') && !asset.message?.conversation.members.some(m=>m.userId===userId)) throw new NotFoundException('Média introuvable.');
    if(!this.storage.getObject)throw new NotFoundException('Stockage non configuré.'); return {buffer:await this.storage.getObject(asset.objectKey),contentType:asset.contentType};
  }

  async getApproved(assetId: string) {
    const asset = await this.db.mediaAsset.findUnique({ where: { id: assetId }, select: { objectKey: true, contentType: true, status: true, expiresAt: true } });
    if (!asset || asset.status !== MediaStatus.APPROVED || asset.expiresAt <= new Date()) throw new NotFoundException('Photo introuvable.');
    if (!this.storage.getObject) throw new NotFoundException('Stockage non configuré.');
    return { buffer: await this.storage.getObject(asset.objectKey), contentType: asset.contentType };
  }

  async deleteOwnedPhoto(userId: string, photoId: string) {
    const photo = await this.db.photo.findFirst({ where: { id: photoId, userId }, include: { mediaAsset: true } });
    if (!photo?.mediaAsset) return { deleted: false };
    await this.storage.deleteObject(photo.mediaAsset.objectKey);
    await this.db.$transaction(async (tx: any) => {
      await tx.mediaAsset.update({ where: { id: photo.mediaAssetId! }, data: { status: MediaStatus.DELETED } });
      await tx.photo.delete({ where: { id: photo.id } });
      const replacement = await tx.photo.findFirst({ where: { userId }, orderBy: { sortOrder: 'asc' } });
      await tx.user.update({ where: { id: userId }, data: { profilePhotoUrl: replacement?.url || '' } });
    });
    return { deleted: true };
  }

  async deleteOwned(userId: string, assetId: string) {
    const legacy = assetId.startsWith(`users/${userId}/`);
    const asset = await this.db.mediaAsset.findFirst({ where: legacy ? { userId, objectKey: assetId, status: { not: MediaStatus.DELETED } } : { id: assetId, userId, status: { not: MediaStatus.DELETED } } });
    if (!asset) return { deleted: false };
    await this.storage.deleteObject(asset.objectKey);
    await this.db.mediaAsset.update({ where: { id: asset.id }, data: { status: MediaStatus.DELETED } });
    if (legacy || !this.db.photo) return { deleted: true };
    await this.db.photo.deleteMany({ where: { userId, url: `/media/assets/${asset.id}` } });
    const replacement = await this.db.photo.findFirst({ where: { userId }, orderBy: { sortOrder: 'asc' } });
    await this.db.user.update({ where: { id: userId }, data: { profilePhotoUrl: replacement?.url || '' } });
    return { deleted: true };
  }
}

