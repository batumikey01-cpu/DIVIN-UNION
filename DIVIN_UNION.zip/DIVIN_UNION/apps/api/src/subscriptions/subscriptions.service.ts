import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { Plan, SubscriptionStatus } from '@prisma/client';
import { PrismaService } from '../common/prisma.service';
import { PaymentProviderRegistry } from './payment-provider'; import { NotificationService } from '../notifications/notification.service';

const DEFAULT_PRICES = [
  { plan: Plan.PREMIUM, months:1, amount:4.99, currency:'USD' }, { plan:Plan.PREMIUM, months:3, amount:12, currency:'USD' }, { plan:Plan.PREMIUM, months:6, amount:23.94, currency:'USD' },
  { plan: Plan.ELITE, months:1, amount:9.99, currency:'USD' }, { plan:Plan.ELITE, months:3, amount:24, currency:'USD' }, { plan:Plan.ELITE, months:6, amount:47.94, currency:'USD' },
];

@Injectable()
export class SubscriptionsService {
  constructor(private readonly db: PrismaService, private readonly providers: PaymentProviderRegistry, private readonly notifications: NotificationService) {}
  async ensurePrices() { for (const p of DEFAULT_PRICES) await this.db.subscriptionPrice.upsert({ where:{plan_months:{plan:p.plan,months:p.months}}, update:{}, create:p }); }
  private addMonths(date: Date, months: number) { const d=new Date(date); const day=d.getUTCDate(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth()+months); const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate(); d.setUTCDate(Math.min(day,last)); return d; }
  async listPrices() { await this.ensurePrices(); return this.db.subscriptionPrice.findMany({ where:{active:true, plan:{not:Plan.FREE}}, orderBy:[{plan:'asc'},{months:'asc'}] }); }
  async listActiveProviders() { return this.db.paymentProviderConfig.findMany({ where:{active:true}, select:{id:true,name:true,driver:true,environment:true,currencies:true}, orderBy:{createdAt:'asc'} }); }
  async createCheckout(userId:string, plan:Plan, months:number, mobileMoney?:string, providerConfigId?:string) {
    if (plan===Plan.FREE || ![1,3,6].includes(months)) throw new BadRequestException('Plan ou durée invalide.');
    const user=await this.db.user.findUnique({where:{id:userId},select:{id:true,isActive:true,isDeleted:true,phone:true}}); if(!user||!user.isActive||user.isDeleted) throw new BadRequestException('Utilisateur inactif.');
    await this.ensurePrices(); const price=await this.db.subscriptionPrice.findUnique({where:{plan_months:{plan,months}}}); if(!price||!price.active) throw new BadRequestException('Tarif indisponible.');
    const reference=this.providers.newReference(); const pending=await this.db.subscription.create({data:{userId,plan,provider:'external',providerReference:reference,startsAt:new Date(),endsAt:new Date(),status:SubscriptionStatus.PENDING}});
    try {
      const result=await this.providers.checkout({userId,plan:plan as Exclude<Plan,'FREE'>,months:months as 1|3|6,amount:Number(price.amount),currency:price.currency,reference,motif:`DivinUnion ${plan} ${months} mois`,mobileMoney:mobileMoney || user.phone || '', providerConfigId});
      await this.db.paymentTransaction.create({data:{userId,subscriptionId:pending.id,providerConfigId:(await this.providers.active(providerConfigId)).id,provider:'external',reference,providerTransactionId:result.providerTransactionId,amount:price.amount,currency:price.currency,status:'PENDING',metadata:{plan,months}}});
      return {provider:result.provider,reference,plan,months,amount:price.amount,currency:price.currency,status:result.status,checkoutUrl:result.checkoutUrl||null};
    } catch(e) { await this.db.subscription.update({where:{id:pending.id},data:{status:SubscriptionStatus.CANCELED}}); throw e; }
  }
  async handleWonyaCallback(payload:any) {
    const reference=String(payload?.RefTransa||''); const status=String(payload?.StatutWonya||payload?.StatutTransa||''); if(!/^[A-Za-z0-9]{20}$/.test(reference)) throw new BadRequestException('Référence de transaction invalide.');
    const tx=await this.db.paymentTransaction.findUnique({where:{reference}}); if(!tx) return {received:true,handled:false};
    const pending=tx.subscriptionId?await this.db.subscription.findUnique({where:{id:tx.subscriptionId}}):null; if(!pending) return {received:true,handled:false};
    if (['Succes','Reçu','SUCCESS','PAID','COMPLETED'].includes(status)) {
      const verified=await this.providers.status(reference, tx.providerConfigId || undefined);
      const verifiedStatus=String(verified?.StatutWonya||verified?.StatutTransa||verified?.status||'');
      const verifiedRef=String(verified?.RefTransa||reference);
      const verifiedAmount=verified?.Montant===undefined?Number(tx.amount):Number(verified?.Montant);
      const verifiedCurrency=String(verified?.Devise||tx.currency);
      if (verifiedRef!==reference || !['Succes','Reçu','SUCCESS','PAID','COMPLETED'].includes(verifiedStatus) || verifiedAmount!==Number(tx.amount) || verifiedCurrency!==tx.currency) return {received:true,handled:false,verified:false};
      const meta=(tx.metadata||{}) as any; const months=Number(meta.months); if(![1,3,6].includes(months)) throw new BadRequestException('Durée d’abonnement invalide.'); const starts=new Date(); const ends=this.addMonths(starts,months);
      await this.db.$transaction([this.db.subscription.update({where:{id:pending.id},data:{startsAt:starts,endsAt:ends,status:SubscriptionStatus.ACTIVE}}),this.db.user.update({where:{id:tx.userId},data:{plan:pending.plan}}),this.db.paymentTransaction.update({where:{id:tx.id},data:{status:'PAID',providerTransactionId:String(payload?.Id||tx.providerTransactionId||'')}})]);
      await this.notifications.notifyPayment(tx.userId, `Votre abonnement ${pending.plan} est maintenant actif pour ${months} mois.`);
      return {received:true,handled:true};
    }
    if (['Echec','FAILED','FAILURE'].includes(status)) await this.db.$transaction([this.db.subscription.update({where:{id:pending.id},data:{status:SubscriptionStatus.CANCELED}}),this.db.paymentTransaction.update({where:{id:tx.id},data:{status:'FAILED'}})]);
    return {received:true,handled:true};
  }
  async sync(reference:string) { const tx=await this.db.paymentTransaction.findUnique({where:{reference},select:{providerConfigId:true}}); if(!tx) throw new BadRequestException('Transaction introuvable.'); const data=await this.providers.status(reference,tx.providerConfigId||undefined); return this.handleWonyaCallback({...data,RefTransa:reference}); }
}
