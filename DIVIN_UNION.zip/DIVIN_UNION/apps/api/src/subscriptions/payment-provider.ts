import { BadRequestException, Injectable } from '@nestjs/common';
import { randomBytes } from 'node:crypto';
import { Plan } from '@prisma/client';
import { PrismaService } from '../common/prisma.service';
import { decryptSecret } from './payment-crypto';

export type CheckoutInput = { userId: string; plan: Exclude<Plan,'FREE'>; months: 1|3|6; amount: number; currency: string; reference: string; motif: string; mobileMoney: string };
export type CheckoutResult = { provider: string; reference: string; providerTransactionId?: string; checkoutUrl?: string; status: string };

@Injectable()
export class PaymentProviderRegistry {
  constructor(private readonly db: PrismaService) {}
  async active(providerConfigId?: string) {
    const cfg = providerConfigId
      ? await this.db.paymentProviderConfig.findFirst({ where: { id: providerConfigId, active: true } })
      : await this.db.paymentProviderConfig.findFirst({ where: { active: true }, orderBy: { createdAt: 'asc' } });
    if (!cfg) throw new BadRequestException('Aucun fournisseur de paiement actif.');
    return cfg;
  }
  async checkout(input: CheckoutInput & { providerConfigId?: string }): Promise<CheckoutResult> {
    const cfg = await this.active(input.providerConfigId);
    if (cfg.driver !== 'wonyapay') throw new BadRequestException(`Driver de paiement non supporté: ${cfg.driver}`);
    const token = cfg.tokenEncrypted ? decryptSecret(cfg.tokenEncrypted) : '';
    if (!token || (!cfg.partnerRef && !cfg.caisseRef)) throw new BadRequestException('Configuration WonyaPay incomplète.');
    const ref = input.reference.replace(/[^A-Za-z0-9]/g, '').slice(0,20).padEnd(20,'0');
    const mobileMoney=input.mobileMoney.replace(/\D/g,'').slice(-10);
    if (!/^\d{10}$/.test(mobileMoney)) throw new BadRequestException('Le numéro Mobile Money doit contenir 10 chiffres.');
    const body: Record<string, unknown> = {
      RefPartenaire: cfg.partnerRef || cfg.caisseRef,
      RefTransa: ref,
      Montant: input.amount,
      Devise: input.currency,
      Action: 'C2B',
      MobileMoney: mobileMoney,
      Motif: input.motif,
      userId: input.userId,
      plan: input.plan,
      months: input.months,
    };
    const response = await fetch(`${cfg.baseUrl.replace(/\/$/,'')}/payment`, { method:'POST', headers:{ Authorization:`Bearer ${token}`, 'Content-Type':'application/json' }, body:JSON.stringify(body) });
    const data: any = await response.json().catch(()=>({}));
    if (!response.ok) throw new BadRequestException(data?.message || 'Le fournisseur de paiement a refusé la transaction.');
    return { provider:cfg.name, reference:ref, providerTransactionId:data?.transactionId || data?.Id, status:data?.StatutTransa || data?.status || 'pending' };
  }
  async status(reference: string, providerConfigId?: string) {
    const cfg = await this.active(providerConfigId); const token = cfg.tokenEncrypted ? decryptSecret(cfg.tokenEncrypted) : '';
    const response = await fetch(`${cfg.baseUrl.replace(/\/$/,'')}/transaction-status/status/${encodeURIComponent(reference)}`, { headers:{ Authorization:`Bearer ${token}` } });
    const data:any = await response.json().catch(()=>({}));
    if (!response.ok) throw new BadRequestException(data?.message || 'Impossible de vérifier le paiement.');
    return data;
  }
  async testConnection(id:string){const cfg=await this.db.paymentProviderConfig.findUnique({where:{id}});if(!cfg)throw new BadRequestException('Fournisseur introuvable.');if(cfg.driver!=='wonyapay')return {ok:false,reason:'DRIVER_UNSUPPORTED'};const token=cfg.tokenEncrypted?decryptSecret(cfg.tokenEncrypted):'';const r=await fetch(`${cfg.baseUrl.replace(/\/$/,'')}/transaction-status/status/00000000000000000000`,{headers:{Authorization:`Bearer ${token}`}}).catch(()=>null);return {ok:Boolean(r),status:r?.status||null};}
  newReference() { return randomBytes(15).toString('base64url').replace(/[^A-Za-z0-9]/g,'').slice(0,20).padEnd(20,'X'); }
}
