import { Body, Controller, Get, Headers, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtGuard } from '../auth/jwt.guard';
import { SubscriptionsService } from './subscriptions.service';
import { CheckoutDto, PaymentWebhookDto } from './subscriptions.dto';
@Controller('subscriptions')
export class SubscriptionsController { constructor(private readonly subscriptions:SubscriptionsService){}
 @Get('prices') prices(){return this.subscriptions.listPrices();}
 @Get('providers') @UseGuards(JwtGuard) providers(){return this.subscriptions.listActiveProviders();}
 @Post('checkout') @UseGuards(JwtGuard) checkout(@Req() r:any,@Body() b:CheckoutDto){return this.subscriptions.createCheckout(r.user.sub,b.plan,b.months,b.mobileMoney,b.providerConfigId);}
 @Post('webhook') webhook(@Headers('x-payment-signature') _sig:string|undefined,@Body() p:PaymentWebhookDto){return this.subscriptions.handleWonyaCallback(p);}
 @Post('sync/:reference') @UseGuards(JwtGuard) sync(@Param('reference') ref:string){return this.subscriptions.sync(ref);}
}
