import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';

function key() {
  const raw = process.env.PAYMENT_CONFIG_ENCRYPTION_KEY;
  if (!raw) throw new Error('PAYMENT_CONFIG_ENCRYPTION_KEY est requis pour les secrets de paiement.');
  const b = Buffer.from(raw, 'base64');
  if (b.length !== 32) throw new Error('PAYMENT_CONFIG_ENCRYPTION_KEY doit être une clé base64 de 32 octets.');
  return b;
}
export function encryptSecret(value: string) {
  const iv = randomBytes(12); const cipher = createCipheriv('aes-256-gcm', key(), iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return `${iv.toString('base64')}.${cipher.getAuthTag().toString('base64')}.${encrypted.toString('base64')}`;
}
export function decryptSecret(value: string) {
  const [ivB64, tagB64, dataB64] = value.split('.');
  const decipher = createDecipheriv('aes-256-gcm', key(), Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}
