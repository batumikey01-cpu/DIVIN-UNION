import { ConflictException, NotFoundException } from '@nestjs/common';
import { ModerationService } from './moderation.service';

describe('ModerationService blocking', () => {
  const db: any = {
    user: { findUnique: jest.fn() },
    block: { upsert: jest.fn(), deleteMany: jest.fn() },
  };
  const service = new ModerationService(db);

  beforeEach(() => jest.clearAllMocks());

  it('creates an idempotent block for an existing user', async () => {
    db.user.findUnique.mockResolvedValue({ id: 'u2' });
    db.block.upsert.mockResolvedValue({ id: 'b1', blockerId: 'u1', blockedId: 'u2' });
    await expect(service.block('u1', 'u2')).resolves.toEqual(expect.objectContaining({ blockedId: 'u2' }));
    expect(db.block.upsert).toHaveBeenCalledWith(expect.objectContaining({ where: { blockerId_blockedId: { blockerId: 'u1', blockedId: 'u2' } } }));
  });

  it('rejects self-blocking and unknown targets', async () => {
    await expect(service.block('u1', 'u1')).rejects.toBeInstanceOf(ConflictException);
    db.user.findUnique.mockResolvedValue(null);
    await expect(service.block('u1', 'missing')).rejects.toBeInstanceOf(NotFoundException);
  });

  it('removes a block idempotently', async () => {
    db.block.deleteMany.mockResolvedValue({ count: 1 });
    await expect(service.unblock('u1', 'u2')).resolves.toEqual({ ok: true });
    expect(db.block.deleteMany).toHaveBeenCalledWith({ where: { blockerId: 'u1', blockedId: 'u2' } });
  });
});
