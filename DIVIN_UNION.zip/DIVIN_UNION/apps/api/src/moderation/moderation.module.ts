import { Module } from '@nestjs/common';
import { ModerationController } from './moderation.controller';
import { ModerationService } from './moderation.service';
import { AuthModule } from '../auth/auth.module';
import { RolesGuard } from '../common/roles.guard';
import { PrismaModule } from '../common/prisma.module';

@Module({ imports: [AuthModule, PrismaModule], controllers: [ModerationController], providers: [ModerationService, RolesGuard], exports: [ModerationService] })
export class ModerationModule {}
