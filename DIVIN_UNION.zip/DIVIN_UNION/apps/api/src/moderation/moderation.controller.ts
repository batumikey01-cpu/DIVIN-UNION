import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { Role } from '@prisma/client';
import { JwtGuard } from '../auth/jwt.guard';
import { Roles, RolesGuard } from '../common/roles.guard';
import { ModerationService } from './moderation.service';
import { CreateReportDto } from './report.dto';
import { BlockUserDto } from './block-user.dto';

@Controller('moderation')
@UseGuards(JwtGuard, RolesGuard)
export class ModerationController {
  constructor(private readonly moderation: ModerationService) {}

  @Post('report')
  report(@Req() request: any, @Body() body: CreateReportDto) { return this.moderation.createReport(request.user.sub || request.user.id, body); }

  @Get('reports')
  @Roles(Role.MODERATOR, Role.SUPER_ADMIN)
  reports() { return this.moderation.list(); }

  @Patch('reports/:id/resolve')
  @Roles(Role.MODERATOR, Role.SUPER_ADMIN)
  resolve(@Req() request:any,@Param('id') id:string,@Body() body:{status:'RESOLVED'|'DISMISSED'}){return this.moderation.resolveReport(request.user.sub||request.user.id,id,body.status);}

  @Post('block/:userId')
  block(@Req() request: any, @Param('userId') userId: string) { return this.moderation.block(request.user.sub || request.user.id, userId); }

  @Post('block')
  blockUser(@Req() request: any, @Body() body: BlockUserDto) { return this.moderation.blockUser(request.user.sub || request.user.id, body); }

  @Delete('block/:blockedId')
  @HttpCode(HttpStatus.NO_CONTENT)
  async unblockUser(@Req() request: any, @Param('blockedId') blockedId: string) {
    await this.moderation.unblockUser(request.user.sub || request.user.id, blockedId);
  }

  @Get('blocks')
  blocks(@Req() request: any) { return this.moderation.listBlocks(request.user.sub || request.user.id); }
}
