import { BadRequestException, ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { ReportReason } from '@prisma/client';
import { PrismaService } from '../common/prisma.service';
import { CreateReportDto } from './report.dto';
import { BlockUserDto } from './block-user.dto';

@Injectable()
export class ModerationService {
  constructor(private readonly db: PrismaService) {}

  async createReport(reporterId: string, dto: CreateReportDto) {
    if (reporterId === dto.targetId) throw new BadRequestException('Vous ne pouvez pas vous signaler vous-même.');
    if (!Object.values(ReportReason).includes(dto.reason as ReportReason)) throw new BadRequestException('Raison de signalement invalide.');
    const target = await this.db.user.findUnique({ where: { id: dto.targetId }, select: { id: true } });
    if (!target) throw new NotFoundException('Utilisateur signalé introuvable.');
    return this.db.report.create({ data: { reporterId, reportedId: dto.targetId, reason: dto.reason as ReportReason } });
  }

  // Nom historique conservé pour les contrôleurs déjà intégrés.
  async report(reporterId: string, dto: CreateReportDto) { return this.createReport(reporterId, dto); }

  async blockUser(blockerId: string, dto: BlockUserDto) {
    if (blockerId === dto.blockedId) throw new ConflictException('Vous ne pouvez pas vous bloquer vous-même.');
    const target = await this.db.user.findUnique({ where: { id: dto.blockedId }, select: { id: true } });
    if (!target) throw new NotFoundException('Utilisateur à bloquer introuvable.');
    return this.db.block.upsert({
      where: { blockerId_blockedId: { blockerId, blockedId: dto.blockedId } },
      update: {},
      create: { blockerId, blockedId: dto.blockedId },
    });
  }

  // Alias historique conservé pour les contrôleurs déjà intégrés.
  async block(blockerId: string, blockedId: string) { return this.blockUser(blockerId, { blockedId }); }

  async unblockUser(blockerId: string, blockedId: string) {
    return this.db.block.deleteMany({ where: { blockerId, blockedId } });
  }

  async unblock(blockerId: string, blockedId: string) { await this.unblockUser(blockerId, blockedId); return { ok: true }; }

  async isBlocked(userA: string, userB: string): Promise<boolean> {
    const count = await this.db.block.count({ where: { OR: [{ blockerId: userA, blockedId: userB }, { blockerId: userB, blockedId: userA }] } });
    return count > 0;
  }

  list() {
    return this.db.report.findMany({ where: { status: { in: ['OPEN', 'REVIEWING'] } }, include: { reporter: true, reported: true }, orderBy: { createdAt: 'asc' } });
  }

  async resolveReport(actorId:string,reportId:string,status:'RESOLVED'|'DISMISSED'){const report=await this.db.report.findUnique({where:{id:reportId}});if(!report)throw new NotFoundException('Signalement introuvable.');const updated=await this.db.report.update({where:{id:reportId},data:{status,resolvedAt:new Date()}});await this.db.auditLog.create({data:{actorId,action:`REPORT_${status}`,targetType:'Report',targetId:reportId}});return updated;}

  listBlocks(blockerId: string) {
    return this.db.block.findMany({ where: { blockerId }, include: { blocked: { select: { id: true, firstName: true, lastName: true, profilePhotoUrl: true } } }, orderBy: { createdAt: 'desc' } });
  }
}
