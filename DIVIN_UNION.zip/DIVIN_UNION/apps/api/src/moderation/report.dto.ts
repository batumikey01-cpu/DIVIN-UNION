import { IsNotEmpty, IsString, MaxLength } from 'class-validator';

export class CreateReportDto {
  // User.id est un cuid Prisma dans Divin’Union, et non un UUID obligatoire.
  @IsString()
  @IsNotEmpty()
  targetId!: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(80)
  reason!: string;
}
