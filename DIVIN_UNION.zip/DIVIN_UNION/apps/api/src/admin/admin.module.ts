import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { AdminService } from './admin.service';
import { AuthModule } from '../auth/auth.module';
import { RolesGuard } from '../common/roles.guard';
import { SubscriptionsModule } from '../subscriptions/subscriptions.module';
import { NotificationModule } from '../notifications/notification.module';

@Module({ imports: [AuthModule, SubscriptionsModule, NotificationModule], controllers: [AdminController], providers: [AdminService, RolesGuard] })
export class AdminModule {}
