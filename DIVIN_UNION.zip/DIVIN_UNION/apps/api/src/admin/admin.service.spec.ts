import { ForbiddenException } from '@nestjs/common';
import { Role } from '@prisma/client';
import { AdminService } from './admin.service';

describe('AdminService safeguards', () => {
  const db: any = {
    user: { findMany: jest.fn(), findUnique: jest.fn(), count: jest.fn(), update: jest.fn() },
    report: { count: jest.fn() },
    auditLog: { create: jest.fn() },
  };
  const notifications: any = { create: jest.fn() };
  const service = new AdminService(db, notifications);

  beforeEach(() => jest.clearAllMocks());

  it('masks phone numbers in admin search results', async () => {
    db.user.findMany.mockResolvedValue([{ id: 'u1', firstName: 'A', lastName: 'B', phone: '+243811234567' }]);
    await expect(service.search('A')).resolves.toEqual([{ id: 'u1', firstName: 'A', lastName: 'B', phoneMasked: '*********4567' }]);
  });

  it('rejects self-deletion', async () => {
    db.user.findUnique.mockResolvedValue({ id: 'admin', role: Role.SUPER_ADMIN });
    await expect(service.delete('admin', 'admin')).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('protects the last active super-admin', async () => {
    db.user.findUnique.mockResolvedValue({ id: 'root', role: Role.SUPER_ADMIN });
    db.user.count.mockResolvedValue(1);
    await expect(service.delete('admin', 'root')).rejects.toThrow('dernier super-administrateur');
  });
});
