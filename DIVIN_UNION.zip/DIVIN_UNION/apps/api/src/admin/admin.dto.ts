import { IsBoolean, IsNumber, IsOptional, IsString, MaxLength, Min, MinLength } from 'class-validator';
export class AdminSearchDto { @IsString() @MinLength(1) @MaxLength(100) q!:string; }
export class AdminUserIdDto { @IsString() @MinLength(1) id!:string; }
export class UpdatePriceDto { @IsNumber() @Min(0) amount!:number; @IsOptional() @IsString() currency?:string; @IsOptional() @IsBoolean() active?:boolean; }
export class PaymentProviderConfigDto { @IsOptional() @IsString() id?:string; @IsString() name!:string; @IsString() driver!:string; @IsString() baseUrl!:string; @IsOptional() @IsString() environment?:string; @IsOptional() @IsString() partnerRef?:string; @IsOptional() @IsString() caisseRef?:string; @IsOptional() @IsString() token?:string; @IsOptional() currencies?:string[]; @IsOptional() @IsBoolean() active?:boolean; }
