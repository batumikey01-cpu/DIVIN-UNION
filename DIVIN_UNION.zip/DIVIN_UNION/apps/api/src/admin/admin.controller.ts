import { Body, Controller, Delete, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { Role } from '@prisma/client'; import { JwtGuard } from '../auth/jwt.guard'; import { Roles, RolesGuard } from '../common/roles.guard'; import { AdminService } from './admin.service'; import { PaymentProviderRegistry } from '../subscriptions/payment-provider'; import { AdminSearchDto, AdminUserIdDto, PaymentProviderConfigDto, UpdatePriceDto } from './admin.dto';
@Controller('admin') @UseGuards(JwtGuard,RolesGuard)
export class AdminController { constructor(private readonly admin:AdminService,private readonly paymentRegistry:PaymentProviderRegistry){}
 @Get('users') @Roles(Role.MODERATOR,Role.SUPER_ADMIN) search(@Query() q:AdminSearchDto){return this.admin.search(q.q);}
 @Delete('users/:id') @Roles(Role.SUPER_ADMIN) delete(@Req() r:any,@Param() p:AdminUserIdDto){return this.admin.delete(r.user.sub||r.user.id,p.id);}
 @Post('users/:id/warn') @Roles(Role.MODERATOR,Role.SUPER_ADMIN) warn(@Req()r:any,@Param()p:AdminUserIdDto,@Body()b:{reason:string}){return this.admin.warn(r.user.sub||r.user.id,p.id,String(b.reason||'').trim());}
 @Patch('users/:id/status') @Roles(Role.MODERATOR,Role.SUPER_ADMIN) status(@Req()r:any,@Param()p:AdminUserIdDto,@Body()b:{isActive:boolean}){return this.admin.setActive(r.user.sub||r.user.id,p.id,Boolean(b.isActive));}
 @Get('stats') @Roles(Role.MODERATOR,Role.SUPER_ADMIN) stats(){return this.admin.stats();}
 @Get('payments') @Roles(Role.SUPER_ADMIN) payments(){return this.admin.payments();}
 @Get('subscriptions') @Roles(Role.MODERATOR,Role.SUPER_ADMIN) subscriptions(){return this.admin.subscriptions();}
 @Get('pricing') @Roles(Role.SUPER_ADMIN) prices(){return this.admin.prices();}
 @Patch('pricing/:id') @Roles(Role.SUPER_ADMIN) price(@Param('id') id:string,@Body() b:UpdatePriceDto){return this.admin.updatePrice(id,b.amount,b.currency,b.active);}
 @Get('payment-providers') @Roles(Role.SUPER_ADMIN) providers(){return this.admin.providers();}
 @Post('payment-providers') @Roles(Role.SUPER_ADMIN) provider(@Body() b:PaymentProviderConfigDto){return this.admin.upsertProvider(b);}
 @Patch('payment-providers/:id/status') @Roles(Role.SUPER_ADMIN) providerStatus(@Param('id') id:string,@Body() b:{active:boolean}){return this.admin.setProviderActive(id,Boolean(b.active));}
 @Delete('payment-providers/:id') @Roles(Role.SUPER_ADMIN) deleteProvider(@Param('id') id:string){return this.admin.deleteProvider(id);}
 @Post('payment-providers/:id/test') @Roles(Role.SUPER_ADMIN) testProvider(@Param('id')id:string){return this.paymentRegistry.testConnection(id);}
}
