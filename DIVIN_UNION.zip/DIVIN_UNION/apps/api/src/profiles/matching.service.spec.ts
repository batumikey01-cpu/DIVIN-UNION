import { Test, TestingModule } from '@nestjs/testing';
import { MatchingService } from './matching.service';
import { PrismaService } from '../common/prisma.service';

describe('MatchingService', () => {
  let service: MatchingService;
  let prisma: PrismaService;

  const mockPrisma = {
    user: { findUniqueOrThrow: jest.fn(), findMany: jest.fn() },
    boost: { findMany: jest.fn().mockResolvedValue([]) },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MatchingService,
        { provide: PrismaService, useValue: mockPrisma },
      ],
    }).compile();

    service = module.get<MatchingService>(MatchingService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should find Christian matches without exposing phone data', async () => {
    const mockCurrentUser = { id: 'u1', gender: 'MALE', profilePhotoUrl: 'photo' };
    const mockUsers = [{
      id: 'u2', firstName: 'A', lastName: 'B', dateOfBirth: new Date('1990-01-01'), gender: 'FEMALE',
      country: 'CD', city: 'Kinshasa', profilePhotoUrl: 'photo', bio: 'Bio', interests: ['prière'],
      maritalStatus: 'SINGLE', phoneVerified: true, plan: 'FREE',
    }];
    mockPrisma.user.findUniqueOrThrow.mockResolvedValue(mockCurrentUser);
    mockPrisma.user.findMany.mockResolvedValue(mockUsers);

    const result = await service.findMatches('u1', { christianOnly: true });

    expect(result).toEqual(expect.arrayContaining([expect.objectContaining({ id: 'u2', interests: ['prière'] })]));
    expect(result[0]).not.toHaveProperty('phone');
    expect(prisma.user.findUniqueOrThrow).toHaveBeenCalledWith({ where: { id: 'u1' } });
    expect(prisma.user.findMany).toHaveBeenCalledWith({
      where: {
        id: { not: 'u1' },
        isActive: true,
        isDeleted: false,
        role: { not: 'SUPER_ADMIN' },
        invisibleMode: false,
        isChristian: true,
        profilePhotoUrl: { not: '' },
        gender: 'FEMALE',
        blocksSent: { none: { blockedId: 'u1' } },
        blocksReceived: { none: { blockerId: 'u1' } },
        swipesReceived: { none: { giverId: 'u1' } },
        country: undefined,
        city: undefined,
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        dateOfBirth: true,
        gender: true,
        country: true,
        city: true,
        profilePhotoUrl: true,
        bio: true,
        interests: true,
        maritalStatus: true,
        phoneVerified: true,
        plan: true,
      },
      take: 100,
      orderBy: { createdAt: 'desc' },
    });
  });

  it('should reject an invalid age range', async () => {
    await expect(service.findMatches('u1', { minAge: 45, maxAge: 18 })).rejects.toThrow('minAge');
    expect(prisma.user.findMany).not.toHaveBeenCalled();
  });
});
