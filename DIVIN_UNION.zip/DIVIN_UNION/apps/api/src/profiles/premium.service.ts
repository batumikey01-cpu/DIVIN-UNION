import { ForbiddenException, Injectable } from '@nestjs/common'; import { Plan } from '@prisma/client'; import { PrismaService } from '../common/prisma.service';
@Injectable() export class PremiumService { constructor(private readonly db:PrismaService){}
 private async requirePremium(userId:string){const u=await this.db.user.findUnique({where:{id:userId},select:{plan:true}});if(!u||u.plan===Plan.FREE)throw new ForbiddenException('Cette fonctionnalité est réservée aux abonnés.');}
 async whoLikedMe(userId:string){await this.requirePremium(userId);return this.db.like.findMany({where:{receiverId:userId,giver:{isActive:true,isDeleted:false}},orderBy:{createdAt:'desc'},include:{giver:{select:{id:true,firstName:true,lastName:true,dateOfBirth:true,city:true,country:true,profilePhotoUrl:true,bio:true,plan:true}}}});}
 async activateBoost(userId:string,minutes=60){await this.requirePremium(userId);const starts=new Date();const ends=new Date(starts.getTime()+Math.min(Math.max(minutes,15),120)*60_000);return this.db.boost.create({data:{userId,startsAt:starts,endsAt:ends}});}
 async boostActive(userId:string){return Boolean(await this.db.boost.findFirst({where:{userId,startsAt:{lte:new Date()},endsAt:{gt:new Date()}}}));}
}
