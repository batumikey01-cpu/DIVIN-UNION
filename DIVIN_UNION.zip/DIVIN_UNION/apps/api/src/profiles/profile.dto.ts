import { IsArray, IsBoolean, IsEnum, IsOptional, IsString, MaxLength } from 'class-validator';
import { SwipeAction } from '@prisma/client';

export class UpdateProfileDto {
  @IsOptional()
  @IsString()
  @MaxLength(500)
  bio?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  interests?: string[];

  @IsOptional()
  @IsBoolean()
  christianCriteriaVerified?: boolean;
}

export class SwipeDto {
  @IsEnum(SwipeAction)
  action!: SwipeAction;
}

export class LikeDto {
  @IsString()
  @MaxLength(64)
  id!: string;
}
