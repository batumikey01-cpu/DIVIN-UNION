import { BadRequestException, Injectable } from '@nestjs/common';
import { Role } from '@prisma/client';
import { PrismaService } from '../common/prisma.service';
import { MatchQueryDto } from './match-query.dto';

@Injectable()
export class MatchingService {
  constructor(private readonly prisma: PrismaService) {}

  private age(date: Date) {
    const now = new Date();
    let age = now.getUTCFullYear() - date.getUTCFullYear();
    const month = now.getUTCMonth() - date.getUTCMonth();
    if (month < 0 || (month === 0 && now.getUTCDate() < date.getUTCDate())) age--;
    return age;
  }

  async findMatches(currentUserId: string, query: MatchQueryDto) {
    if (query.minAge !== undefined && query.maxAge !== undefined && query.minAge > query.maxAge) {
      throw new BadRequestException('minAge ne peut pas être supérieur à maxAge.');
    }

    const currentUser = await this.prisma.user.findUniqueOrThrow({ where: { id: currentUserId } });
    if (!currentUser.profilePhotoUrl) throw new BadRequestException('Ajoutez au moins une photo approuvée avant de découvrir des profils.');
    const gender = currentUser.gender === 'MALE' ? 'FEMALE' : 'MALE';
    const users = await this.prisma.user.findMany({
      where: {
        id: { not: currentUserId },
        isActive: true,
        isDeleted: false,
        role: { not: Role.SUPER_ADMIN },
        invisibleMode: false,
        isChristian: true,
        profilePhotoUrl: { not: '' },
        gender,
        blocksSent: { none: { blockedId: currentUserId } },
        blocksReceived: { none: { blockerId: currentUserId } },
        swipesReceived: { none: { giverId: currentUserId } },
        country: query.country || currentUser.travelCountry || undefined,
        city: query.city || currentUser.travelCity || undefined,
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        dateOfBirth: true,
        gender: true,
        country: true,
        city: true,
        profilePhotoUrl: true,
        bio: true,
        interests: true,
        maritalStatus: true,
        phoneVerified: true,
        plan: true,
      },
      take: 100,
      orderBy: { createdAt: 'desc' },
    });

    const boosted = new Set((await this.prisma.boost.findMany({ where: { userId: { in: users.map(u=>u.id) }, startsAt: { lte: new Date() }, endsAt: { gt: new Date() } }, select: { userId: true } })).map(x=>x.userId));
    return users
      .filter((user) => {
        const age = this.age(user.dateOfBirth);
        const ageMatches = (query.minAge === undefined || age >= query.minAge) && (query.maxAge === undefined || age <= query.maxAge);
        const userInterests = Array.isArray(user.interests) ? user.interests : [];
        const interestsMatch = !query.interests?.length || query.interests.every((interest) => userInterests.includes(interest));
        return ageMatches && interestsMatch;
      })
      .sort((a,b)=>(boosted.has(b.id)?1:0)-(boosted.has(a.id)?1:0))
      .slice(0, query.limit ?? 50)
      .map((user) => ({
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        age: this.age(user.dateOfBirth),
        gender: user.gender,
        country: user.country,
        city: user.city,
        photoUrl: user.profilePhotoUrl,
        bio: user.bio,
        interests: user.interests,
        maritalStatus: user.maritalStatus,
        verified: user.phoneVerified,
        plan: user.plan,
      }));
  }
}
