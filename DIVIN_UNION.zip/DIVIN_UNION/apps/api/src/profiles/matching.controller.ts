import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { MatchingService } from './matching.service';
import { MatchQueryDto } from './match-query.dto';
import { JwtGuard } from '../auth/jwt.guard';

@Controller('matching')
@UseGuards(JwtGuard)
export class MatchingController {
  constructor(private readonly matchingService: MatchingService) {}

  @Get()
  async getMatches(@Req() request: any, @Query() query: MatchQueryDto) {
    return this.matchingService.findMatches(request.user.sub || request.user.id, query);
  }
}
