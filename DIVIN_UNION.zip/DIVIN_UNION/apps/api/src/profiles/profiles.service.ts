import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../common/prisma.service';
import { UpdateProfileDto } from './profile.dto';
import { MatchQueryDto } from './match-query.dto';
import { MatchingService } from './matching.service';

@Injectable()
export class ProfilesService {
  constructor(private readonly db: PrismaService, private readonly matching: MatchingService) {}

  age(date: Date) {
    const now = new Date();
    let age = now.getUTCFullYear() - date.getUTCFullYear();
    const month = now.getUTCMonth() - date.getUTCMonth();
    if (month < 0 || (month === 0 && now.getUTCDate() < date.getUTCDate())) age--;
    return age;
  }

  async getMyProfile(userId: string) {
    const user = await this.db.user.findUnique({ where: { id: userId }, include: { photos: true } });
    if (!user) throw new NotFoundException('Utilisateur non trouvé.');
    const { passwordHash: _passwordHash, ...safeUser } = user;
    return { ...safeUser, age: this.age(user.dateOfBirth) };
  }

  // Alias conservé pour compatibilité avec le nom de méthode existant.
  async me(userId: string) { return this.getMyProfile(userId); }

  async updateMyProfile(userId: string, dto: UpdateProfileDto) {
    const existing = await this.db.user.findUnique({ where: { id: userId }, select: { id: true } });
    if (!existing) throw new NotFoundException('Utilisateur non trouvé.');

    // Ce statut est une décision de modération et ne peut pas être élevé par l’utilisateur.
    if (dto.christianCriteriaVerified === true) {
      throw new BadRequestException('La vérification des critères chrétiens est réservée à la modération.');
    }

    const updated = await this.db.user.update({
      where: { id: userId },
      data: {
        ...(dto.bio !== undefined ? { bio: dto.bio } : {}),
        ...(dto.interests !== undefined ? { interests: dto.interests } : {}),
        ...(dto.christianCriteriaVerified === false ? { christianCriteriaVerified: false } : {}),
      },
      include: { photos: true },
    });
    const { passwordHash: _passwordHash, ...safeUser } = updated;
    return { ...safeUser, age: this.age(updated.dateOfBirth) };
  }

  // Alias conservé pour compatibilité avec le nom de méthode existant.
  async updateMe(userId: string, dto: UpdateProfileDto) { return this.updateMyProfile(userId, dto); }

  async discover(id: string, query: MatchQueryDto & { country?: string; city?: string }) {
    return this.matching.findMatches(id, query);
  }

  async like(giverId: string, receiverId: string) {
    return this.swipe(giverId, receiverId, 'LIKE');
  }

  async swipe(giverId: string, receiverId: string, action: 'LIKE' | 'PASS') {
    if (giverId === receiverId) return { matched: false, action };
    const target = await this.db.user.findUnique({ where: { id: receiverId }, select: { id: true } });
    if (!target) throw new NotFoundException('Profil introuvable.');

    await this.db.swipe.upsert({
      where: { giverId_receiverId: { giverId, receiverId } },
      create: { giverId, receiverId, action },
      update: { action },
    });

    if (action === 'LIKE') {
      await this.db.like.upsert({ where: { giverId_receiverId: { giverId, receiverId } }, create: { giverId, receiverId }, update: {} });
    } else {
      await this.db.like.deleteMany({ where: { giverId, receiverId } });
    }

    const reciprocal = action === 'LIKE'
      ? await this.db.like.findUnique({ where: { giverId_receiverId: { giverId: receiverId, receiverId: giverId } } })
      : null;
    if (reciprocal) {
      const existing = await this.db.conversation.findFirst({ where: { AND: [{ members: { some: { userId: giverId } } }, { members: { some: { userId: receiverId } } }, { members: { every: { userId: { in: [giverId, receiverId] } } } }] } });
      if (existing) await this.db.conversation.update({ where: { id: existing.id }, data: { status: 'OPEN', openedAt: new Date() } });
      else await this.db.conversation.create({ data: { status: 'OPEN', openedAt: new Date(), members: { create: [{ userId: giverId }, { userId: receiverId }] } } });
      await this.db.notification.create({ data: { userId: receiverId, type: 'MATCH', title: 'Nouveau match', body: 'Vous avez un nouveau match.', data: { partnerId: giverId } } });
      await this.db.notification.create({ data: { userId: giverId, type: 'MATCH', title: 'Nouveau match', body: 'Vous avez un nouveau match.', data: { partnerId: receiverId } } });
    }
    return { matched: !!reciprocal, action, targetId: receiverId };
  }
}
