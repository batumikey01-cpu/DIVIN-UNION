import { Body, Controller, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { ProfilesService } from './profiles.service';
import { JwtGuard } from '../auth/jwt.guard';
import { LikeDto, SwipeDto, UpdateProfileDto } from './profile.dto';
import { MatchQueryDto } from './match-query.dto';

@Controller(['profiles', 'profile'])
@UseGuards(JwtGuard)
export class ProfilesController {
  constructor(private readonly profiles: ProfilesService) {}

  @Get('me')
  async me(@Req() request: any) { return this.profiles.getMyProfile(request.user.sub || request.user.id); }

  @Patch('me')
  async updateMe(@Req() request: any, @Body() body: UpdateProfileDto) { return this.profiles.updateMyProfile(request.user.sub || request.user.id, body); }

  @Get('discover')
  async discover(@Req() request: any, @Query() query: MatchQueryDto) { return this.profiles.discover(request.user.sub || request.user.id, query); }

  @Post(':id/like')
  like(@Req() request: any, @Body() body: LikeDto) { return this.profiles.like(request.user.sub || request.user.id, body.id); }

  @Post(':id/swipe')
  swipe(@Req() request: any, @Param('id') id: string, @Body() body: SwipeDto) {
    return this.profiles.swipe(request.user.sub || request.user.id, id, body.action);
  }
}
