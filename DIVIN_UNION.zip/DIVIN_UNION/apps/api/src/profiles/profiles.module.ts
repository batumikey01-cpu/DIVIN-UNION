import { Module } from '@nestjs/common';
import { ProfilesController } from './profiles.controller';
import { PublicProfilesController } from './public-profiles.controller';
import { ProfilesService } from './profiles.service';
import { PrismaModule } from '../common/prisma.module';
import { MatchingModule } from './matching.module';
import { MediaModule } from '../media/media.module';
import { PremiumService } from './premium.service';
import { PremiumController } from './premium.controller';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [PrismaModule, MatchingModule, MediaModule, AuthModule],
  controllers: [ProfilesController, PublicProfilesController, PremiumController],
  providers: [ProfilesService, PremiumService],
  exports: [ProfilesService, MatchingModule],
})
export class ProfilesModule {}
