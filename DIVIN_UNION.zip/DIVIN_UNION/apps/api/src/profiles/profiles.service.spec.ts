import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { ProfilesService } from './profiles.service';
import { MatchingService } from './matching.service';
import { PrismaService } from '../common/prisma.service';

describe('ProfilesService', () => {
  let service: ProfilesService;
  let prisma: PrismaService;

  const mockPrisma = {
    user: {
      findUnique: jest.fn(),
      findUniqueOrThrow: jest.fn(),
      update: jest.fn(),
      findMany: jest.fn(),
    },
    swipe: { upsert: jest.fn() },
    like: { upsert: jest.fn(), deleteMany: jest.fn(), findUnique: jest.fn() },
    boost: { findMany: jest.fn().mockResolvedValue([]) },
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ProfilesService,
        MatchingService,
        { provide: PrismaService, useValue: mockPrisma },
      ],
    }).compile();

    service = module.get<ProfilesService>(ProfilesService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should return the current profile when the user exists', async () => {
    const mockUser = {
      id: 'u1',
      phone: '+243999999999',
      firstName: 'Test',
      lastName: 'User',
      dateOfBirth: new Date('1990-01-01'),
      bio: 'Hello',
      interests: ['prière'],
      passwordHash: 'must-not-leak',
      photos: [],
    };
    mockPrisma.user.findUnique.mockResolvedValue(mockUser);

    const result = await service.getMyProfile('u1');

    expect(result).toEqual(expect.objectContaining({ id: 'u1', bio: 'Hello', interests: ['prière'] }));
    expect(result).not.toHaveProperty('passwordHash');
    expect(prisma.user.findUnique).toHaveBeenCalledWith({
      where: { id: 'u1' },
      include: { photos: true },
    });
  });

  it('should throw NotFoundException if user is not found on getMyProfile', async () => {
    mockPrisma.user.findUnique.mockResolvedValue(null);
    await expect(service.getMyProfile('unknown')).rejects.toBeInstanceOf(NotFoundException);
  });

  it('should update the existing User profile fields', async () => {
    const existing = { id: 'u1' };
    const updated = { id: 'u1', bio: 'Bio modifiée', interests: ['prière'], passwordHash: 'secret', dateOfBirth: new Date('1990-01-01'), photos: [] };
    mockPrisma.user.findUnique.mockResolvedValue(existing);
    mockPrisma.user.update.mockResolvedValue(updated);

    const result = await service.updateMyProfile('u1', { bio: 'Bio modifiée', interests: ['prière'] });

    expect(result).toEqual(expect.objectContaining({ id: 'u1', bio: 'Bio modifiée', interests: ['prière'] }));
    expect(result).not.toHaveProperty('passwordHash');
    expect(prisma.user.update).toHaveBeenCalledWith({
      where: { id: 'u1' },
      data: { bio: 'Bio modifiée', interests: ['prière'] },
      include: { photos: true },
    });
  });

  it('should throw NotFoundException if user is not found on updateMyProfile', async () => {
    mockPrisma.user.findUnique.mockResolvedValue(null);
    await expect(service.updateMyProfile('unknown', { bio: 'Bio' })).rejects.toBeInstanceOf(NotFoundException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('should reject self-validation of christian criteria', async () => {
    mockPrisma.user.findUnique.mockResolvedValue({ id: 'u1' });
    await expect(service.updateMyProfile('u1', { christianCriteriaVerified: true })).rejects.toBeInstanceOf(BadRequestException);
    expect(prisma.user.update).not.toHaveBeenCalled();
  });

  it('filters discovery results by age and all requested interests', async () => {
    mockPrisma.user.findUniqueOrThrow.mockResolvedValue({ id: 'u1', gender: 'MALE', profilePhotoUrl: 'photo' });
    mockPrisma.user.findMany.mockResolvedValue([
      { id: 'u2', firstName: 'A', lastName: 'B', dateOfBirth: new Date('1990-01-01'), gender: 'FEMALE', country: 'CD', city: 'Kinshasa', profilePhotoUrl: 'photo', bio: '', interests: ['prière', 'famille'], maritalStatus: 'SINGLE', phoneVerified: true, plan: 'FREE' },
      { id: 'u3', firstName: 'C', lastName: 'D', dateOfBirth: new Date('1970-01-01'), gender: 'FEMALE', country: 'CD', city: 'Kinshasa', profilePhotoUrl: 'photo', bio: '', interests: ['prière'], maritalStatus: 'SINGLE', phoneVerified: true, plan: 'FREE' },
    ]);
    const result = await service.discover('u1', { minAge: 30, maxAge: 40, interests: ['prière', 'famille'] });
    expect(result.map((profile) => profile.id)).toEqual(['u2']);
  });

  it('rejects an invalid age interval', async () => {
    await expect(service.discover('u1', { minAge: 40, maxAge: 20 })).rejects.toThrow('minAge');
  });

  it('persists a PASS and removes a previous like', async () => {
    mockPrisma.user.findUnique.mockResolvedValue({ id: 'u2' });
    mockPrisma.swipe.upsert.mockResolvedValue({ action: 'PASS' });
    mockPrisma.like.deleteMany.mockResolvedValue({ count: 1 });

    const result = await service.swipe('u1', 'u2', 'PASS');

    expect(result).toEqual({ matched: false, action: 'PASS', targetId: 'u2' });
    expect(prisma.swipe.upsert).toHaveBeenCalledWith({
      where: { giverId_receiverId: { giverId: 'u1', receiverId: 'u2' } },
      create: { giverId: 'u1', receiverId: 'u2', action: 'PASS' },
      update: { action: 'PASS' },
    });
    expect(prisma.like.deleteMany).toHaveBeenCalledWith({ where: { giverId: 'u1', receiverId: 'u2' } });
  });
});
