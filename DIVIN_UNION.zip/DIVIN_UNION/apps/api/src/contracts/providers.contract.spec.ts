import * as argon2 from 'argon2';
import { AuthService } from '../auth/auth.service';
import { InMemoryRateLimiter } from '../providers/rate-limiter.provider';
import { InMemorySmsProvider } from '../providers/in-memory-sms.provider';
import { InMemoryStorageProvider } from '../providers/in-memory-storage.provider';
import { MediaService } from '../media/media.service';

describe('provider contracts', () => {
  it('supports the registration verification and media upload contracts without external services', async () => {
    const sms = new InMemorySmsProvider();
    const limiter = new InMemoryRateLimiter();
    const db: any = {
      otpCode: { findFirst: jest.fn(), create: jest.fn(), updateMany: jest.fn() },
      user: { findUnique: jest.fn() },
    };
    const auth = new AuthService(db, { signAsync: jest.fn() } as any, sms, limiter);
    db.otpCode.findFirst.mockResolvedValue(null);
    db.otpCode.create.mockResolvedValue({ id: 'otp-1', expiresAt: new Date(Date.now() + 300000) });
    const requested = await auth.requestOtp('+243811234567');
    expect(requested).toEqual({ ok: true, verificationId: 'otp-1' });
    expect(sms.sent).toHaveLength(1);

    db.otpCode.findFirst.mockResolvedValue({ id: 'otp-1', codeHash: await argon2.hash(sms.sent[0].code), attempts: 0 });
    db.otpCode.updateMany.mockResolvedValue({ count: 1 });
    await expect(auth.verifyOtp('+243811234567', sms.sent[0].code)).resolves.toEqual({ verified: true, verificationId: 'otp-1' });

    const storage = new InMemoryStorageProvider();
    const mediaDb: any = { mediaAsset: { create: jest.fn() } };
    const media = new MediaService(mediaDb, storage);
    const intent = await media.createUploadIntent('u1', { contentType: 'image/jpeg', sizeBytes: 2048 });
    expect(intent.uploadUrl).toMatch(/^https:\/\/storage\.test/);
    expect(intent.objectKey).toMatch(/^users\/u1\//);
  });
});
