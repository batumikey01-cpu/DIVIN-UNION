import { HealthController } from './health.controller';

describe('HealthController', () => {
  it('reports database availability', async () => {
    const controller = new HealthController({ $queryRaw: jest.fn().mockResolvedValue([{ '?column?': 1 }]) } as any);
    const response: any = { status: jest.fn() };
    await expect(controller.ok(response)).resolves.toMatchObject({ status: 'ok', database: 'ok' });
    expect(response.status).not.toHaveBeenCalled();
  });

  it('returns service unavailable when database check fails', async () => {
    const controller = new HealthController({ $queryRaw: jest.fn().mockRejectedValue(new Error('offline')) } as any);
    const response: any = { status: jest.fn() };
    await expect(controller.ok(response)).resolves.toMatchObject({ status: 'degraded', database: 'unavailable' });
    expect(response.status).toHaveBeenCalledWith(503);
  });
});
