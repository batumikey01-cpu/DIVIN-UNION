import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { JwtGuard } from './jwt.guard';
import { InMemorySmsProvider } from '../providers/in-memory-sms.provider';
import { DatabaseRateLimiter, InMemoryRateLimiter } from '../providers/rate-limiter.provider';
import { SocialAuthService } from './social-auth.service';
import { InMemoryEmailOtpProvider } from '../providers/in-memory-email-otp.provider';
import { HttpEmailOtpProvider } from '../providers/http-email-otp.provider';
import { PrismaService } from '../common/prisma.service';

@Module({
  imports: [JwtModule.register({ secret: process.env.JWT_SECRET || 'dev-secret-change-me', signOptions: { expiresIn: '15m' } })],
  controllers: [AuthController],
  providers: [
    AuthService,
    SocialAuthService,
    JwtGuard,
    { provide: 'SMS_PROVIDER', useClass: InMemorySmsProvider },
    { provide: 'EMAIL_OTP_PROVIDER', useFactory: () => process.env.EMAIL_OTP_PROVIDER === 'http' ? new HttpEmailOtpProvider() : new InMemoryEmailOtpProvider() },
    { provide: 'RATE_LIMITER', useFactory: (db:any) => process.env.RATE_LIMITER_PROVIDER === 'memory' ? new InMemoryRateLimiter() : new DatabaseRateLimiter(db), inject: [PrismaService] },
  ],
  exports: [AuthService, JwtGuard, JwtModule],
})
export class AuthModule {}
