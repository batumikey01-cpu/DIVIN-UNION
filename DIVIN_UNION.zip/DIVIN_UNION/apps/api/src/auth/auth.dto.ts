import { Transform } from 'class-transformer';
import { IsBoolean, IsDateString, IsEmail, IsEnum, IsOptional, IsString, IsStrongPassword, Length, Matches, MinLength } from 'class-validator';
import { Gender, MaritalStatus } from '@prisma/client';

const PHONE_PATTERN = /^\+[1-9]\d{7,14}$/;

export class RequestOtpDto {
  @Transform(({ value }) => String(value).replace(/[\s().-]/g, ''))
  @Matches(PHONE_PATTERN, { message: 'Le numéro doit être au format international (+XXXXXXXX).' })
  phone!: string;
}
export class VerifyOtpDto extends RequestOtpDto {
  @Matches(/^\d{6}$/, { message: 'Le code OTP doit contenir 6 chiffres.' }) code!: string;
}

export class RegisterDto {
  @IsString() @MinLength(1) firstName!: string;
  @IsString() @MinLength(1) lastName!: string;
  @IsOptional() @IsEmail() email?: string;
  @IsOptional() @Transform(({ value }) => String(value).replace(/[\s().-]/g, '')) @Matches(PHONE_PATTERN) phone?: string;
  @IsOptional() @IsStrongPassword({ minLength: 10, minUppercase: 1, minLowercase: 1, minNumbers: 1, minSymbols: 1 }) password?: string;
  @IsDateString() dateOfBirth!: string;
  @IsEnum(Gender) gender!: Gender;
  @IsString() @Length(2, 2) country!: string;
  @IsString() @MinLength(1) city!: string;
  @IsEnum(MaritalStatus) maritalStatus!: MaritalStatus;
  @IsBoolean() isChristian!: boolean;
  @IsOptional() @IsString() bio?: string;
  @IsOptional() @IsBoolean() seekingSerious?: boolean;
  @IsOptional() @IsBoolean() seekingMarriage?: boolean;
  @IsOptional() @IsString() @MinLength(20) otpVerificationId?: string;
}

export class LoginDto {
  @IsOptional() @IsString() @MinLength(3) identifier?: string;
  @IsOptional() @IsEmail() email?: string;
  @IsOptional() @Transform(({ value }) => String(value).replace(/[\s().-]/g, '')) @Matches(PHONE_PATTERN) phone?: string;
  @IsString() @MinLength(1) password!: string;
}

export class CompleteSocialSignupDto {
  @IsString() @MinLength(1) firstName!: string;
  @IsString() @MinLength(1) lastName!: string;
  @IsDateString() dateOfBirth!: string;
  @IsEnum(Gender) gender!: Gender;
  @IsString() @Length(2, 2) country!: string;
  @IsString() @MinLength(1) city!: string;
  @IsEnum(MaritalStatus) maritalStatus!: MaritalStatus;
  @IsBoolean() isChristian!: boolean;
  @IsOptional() @IsString() bio?: string;
  @IsOptional() @IsBoolean() seekingSerious?: boolean;
  @IsOptional() @IsBoolean() seekingMarriage?: boolean;
  @IsOptional() @Transform(({ value }) => String(value).replace(/[\s().-]/g, '')) @Matches(PHONE_PATTERN) phone?: string;
}

export class CompleteSocialSignupRequestDto extends CompleteSocialSignupDto {}

export class RequestEmailOtpDto {
  @IsEmail() email!: string;
}
export class VerifyEmailOtpDto extends RequestEmailOtpDto {
  @Matches(/^\d{6}$/, { message: 'Le code OTP doit contenir 6 chiffres.' }) code!: string;
}

export class PasswordResetRequestDto { @IsEmail() email!: string; }
export class PasswordResetConfirmDto { @IsString() @MinLength(32) token!: string; @IsStrongPassword({minLength:10,minUppercase:1,minLowercase:1,minNumbers:1,minSymbols:1}) password!: string; }
