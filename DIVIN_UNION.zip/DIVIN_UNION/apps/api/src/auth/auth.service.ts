import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  Optional,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../common/prisma.service';
import * as argon2 from 'argon2';
import { randomBytes, createHash } from 'node:crypto';
import { CompleteSocialSignupDto, RegisterDto } from './auth.dto';
import { SocialAuthService } from './social-auth.service';
import { SocialProvider } from './social-provider.types';
import { EmailOtpProvider } from '../providers/provider.types';
import { InMemoryEmailOtpProvider } from '../providers/in-memory-email-otp.provider';
import { InMemorySmsProvider } from '../providers/in-memory-sms.provider';
import { SmsProvider } from '../providers/provider.types';
import { InMemoryRateLimiter, RateLimiter } from '../providers/rate-limiter.provider';

const PHONE_PATTERN = /^\+[1-9]\d{7,14}$/;
const OTP_TTL_MS = 10 * 60_000;
const OTP_MAX_ATTEMPTS = 5;
const OTP_COOLDOWN_MS = 60_000;
const REFRESH_TTL_MS = 30 * 24 * 60 * 60_000;

export function normalizePhone(phone: string) {
  const normalized = String(phone).replace(/[\s().-]/g, '');
  if (!PHONE_PATTERN.test(normalized)) throw new BadRequestException('Le numéro doit être au format international.');
  return normalized;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly db: PrismaService,
    private readonly jwt: JwtService,
    @Optional() @Inject('SMS_PROVIDER') private readonly sms: SmsProvider = new InMemorySmsProvider(),
    @Optional() @Inject('RATE_LIMITER') private readonly limiter: RateLimiter = new InMemoryRateLimiter(),
    @Optional() private readonly social: SocialAuthService = new SocialAuthService(),
    @Optional() @Inject('EMAIL_OTP_PROVIDER') private readonly emailOtp: EmailOtpProvider = new InMemoryEmailOtpProvider(),
  ) {}

  async requestEmailOtp(rawEmail: string) {
    const email = String(rawEmail || '').trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) throw new BadRequestException('Email invalide.');
    await this.consumeOrThrow(`otp:email:request:${email}`, 3, 60 * 60_000);
    const recent = await this.db.emailOtpCode.findFirst({ where: { email, createdAt: { gt: new Date(Date.now() - OTP_COOLDOWN_MS) } }, orderBy: { createdAt: 'desc' } });
    if (recent) throw new HttpException('Veuillez patienter avant de demander un nouveau code.', HttpStatus.TOO_MANY_REQUESTS);
    const code = String(randomBytes(4).readUInt32BE(0) % 900000 + 100000);
    await this.db.emailOtpCode.updateMany({ where: { email, usedAt: null }, data: { usedAt: new Date() } });
    const otp = await this.db.emailOtpCode.create({ data: { email, codeHash: await argon2.hash(code), expiresAt: new Date(Date.now() + OTP_TTL_MS) } });
    await this.emailOtp.sendOtp(email, code, otp.expiresAt);
    return { ok: true, verificationId: otp.id };
  }

  async verifyEmailOtp(rawEmail: string, code: string) {
    const email = String(rawEmail || '').trim().toLowerCase();
    await this.consumeOrThrow(`otp:email:verify:${email}`, OTP_MAX_ATTEMPTS, OTP_TTL_MS);
    const otp = await this.db.emailOtpCode.findFirst({ where: { email, usedAt: null, expiresAt: { gt: new Date() } }, orderBy: { createdAt: 'desc' } });
    if (!otp || otp.attempts >= OTP_MAX_ATTEMPTS) throw new UnauthorizedException('Code invalide ou expiré.');
    if (!(await argon2.verify(otp.codeHash, code))) {
      await this.db.emailOtpCode.updateMany({ where: { id: otp.id, usedAt: null, attempts: { lt: OTP_MAX_ATTEMPTS } }, data: { attempts: { increment: 1 } } });
      throw new UnauthorizedException('Code invalide ou expiré.');
    }
    const consumed = await this.db.emailOtpCode.updateMany({ where: { id: otp.id, usedAt: null, expiresAt: { gt: new Date() }, attempts: { lt: OTP_MAX_ATTEMPTS } }, data: { usedAt: new Date(), verifiedAt: new Date() } });
    if (consumed.count !== 1) throw new UnauthorizedException('Code invalide ou déjà utilisé.');
    return { verified: true, verificationId: otp.id };
  }

  async requestOtp(rawPhone: string) {
    const phone = normalizePhone(rawPhone);
    await this.consumeOrThrow(`otp:request:${phone}`, 1, OTP_COOLDOWN_MS);
    const recent = await this.db.otpCode.findFirst({
      where: { phone, createdAt: { gt: new Date(Date.now() - OTP_COOLDOWN_MS) } },
      orderBy: { createdAt: 'desc' },
    });
    if (recent) throw new HttpException('Veuillez patienter avant de demander un nouveau code.', HttpStatus.TOO_MANY_REQUESTS);

    const code = String(randomBytes(4).readUInt32BE(0) % 900000 + 100000);
    await this.db.otpCode.updateMany({ where: { phone, usedAt: null }, data: { usedAt: new Date() } });
    const otp = await this.db.otpCode.create({
      data: { phone, codeHash: await argon2.hash(code), expiresAt: new Date(Date.now() + OTP_TTL_MS) },
    });
    await this.sms.sendOtp(phone, code, otp.expiresAt);
    return { ok: true, verificationId: otp.id };
  }

  async verifyOtp(rawPhone: string, code: string) {
    const phone = normalizePhone(rawPhone);
    await this.consumeOrThrow(`otp:verify:${phone}`, OTP_MAX_ATTEMPTS, OTP_TTL_MS);
    const otp = await this.db.otpCode.findFirst({
      where: { phone, usedAt: null, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
    });
    if (!otp) throw new UnauthorizedException('Code invalide ou expiré.');
    if (otp.attempts >= OTP_MAX_ATTEMPTS) throw new HttpException('Trop de tentatives pour ce code.', HttpStatus.TOO_MANY_REQUESTS);

    const valid = await argon2.verify(otp.codeHash, code);
    if (!valid) {
      await this.db.otpCode.updateMany({
        where: { id: otp.id, usedAt: null, attempts: { lt: OTP_MAX_ATTEMPTS } },
        data: { attempts: { increment: 1 } },
      });
      throw new UnauthorizedException('Code invalide ou expiré.');
    }

    const consumed = await this.db.otpCode.updateMany({
      where: { id: otp.id, usedAt: null, expiresAt: { gt: new Date() }, attempts: { lt: OTP_MAX_ATTEMPTS } },
      data: { usedAt: new Date(), verifiedAt: new Date() },
    });
    if (consumed.count !== 1) throw new UnauthorizedException('Code invalide ou déjà utilisé.');
    return { verified: true, verificationId: otp.id };
  }

  async requestPasswordReset(rawEmail: string) {
    const email=String(rawEmail||'').trim().toLowerCase();
    await this.consumeOrThrow(`password-reset:${email}`,3,60*60_000);
    const generic={ok:true,message:'Si ce compte existe, un lien de récupération a été envoyé.'};
    const user=await this.db.user.findUnique({where:{email},select:{id:true,email:true,isActive:true,isDeleted:true}});
    if(!user||!user.isActive||user.isDeleted||!user.email) return generic;
    const raw=randomBytes(32).toString('base64url'); const hash=createHash('sha256').update(raw).digest('hex'); const expiresAt=new Date(Date.now()+30*60_000);
    await this.db.passwordResetToken.updateMany({where:{userId:user.id,usedAt:null},data:{usedAt:new Date()}});
    await this.db.passwordResetToken.create({data:{userId:user.id,tokenHash:hash,expiresAt}});
    if(!this.emailOtp.sendPasswordReset) throw new HttpException('Service email non configuré.',HttpStatus.SERVICE_UNAVAILABLE);
    await this.emailOtp.sendPasswordReset(user.email,raw,expiresAt);
    return generic;
  }

  async confirmPasswordReset(token:string,password:string) {
    const hash=createHash('sha256').update(token).digest('hex');
    const row=await this.db.passwordResetToken.findFirst({where:{tokenHash:hash,usedAt:null,expiresAt:{gt:new Date()}},select:{id:true,userId:true}});
    if(!row) throw new UnauthorizedException('Lien invalide ou expiré.');
    const passwordHash=await argon2.hash(password);
    await this.db.$transaction([this.db.passwordResetToken.update({where:{id:row.id},data:{usedAt:new Date()}}),this.db.user.update({where:{id:row.userId},data:{passwordHash}}),this.db.refreshSession.updateMany({where:{userId:row.userId,revokedAt:null},data:{revokedAt:new Date()}})]);
    return {ok:true};
  }

  async register(dto: RegisterDto) {
    const phone = dto.phone ? normalizePhone(dto.phone) : undefined;
    if (dto.isChristian !== true) throw new BadRequestException('Divin’Union est réservé aux chrétiens.');
    if (this.age(new Date(dto.dateOfBirth)) < 18) throw new BadRequestException('Vous devez avoir au moins 18 ans.');

    if (!phone && !dto.email) throw new BadRequestException('Un email ou un téléphone est requis.');
    if (!dto.password) throw new BadRequestException('Un mot de passe est requis pour une inscription par email.');
    if (phone) { const existing = await this.db.user.findUnique({ where: { phone } }); if (existing) throw new BadRequestException('Numéro déjà utilisé.'); }
    if (dto.email) { const existingEmail = await this.db.user.findUnique({ where: { email: dto.email.toLowerCase() } }); if (existingEmail) throw new BadRequestException('Email déjà utilisé.'); }

    const passwordHash = await argon2.hash(dto.password);
    const user = await this.db.$transaction(async (tx: any) => {
      if (phone) {
        const verification = await tx.otpCode.updateMany({
          where: {
            id: dto.otpVerificationId,
            phone,
            usedAt: { not: null },
            consumedAt: null,
            verifiedAt: { not: null },
            createdAt: { gt: new Date(Date.now() - OTP_TTL_MS) },
          },
          data: { consumedAt: new Date() },
        });
        if (verification.count !== 1) throw new UnauthorizedException('Le téléphone doit être vérifié avant l’inscription.');
      } else if (dto.email) {
        const verification = await tx.emailOtpCode.updateMany({ where: { id: dto.otpVerificationId, email: dto.email.toLowerCase(), usedAt: { not: null }, consumedAt: null, verifiedAt: { not: null }, createdAt: { gt: new Date(Date.now() - OTP_TTL_MS) } }, data: { consumedAt: new Date() } });
        if (verification.count !== 1) throw new UnauthorizedException('L’email doit être vérifié avant l’inscription.');
      }

      return tx.user.create({
        data: {
          phone,
          email: dto.email?.toLowerCase(),
          passwordHash,
          firstName: dto.firstName,
          lastName: dto.lastName,
          dateOfBirth: new Date(dto.dateOfBirth),
          gender: dto.gender,
          country: dto.country.toUpperCase(),
          city: dto.city,
          maritalStatus: dto.maritalStatus,
          isChristian: true,
          phoneVerified: false,
          profilePhotoUrl: '',
          bio: dto.bio ?? '',
          seekingSerious: dto.seekingSerious ?? true,
          seekingMarriage: dto.seekingMarriage ?? true,
        },
      });
    });
    return this.issue(user);
  }

  async login(rawIdentifier: string, password: string) {
    const identifier = String(rawIdentifier || '').trim();
    await this.consumeOrThrow(`login:${identifier.toLowerCase()}`, 10, 15 * 60_000);
    const user = identifier.includes('@')
      ? await this.db.user.findUnique({ where: { email: identifier.toLowerCase() } })
      : await this.db.user.findUnique({ where: { phone: normalizePhone(identifier) } });
    if (!user || user.isDeleted || !user.isActive || !user.passwordHash || !(await argon2.verify(user.passwordHash, password))) {
      throw new UnauthorizedException('Identifiants invalides.');
    }
    return this.issue(user);
  }

  async refresh(rawToken: string) {
    const [sessionId, secret] = String(rawToken).split('.', 2);
    if (!sessionId || !secret) throw new UnauthorizedException('Session invalide.');
    await this.consumeOrThrow(`refresh:${sessionId}`, 30, 60_000);

    const session = await this.db.refreshSession.findUnique({ where: { id: sessionId }, include: { user: true } });
    if (!session || !(await argon2.verify(session.tokenHash, secret))) throw new UnauthorizedException('Session invalide.');
    if (session.revokedAt || session.expiresAt <= new Date()) {
      await this.db.refreshSession.update({ where: { id: session.id }, data: { reuseDetectedAt: new Date() } }).catch(() => undefined);
      await this.db.refreshSession.updateMany({ where: { userId: session.userId, revokedAt: null }, data: { revokedAt: new Date() } });
      throw new UnauthorizedException('Réutilisation de session détectée.');
    }
    if (session.user.isDeleted || !session.user.isActive) throw new UnauthorizedException('Session invalide.');

    const result = await this.db.$transaction(async (tx: any) => {
      const revoked = await tx.refreshSession.updateMany({ where: { id: session.id, revokedAt: null }, data: { revokedAt: new Date() } });
      if (revoked.count !== 1) throw new UnauthorizedException('Réutilisation de session détectée.');
      return this.issue(session.user, tx);
    });
    return result;
  }

  async revokeRefresh(rawToken: string) {
    const [sessionId, secret] = String(rawToken).split('.', 2);
    if (!sessionId || !secret) return { ok: true };
    const session = await this.db.refreshSession.findUnique({ where: { id: sessionId } });
    if (session && await argon2.verify(session.tokenHash, secret)) {
      await this.db.refreshSession.update({ where: { id: session.id }, data: { revokedAt: new Date() } });
    }
    return { ok: true };
  }

  async startSocial(provider: SocialProvider) {
    const allowed = new Set<SocialProvider>(['google', 'apple', 'microsoft']);
    if (!allowed.has(provider)) throw new BadRequestException('Fournisseur social non pris en charge.');
    const state = this.social.createState();
    const nonce = this.social.createNonce();
    const verifier = this.social.createCodeVerifier();
    const redirectUri = this.redirectUri(provider);
    await this.db.oAuthState.create({ data: { provider, stateHash: this.social.hashState(state), nonce, codeVerifier: verifier, redirectUri, expiresAt: new Date(Date.now() + 10 * 60_000) } });
    return this.social.getAuthorizationUrl(provider, { state, nonce, codeChallenge: this.social.codeChallenge(verifier), redirectUri });
  }

  async completeSocialCallback(provider: SocialProvider, state: string, code: string) {
    const oauth = await this.db.oAuthState.findFirst({ where: { provider, stateHash: this.social.hashState(state), consumedAt: null, expiresAt: { gt: new Date() } } });
    if (!oauth) throw new UnauthorizedException('Session OAuth invalide ou expirée.');
    const consumed = await this.db.oAuthState.updateMany({ where: { id: oauth.id, consumedAt: null }, data: { consumedAt: new Date() } });
    if (consumed.count !== 1) throw new UnauthorizedException('Session OAuth déjà utilisée.');
    const identity = await this.social.exchangeCode(provider, code, oauth.codeVerifier, oauth.redirectUri, oauth.nonce);
    const linked = await this.db.socialAccount.findUnique({ where: { provider_providerAccountId: { provider, providerAccountId: identity.providerAccountId } }, include: { user: true } });
    if (linked?.user && linked.user.isActive && !linked.user.isDeleted) return { type: 'login' as const, result: await this.issue(linked.user) };
    if (identity.email) {
      const byEmail = identity.emailVerified ? await this.db.user.findUnique({ where: { email: identity.email } }) : null;
      if (byEmail && byEmail.isActive && !byEmail.isDeleted) {
        await this.db.socialAccount.upsert({ where: { provider_providerAccountId: { provider, providerAccountId: identity.providerAccountId } }, create: { userId: byEmail.id, provider, providerAccountId: identity.providerAccountId, email: identity.email }, update: { email: identity.email } });
        return { type: 'login' as const, result: await this.issue(byEmail) };
      }
    }
    const rawToken = randomBytes(32).toString('base64url');
    await this.db.socialSignupSession.create({ data: { tokenHash: this.social.hashState(rawToken), provider, providerAccountId: identity.providerAccountId, email: identity.email, emailVerified: identity.emailVerified, firstName: identity.firstName || '', lastName: identity.lastName || '', avatarUrl: identity.avatarUrl, expiresAt: new Date(Date.now() + 15 * 60_000) } });
    return { type: 'signup' as const, signupToken: rawToken, profile: { email: identity.email, firstName: identity.firstName, lastName: identity.lastName, avatarUrl: identity.avatarUrl } };
  }

  async completeSocialSignup(rawToken: string, dto: CompleteSocialSignupDto) {
    const tokenHash = this.social.hashState(rawToken);
    const pending = await this.db.socialSignupSession.findUnique({ where: { tokenHash } });
    if (!pending || pending.consumedAt || pending.expiresAt <= new Date()) throw new UnauthorizedException('Inscription sociale expirée.');
    if (dto.isChristian !== true) throw new BadRequestException('Divin’Union est réservé aux chrétiens.');
    if (this.age(new Date(dto.dateOfBirth)) < 18) throw new BadRequestException('Vous devez avoir au moins 18 ans.');
    if (dto.phone) {
      const existingPhone = await this.db.user.findUnique({ where: { phone: normalizePhone(dto.phone) } });
      if (existingPhone) throw new BadRequestException('Numéro déjà utilisé.');
    }
    if (pending.email) {
      const existingEmail = await this.db.user.findUnique({ where: { email: pending.email } });
      if (existingEmail) throw new BadRequestException('Email déjà utilisé.');
    }
    const user = await this.db.$transaction(async (tx: any) => {
      const consumed = await tx.socialSignupSession.updateMany({ where: { id: pending.id, consumedAt: null, expiresAt: { gt: new Date() } }, data: { consumedAt: new Date() } });
      if (consumed.count !== 1) throw new UnauthorizedException('Inscription sociale déjà utilisée.');
      const created = await tx.user.create({ data: { email: pending.email, phone: dto.phone ? normalizePhone(dto.phone) : undefined, passwordHash: null, firstName: dto.firstName || pending.firstName || 'Utilisateur', lastName: dto.lastName || pending.lastName || '', dateOfBirth: new Date(dto.dateOfBirth), gender: dto.gender, country: dto.country.toUpperCase(), city: dto.city, maritalStatus: dto.maritalStatus, isChristian: true, phoneVerified: false, profilePhotoUrl: '', bio: dto.bio ?? '', seekingSerious: dto.seekingSerious ?? true, seekingMarriage: dto.seekingMarriage ?? true } });
      await tx.socialAccount.create({ data: { userId: created.id, provider: pending.provider, providerAccountId: pending.providerAccountId, email: pending.email } });
      return created;
    });
    return this.issue(user);
  }

  private redirectUri(provider: SocialProvider) {
    const base = (process.env.API_PUBLIC_URL || `http://localhost:${process.env.PORT || 4000}`).replace(/\/$/, '');
    return `${base}/auth/oauth/${provider}/callback`;
  }

  age(date: Date) {
    const now = new Date();
    let age = now.getUTCFullYear() - date.getUTCFullYear();
    const month = now.getUTCMonth() - date.getUTCMonth();
    if (month < 0 || (month === 0 && now.getUTCDate() < date.getUTCDate())) age--;
    return age;
  }

  private async issue(user: any, client: any = this.db) {
    const accessToken = await this.jwt.signAsync({ sub: user.id, role: user.role });
    const sessionId = randomBytes(18).toString('hex');
    const secret = randomBytes(48).toString('base64url');
    await client.refreshSession.create({
      data: {
        id: sessionId,
        userId: user.id,
        tokenHash: await argon2.hash(secret),
        expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
      },
    });
    return {
      accessToken,
      refreshToken: `${sessionId}.${secret}`,
      user: { id: user.id, firstName: user.firstName, lastName: user.lastName, plan: user.plan, role: user.role },
    };
  }

  private async consumeOrThrow(key: string, limit: number, windowMs: number) {
    const result = await this.limiter.consume(key, limit, windowMs);
    if (!result.allowed) throw new HttpException('Trop de tentatives. Veuillez réessayer plus tard.', HttpStatus.TOO_MANY_REQUESTS);
  }
}
