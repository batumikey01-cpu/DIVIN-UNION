import { AuthService } from './auth.service';
import * as argon2 from 'argon2';
import { InMemorySmsProvider } from '../providers/in-memory-sms.provider';

function makeService() {
  const db: any = {
    otpCode: { findFirst: jest.fn(), create: jest.fn(), update: jest.fn(), updateMany: jest.fn() },
    user: { findUnique: jest.fn(), create: jest.fn() },
    refreshSession: { create: jest.fn(), findUnique: jest.fn(), update: jest.fn().mockResolvedValue({}), updateMany: jest.fn() },
    $transaction: jest.fn(async (callback: any) => callback(db)),
  };
  const jwt: any = { signAsync: jest.fn().mockResolvedValue('access-token') };
  const sms = new InMemorySmsProvider();
  return { service: new AuthService(db, jwt, sms), db, sms };
}

describe('AuthService identity tranche', () => {
  it('normalizes international phone numbers before persistence', async () => {
    const { service, db, sms } = makeService();
    db.otpCode.findFirst.mockResolvedValue(null);
    db.otpCode.create.mockResolvedValue({ id: 'otp-1', expiresAt: new Date(Date.now() + 300000) });
    const result = await service.requestOtp('+243 811 234 567');
    expect(db.otpCode.create.mock.calls[0][0].data.phone).toBe('+243811234567');
    expect(sms.sent).toHaveLength(1);
    expect(result).not.toHaveProperty('devCode');
  });

  it('increments attempts and rejects an invalid OTP', async () => {
    const { service, db } = makeService();
    db.otpCode.findFirst.mockResolvedValue({ id: 'otp-1', codeHash: await argon2.hash('123456'), attempts: 0 });
    await expect(service.verifyOtp('+243811234567', '000000')).rejects.toThrow('Code invalide');
    expect(db.otpCode.updateMany).toHaveBeenCalledWith(expect.objectContaining({ where: expect.objectContaining({ usedAt: null }) }));
  });

  it('rejects a valid OTP when another request consumed it first', async () => {
    const { service, db } = makeService();
    db.otpCode.findFirst.mockResolvedValue({ id: 'otp-1', codeHash: await argon2.hash('123456'), attempts: 0 });
    db.otpCode.updateMany.mockResolvedValue({ count: 0 });
    await expect(service.verifyOtp('+243811234567', '123456')).rejects.toThrow('déjà utilisé');
  });

  it('consumes an OTP atomically during registration', async () => {
    const { service, db } = makeService();
    db.user.findUnique.mockResolvedValue(null);
    db.otpCode.updateMany.mockResolvedValue({ count: 1 });
    db.user.create.mockResolvedValue({ id: 'user-1', role: 'USER', plan: 'FREE', firstName: 'A', lastName: 'B' });
    await service.register({ phone: '+243811234567', firstName: 'A', lastName: 'B', password: 'StrongPassword1!', dateOfBirth: '1990-01-01', gender: 'MALE', country: 'CD', city: 'Kinshasa', maritalStatus: 'SINGLE', isChristian: true, profilePhotoUrl: 'storage://photo', otpVerificationId: 'otp-1' } as any);
    expect(db.otpCode.updateMany).toHaveBeenCalledWith(expect.objectContaining({ where: expect.objectContaining({ consumedAt: null }) }));
  });

  it('rejects a second registration attempt using the same OTP', async () => {
    const { service, db } = makeService();
    db.user.findUnique.mockResolvedValue(null);
    db.otpCode.updateMany.mockResolvedValue({ count: 0 });
    await expect(service.register({ phone: '+243811234567', firstName: 'A', lastName: 'B', password: 'StrongPassword1!', dateOfBirth: '1990-01-01', gender: 'MALE', country: 'CD', city: 'Kinshasa', maritalStatus: 'SINGLE', isChristian: true, profilePhotoUrl: 'storage://photo', otpVerificationId: 'otp-1' } as any)).rejects.toThrow('téléphone doit être vérifié');
    expect(db.user.create).not.toHaveBeenCalled();
  });

  it('detects reuse of a revoked refresh token and revokes active sessions', async () => {
    const { service, db } = makeService();
    const secret = 'refresh-secret';
    db.refreshSession.findUnique.mockResolvedValue({ id: 'session-1', userId: 'user-1', tokenHash: await argon2.hash(secret), revokedAt: new Date(), expiresAt: new Date(Date.now() + 10000), user: { id: 'user-1', isDeleted: false, isActive: true } });
    await expect(service.refresh(`session-1.${secret}`)).rejects.toThrow('Réutilisation');
    expect(db.refreshSession.updateMany).toHaveBeenCalledWith(expect.objectContaining({ where: { userId: 'user-1', revokedAt: null } }));
  });
});
