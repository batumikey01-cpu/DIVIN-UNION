import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common';
import { createHash, createPublicKey, createSign, createVerify, randomBytes, timingSafeEqual } from 'node:crypto';
import { SocialIdentity, SocialProvider } from './social-provider.types';

type Jwk = { kid: string; kty: string; n?: string; e?: string; alg?: string; use?: string; crv?: string; x?: string; y?: string };

type JwtParts = { header: Record<string, any>; payload: Record<string, any>; signingInput: Buffer; signature: Buffer };

const issuerConfig: Record<SocialProvider, { authorize: string; token: string; jwks: string }> = {
  google: { authorize: 'https://accounts.google.com/o/oauth2/v2/auth', token: 'https://oauth2.googleapis.com/token', jwks: 'https://www.googleapis.com/oauth2/v3/certs' },
  apple: { authorize: 'https://appleid.apple.com/auth/authorize', token: 'https://appleid.apple.com/auth/token', jwks: 'https://appleid.apple.com/auth/keys' },
  microsoft: { authorize: `https://login.microsoftonline.com/common/oauth2/v2.0/authorize`, token: `https://login.microsoftonline.com/common/oauth2/v2.0/token`, jwks: 'https://login.microsoftonline.com/common/discovery/v2.0/keys' },
};

function b64url(value: Buffer | string) { return Buffer.from(value).toString('base64url'); }
function sha256(value: string) { return createHash('sha256').update(value).digest('base64url'); }
function decodePart(value: string) { return JSON.parse(Buffer.from(value, 'base64url').toString('utf8')); }

@Injectable()
export class SocialAuthService {
  private jwksCache = new Map<string, { expiresAt: number; keys: Jwk[] }>();

  getAuthorizationUrl(provider: SocialProvider, input: { state: string; nonce: string; codeChallenge: string; redirectUri: string }) {
    const clientId = this.clientId(provider);
    const cfg = issuerConfig[provider];
    const params = new URLSearchParams({ client_id: clientId, redirect_uri: input.redirectUri, response_type: 'code', scope: provider === 'microsoft' ? 'openid profile email User.Read' : 'openid email profile', state: input.state, nonce: input.nonce, code_challenge: input.codeChallenge, code_challenge_method: 'S256' });
    if (provider === 'apple') params.set('response_mode', 'form_post');
    return `${cfg.authorize}?${params.toString()}`;
  }

  async exchangeCode(provider: SocialProvider, code: string, codeVerifier: string, redirectUri: string, expectedNonce?: string): Promise<SocialIdentity> {
    const cfg = issuerConfig[provider];
    const body = new URLSearchParams({ client_id: this.clientId(provider), client_secret: await this.clientSecret(provider), code, code_verifier: codeVerifier, grant_type: 'authorization_code', redirect_uri: redirectUri });
    const response = await fetch(cfg.token, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body });
    const data = await response.json() as any;
    if (!response.ok || !data.access_token) throw new UnauthorizedException('Authentification sociale impossible.');

    if (provider === 'apple') {
      const payload = await this.verifyJwt(data.id_token, provider);
      if (expectedNonce && payload.nonce !== expectedNonce) throw new UnauthorizedException('Nonce social invalide.');
      return {
        provider,
        providerAccountId: String(payload.sub),
        email: typeof payload.email === 'string' ? payload.email.toLowerCase() : undefined,
        emailVerified: payload.email_verified === true || payload.email_verified === 'true',
        firstName: '', lastName: '',
      };
    }

    if (data.id_token) {
      const payload = await this.verifyJwt(data.id_token, provider);
      if (expectedNonce && payload.nonce !== expectedNonce) throw new UnauthorizedException('Nonce social invalide.');
    }
    const userInfoUrl = provider === 'microsoft' ? 'https://graph.microsoft.com/oidc/userinfo' : 'https://openidconnect.googleapis.com/v1/userinfo';
    const infoResponse = await fetch(userInfoUrl, { headers: { authorization: `Bearer ${data.access_token}` } });
    const info = await infoResponse.json() as any;
    if (!infoResponse.ok || !(info.sub || info.id)) throw new UnauthorizedException('Profil du fournisseur social introuvable.');
    return {
      provider,
      providerAccountId: String(info.sub || info.id),
      email: typeof info.email === 'string' ? info.email.toLowerCase() : (typeof info.preferred_username === 'string' ? info.preferred_username.toLowerCase() : undefined),
      emailVerified: info.email_verified !== false,
      firstName: String(info.given_name || info.givenName || '').trim(),
      lastName: String(info.family_name || info.surname || '').trim(),
      avatarUrl: typeof info.picture === 'string' ? info.picture : undefined,
    };
  }

  async verifyState(expected: string, actual: string) {
    const a = Buffer.from(expected);
    const b = Buffer.from(actual);
    if (a.length !== b.length || !timingSafeEqual(a, b)) throw new BadRequestException('État OAuth invalide.');
  }

  createState() { return randomBytes(32).toString('base64url'); }
  createNonce() { return randomBytes(32).toString('base64url'); }
  createCodeVerifier() { return randomBytes(48).toString('base64url'); }
  codeChallenge(verifier: string) { return sha256(verifier); }
  hashState(value: string) { return sha256(value); }

  private clientId(provider: SocialProvider) {
    const key = provider === 'google' ? 'GOOGLE_CLIENT_ID' : provider === 'apple' ? 'APPLE_CLIENT_ID' : 'MICROSOFT_CLIENT_ID';
    const value = process.env[key];
    if (!value) throw new BadRequestException(`Fournisseur ${provider} non configuré.`);
    return value;
  }

  private async clientSecret(provider: SocialProvider) {
    if (provider === 'google') {
      const value = process.env.GOOGLE_CLIENT_SECRET;
      if (!value) throw new BadRequestException('Google non configuré.');
      return value;
    }
    if (provider === 'microsoft') {
      const value = process.env.MICROSOFT_CLIENT_SECRET;
      if (!value) throw new BadRequestException('Microsoft non configuré.');
      return value;
    }
    const team = process.env.APPLE_TEAM_ID;
    const keyId = process.env.APPLE_KEY_ID;
    const clientId = process.env.APPLE_CLIENT_ID;
    const privateKey = process.env.APPLE_PRIVATE_KEY?.replace(/\\n/g, '\n');
    if (!team || !keyId || !clientId || !privateKey) throw new BadRequestException('Apple non configuré.');
    const now = Math.floor(Date.now() / 1000);
    const header = b64url(JSON.stringify({ alg: 'ES256', kid: keyId, typ: 'JWT' }));
    const payload = b64url(JSON.stringify({ iss: team, iat: now, exp: now + 300, aud: 'https://appleid.apple.com', sub: clientId }));
    const signer = createSign('SHA256'); signer.update(`${header}.${payload}`); signer.end();
    return `${header}.${payload}.${signer.sign({ key: privateKey, dsaEncoding: 'ieee-p1363' }).toString('base64url')}`;
  }

  private async verifyJwt(token: string, provider: SocialProvider) {
    const parts = token.split('.');
    if (parts.length !== 3) throw new UnauthorizedException('Jeton social invalide.');
    const parsed: JwtParts = { header: decodePart(parts[0]), payload: decodePart(parts[1]), signingInput: Buffer.from(`${parts[0]}.${parts[1]}`), signature: Buffer.from(parts[2], 'base64url') };
    const keys = await this.jwks(issuerConfig[provider].jwks);
    const jwk = keys.find((key) => key.kid === parsed.header.kid);
    if (!jwk) throw new UnauthorizedException('Clé de signature sociale inconnue.');
    const publicKey = createPublicKey({ key: jwk as any, format: 'jwk' });
    const alg = parsed.header.alg;
    const verifier = createVerify(alg === 'ES256' ? 'SHA256' : 'RSA-SHA256'); verifier.update(parsed.signingInput); verifier.end();
    const valid = verifier.verify(alg === 'ES256' ? { key: publicKey, dsaEncoding: 'ieee-p1363' } : publicKey, parsed.signature);
    if (!valid) throw new UnauthorizedException('Signature sociale invalide.');
    const now = Math.floor(Date.now() / 1000);
    const expectedIssuer = provider === 'apple' ? 'https://appleid.apple.com' : provider === 'google' ? 'https://accounts.google.com' : undefined;
    if (expectedIssuer && parsed.payload.iss !== expectedIssuer) throw new UnauthorizedException('Émetteur social invalide.');
    if (provider === 'microsoft') {
      const issuer = String(parsed.payload.iss || '');
      if (!/^https:\/\/login\.microsoftonline\.com\/[a-f0-9-]+\/v2\.0$/i.test(issuer)) throw new UnauthorizedException('Émetteur Microsoft invalide.');
      if (parsed.payload.tid && !/^[a-f0-9-]{36}$/i.test(String(parsed.payload.tid))) throw new UnauthorizedException('Tenant Microsoft invalide.');
    }
    const expectedAudience = this.clientId(provider);
    if (parsed.payload.aud !== expectedAudience) throw new UnauthorizedException('Audience sociale invalide.');
    if (typeof parsed.payload.exp === 'number' && parsed.payload.exp < now) throw new UnauthorizedException('Jeton social expiré.');
    if (typeof parsed.payload.nbf === 'number' && parsed.payload.nbf > now + 30) throw new UnauthorizedException('Jeton social pas encore valide.');
    return parsed.payload;
  }

  private async jwks(url: string) {
    const cached = this.jwksCache.get(url);
    if (cached && cached.expiresAt > Date.now()) return cached.keys;
    const response = await fetch(url);
    if (!response.ok) throw new UnauthorizedException('Impossible de vérifier le fournisseur social.');
    const data = await response.json() as { keys: Jwk[] };
    this.jwksCache.set(url, { keys: data.keys, expiresAt: Date.now() + 6 * 60 * 60_000 });
    return data.keys;
  }
}
