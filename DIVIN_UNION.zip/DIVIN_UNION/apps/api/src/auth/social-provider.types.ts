export type SocialProvider = 'google' | 'apple' | 'microsoft';

export interface SocialIdentity {
  provider: SocialProvider;
  providerAccountId: string;
  email?: string;
  emailVerified: boolean;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
}

export interface SocialProviderAdapter {
  readonly provider: SocialProvider;
  getAuthorizationUrl(input: { state: string; nonce: string; codeChallenge: string; redirectUri: string }): string;
  exchangeCode(input: { code: string; codeVerifier: string; redirectUri: string }): Promise<SocialIdentity>;
}
