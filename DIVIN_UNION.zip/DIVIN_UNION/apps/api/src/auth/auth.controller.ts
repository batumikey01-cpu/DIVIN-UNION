import { Body, Controller, Get, Param, Post, Query, Req, Res } from '@nestjs/common';
import { Request, Response } from 'express';
import { AuthService } from './auth.service';
import { CompleteSocialSignupRequestDto, LoginDto, RegisterDto, RequestEmailOtpDto, RequestOtpDto, VerifyEmailOtpDto, VerifyOtpDto, PasswordResetRequestDto, PasswordResetConfirmDto } from './auth.dto';
import { SocialProvider } from './social-provider.types';

const REFRESH_COOKIE = 'du_refresh';
const SOCIAL_SIGNUP_COOKIE = 'du_social_signup';
const cookieOptions = { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict' as const, path: '/auth', maxAge: 30 * 24 * 60 * 60 * 1000 };

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Post('otp/request') requestOtp(@Body() body: RequestOtpDto) { return this.auth.requestOtp(body.phone); }
  @Post('otp/verify') verifyOtp(@Body() body: VerifyOtpDto) { return this.auth.verifyOtp(body.phone, body.code); }
  @Post('otp/email/request') requestEmailOtp(@Body() body: RequestEmailOtpDto) { return this.auth.requestEmailOtp(body.email); }
  @Post('otp/email/verify') verifyEmailOtp(@Body() body: VerifyEmailOtpDto) { return this.auth.verifyEmailOtp(body.email, body.code); }

  @Get('oauth/:provider/start')
  async socialStart(@Param('provider') provider: SocialProvider, @Res() response: Response) {
    const url = await this.auth.startSocial(provider);
    return response.redirect(url);
  }

  @Get('oauth/:provider/callback')
  async socialCallback(@Param('provider') provider: SocialProvider, @Query('state') state: string, @Query('code') code: string, @Res() response: Response) {
    const result = await this.auth.completeSocialCallback(provider, state, code);
    const web = (process.env.WEB_ORIGIN || 'http://localhost:3000').split(',')[0].trim();
    if (result.type === 'login') {
      response.cookie(REFRESH_COOKIE, result.result.refreshToken, cookieOptions);
      return response.redirect(`${web}/auth/social/success`);
    }
    response.cookie(SOCIAL_SIGNUP_COOKIE, result.signupToken, { ...cookieOptions, maxAge: 15 * 60 * 1000 });
    return response.redirect(`${web}/register/social`);
  }

  @Post('oauth/apple/callback')
  async appleCallback(@Body('state') state: string, @Body('code') code: string, @Res() response: Response) {
    const result = await this.auth.completeSocialCallback('apple', state, code);
    const web = (process.env.WEB_ORIGIN || 'http://localhost:3000').split(',')[0].trim();
    if (result.type === 'login') {
      response.cookie(REFRESH_COOKIE, result.result.refreshToken, cookieOptions);
      return response.redirect(`${web}/auth/social/success`);
    }
    response.cookie(SOCIAL_SIGNUP_COOKIE, result.signupToken, { ...cookieOptions, maxAge: 15 * 60 * 1000 });
    return response.redirect(`${web}/register/social`);
  }

  @Post('oauth/complete')
  async completeSocial(@Req() request: Request, @Body() body: CompleteSocialSignupRequestDto, @Res({ passthrough: true }) response: Response) {
    const signupToken = request.cookies?.[SOCIAL_SIGNUP_COOKIE];
    if (!signupToken) return response.status(401).json({ message: 'Inscription sociale absente ou expirée.' });
    const result = await this.auth.completeSocialSignup(signupToken, body);
    response.clearCookie(SOCIAL_SIGNUP_COOKIE, { ...cookieOptions, maxAge: undefined });
    response.cookie(REFRESH_COOKIE, result.refreshToken, cookieOptions);
    return { accessToken: result.accessToken, user: result.user };
  }

  @Post('register')
  async register(@Body() body: RegisterDto, @Res({ passthrough: true }) response: Response) {
    const result = await this.auth.register(body);
    response.cookie(REFRESH_COOKIE, result.refreshToken, cookieOptions);
    return { accessToken: result.accessToken, user: result.user };
  }

  @Post('password-reset/request') requestPasswordReset(@Body() body: PasswordResetRequestDto) { return this.auth.requestPasswordReset(body.email); }
  @Post('password-reset/confirm') confirmPasswordReset(@Body() body: PasswordResetConfirmDto) { return this.auth.confirmPasswordReset(body.token, body.password); }

  @Post('login')
  async login(@Body() body: LoginDto, @Res({ passthrough: true }) response: Response) {
    const identifier = body.identifier || body.email || body.phone;
    const result = await this.auth.login(identifier || '', body.password);
    response.cookie(REFRESH_COOKIE, result.refreshToken, cookieOptions);
    return { accessToken: result.accessToken, user: result.user };
  }

  @Post('refresh')
  async refresh(@Req() request: Request, @Res({ passthrough: true }) response: Response) {
    const token = request.cookies?.[REFRESH_COOKIE];
    if (!token) return response.status(401).json({ message: 'Session absente.' });
    const result = await this.auth.refresh(token);
    response.cookie(REFRESH_COOKIE, result.refreshToken, cookieOptions);
    return { accessToken: result.accessToken, user: result.user };
  }

  @Post('logout')
  async logout(@Req() request: Request, @Res({ passthrough: true }) response: Response) {
    const token = request.cookies?.[REFRESH_COOKIE];
    if (token) await this.auth.revokeRefresh(token);
    response.clearCookie(REFRESH_COOKIE, { ...cookieOptions, maxAge: undefined });
    return { ok: true };
  }
}
