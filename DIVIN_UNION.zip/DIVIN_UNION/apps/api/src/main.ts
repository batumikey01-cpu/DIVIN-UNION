import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import cookieParser = require('cookie-parser');
import { AppModule } from './app.module';

function validateEnvironment() {
  if (process.env.NODE_ENV === 'production') {
    for (const name of ['DATABASE_URL', 'JWT_SECRET', 'JWT_REFRESH_SECRET', 'WEB_ORIGIN', 'PAYMENT_CONFIG_ENCRYPTION_KEY']) {
      if (!process.env[name] || (process.env[name]!.length < 32 && name.includes('SECRET'))) {
        throw new Error(`Variable d’environnement de production absente ou faible: ${name}`);
      }
    }
    if (!process.env.PAYMENT_CONFIG_ENCRYPTION_KEY || Buffer.from(process.env.PAYMENT_CONFIG_ENCRYPTION_KEY, 'base64').length !== 32) throw new Error('PAYMENT_CONFIG_ENCRYPTION_KEY doit être une clé base64 de 32 octets.');
    if (process.env.JWT_SECRET === 'dev-secret-change-me') {
      throw new Error('JWT_SECRET de développement interdit en production.');
    }
    for (const name of ['EMAIL_OTP_PROVIDER', 'PAYMENT_PROVIDER', 'STORAGE_PROVIDER']) {
      if (!process.env[name] || process.env[name] === 'mock' || process.env[name] === 'local') {
        throw new Error(`Fournisseur de production obligatoire: ${name}`);
      }
    }
    for (const name of ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'MICROSOFT_CLIENT_ID', 'MICROSOFT_CLIENT_SECRET', 'APPLE_CLIENT_ID', 'APPLE_TEAM_ID', 'APPLE_KEY_ID', 'APPLE_PRIVATE_KEY']) {
      if (!process.env[name]) throw new Error(`Configuration OAuth sociale absente: ${name}`);
    }
    if (!process.env.EMAIL_PROVIDER_URL) throw new Error('EMAIL_PROVIDER_URL requis en production pour les emails transactionnels.');
  }
}

function allowedOrigins() {
  return (process.env.WEB_ORIGIN || process.env.CLIENT_URL || 'http://localhost:3000')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);
}

async function bootstrap() {
  validateEnvironment();
  const app = await NestFactory.create(AppModule);
  app.use(helmet());
  app.use(cookieParser());

  const origins = allowedOrigins();
  app.enableCors({
    origin: (origin: string | undefined, callback: (error: Error | null, allowed?: boolean) => void) => {
      // Les clients non navigateur (curl, apps natives) n’envoient pas d’origine.
      if (!origin || origins.includes(origin)) return callback(null, true);
      return callback(new Error('Origine CORS refusée par la politique de sécurité.'));
    },
    methods: ['GET', 'HEAD', 'PUT', 'PATCH', 'POST', 'DELETE', 'OPTIONS'],
    credentials: true,
  });

  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    transform: true,
    forbidNonWhitelisted: true,
    forbidUnknownValues: true,
  }));

  await app.listen(Number(process.env.PORT || process.env.API_PORT || 4000), '0.0.0.0');
}

void bootstrap();
