import { Injectable } from '@nestjs/common'; import { PrismaService } from '../common/prisma.service';
export type NotificationType='MATCH'|'MESSAGE'|'SUBSCRIPTION'|'PAYMENT'|'ADMIN'|'SECURITY';
@Injectable() export class NotificationService { constructor(private readonly db:PrismaService){}
 async create(userId:string,type:NotificationType,title:string,body:string,data?:Record<string,unknown>){return this.db.notification.create({data:{userId,type,title,body,data:data as any}});}
 async notifyNewMatch(userId:string,partnerName:string){return this.create(userId,'MATCH','Nouveau match',`${partnerName} et vous vous êtes appréciés.`,{partnerName});}
 async notifyNewMessage(userId:string,senderName:string,_preview:string){return this.create(userId,'MESSAGE','Nouveau message',`${senderName} vous a envoyé un message.`,{senderName});}
 async notifyPayment(userId:string,body:string){return this.create(userId,'PAYMENT','Paiement',body);}
 async list(userId:string,limit=50){return this.db.notification.findMany({where:{userId},orderBy:{createdAt:'desc'},take:Math.min(Math.max(limit,1),100)});}
 async unreadCount(userId:string){return this.db.notification.count({where:{userId,readAt:null}});}
 async markRead(userId:string,id?:string){if(id)await this.db.notification.updateMany({where:{id,userId},data:{readAt:new Date()}});else await this.db.notification.updateMany({where:{userId,readAt:null},data:{readAt:new Date()}});return{ok:true};}
}
