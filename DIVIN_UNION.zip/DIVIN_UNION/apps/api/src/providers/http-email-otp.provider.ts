import { BadRequestException, Injectable } from '@nestjs/common';
import { EmailOtpProvider } from './provider.types';

@Injectable()
export class HttpEmailOtpProvider implements EmailOtpProvider {
  async sendOtp(email: string, code: string, expiresAt: Date) {
    const apiKey = process.env.RESEND_API_KEY;
    const from = process.env.EMAIL_FROM;

    if (!apiKey) {
      throw new BadRequestException('RESEND_API_KEY non configurée.');
    }

    if (!from) {
      throw new BadRequestException('EMAIL_FROM non configuré.');
    }

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        from,
        to: [email],
        subject: 'Votre code de vérification Divin’Union',
        html: `
          <div style="font-family: Arial, sans-serif; line-height: 1.6;">
            <h2>Divin’Union</h2>
            <p>Votre code de vérification est :</p>
            <p style="font-size: 32px; font-weight: bold; letter-spacing: 8px;">
              ${code}
            </p>
            <p>Ce code expire à ${expiresAt.toISOString()}.</p>
            <p>Si vous n'êtes pas à l'origine de cette demande, ignorez cet e-mail.</p>
          </div>
        `,
      }),
    });

    if (!response.ok) {
      const details = await response.text();
      console.error('Resend email error:', details);
      throw new BadRequestException('Impossible d’envoyer le code email.');
    }
  }

  async sendPasswordReset(email: string, token: string, expiresAt: Date) {
    const apiKey = process.env.RESEND_API_KEY;
    const from = process.env.EMAIL_FROM;

    if (!apiKey) {
      throw new Error('RESEND_API_KEY non configurée.');
    }

    if (!from) {
      throw new Error('EMAIL_FROM non configuré.');
    }

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        from,
        to: [email],
        subject: 'Réinitialisation de votre mot de passe Divin’Union',
        html: `
          <div style="font-family: Arial, sans-serif; line-height: 1.6;">
            <h2>Divin’Union</h2>
            <p>Votre demande de réinitialisation de mot de passe a été reçue.</p>
            <p>Token : ${token}</p>
            <p>Cette demande expire à ${expiresAt.toISOString()}.</p>
          </div>
        `,
      }),
    });

    if (!response.ok) {
      const details = await response.text();
      console.error('Resend password reset error:', details);
      throw new Error('Le fournisseur email a refusé le message.');
    }
  }
}