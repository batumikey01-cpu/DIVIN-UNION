import { Plan } from '@prisma/client';

export interface SmsProvider {
  sendOtp(phone: string, code: string, expiresAt: Date): Promise<void>;
}

export interface CheckoutInput {
  userId: string;
  plan: Exclude<Plan, 'FREE'>;
  successUrl: string;
  cancelUrl: string;
}

export interface CheckoutResult {
  provider: string;
  sessionId: string;
  checkoutUrl: string;
}

export interface PaymentEvent {
  eventId: string;
  type: string;
  sessionId: string;
  userId: string;
  plan: Exclude<Plan, 'FREE'>;
}

export interface PaymentProvider {
  createCheckout(input: CheckoutInput): Promise<CheckoutResult>;
  verifyWebhook(rawBody: Buffer, signature: string): PaymentEvent;
}

export interface UploadIntentInput {
  userId: string;
  objectKey: string;
  contentType: string;
  maxBytes: number;
}

export interface UploadIntent {
  provider: string;
  objectKey: string;
  uploadUrl: string;
  expiresAt: Date;
}

export interface StorageProvider {
  createUploadIntent(input: UploadIntentInput): Promise<UploadIntent>;
  deleteObject(objectKey: string): Promise<void>;
  putObject?(objectKey: string, data: Buffer): Promise<void>;
  getObject?(objectKey: string): Promise<Buffer>;
}

export interface EmailOtpProvider {
  sendOtp(email: string, code: string, expiresAt: Date): Promise<void>;
  sendPasswordReset?(email: string, token: string, expiresAt: Date): Promise<void>;
}
