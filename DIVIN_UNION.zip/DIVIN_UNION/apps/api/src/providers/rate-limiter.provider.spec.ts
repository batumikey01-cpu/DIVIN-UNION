import { InMemoryRateLimiter } from './rate-limiter.provider';

describe('InMemoryRateLimiter', () => {
  it('allows up to the configured limit and rejects the next request', async () => {
    const limiter = new InMemoryRateLimiter();
    await expect(limiter.consume('ip:1', 2, 60_000)).resolves.toMatchObject({ allowed: true, remaining: 1 });
    await expect(limiter.consume('ip:1', 2, 60_000)).resolves.toMatchObject({ allowed: true, remaining: 0 });
    await expect(limiter.consume('ip:1', 2, 60_000)).resolves.toMatchObject({ allowed: false, remaining: 0 });
  });

  it('uses independent buckets for different keys', async () => {
    const limiter = new InMemoryRateLimiter();
    await limiter.consume('ip:1', 1, 60_000);
    await expect(limiter.consume('ip:2', 1, 60_000)).resolves.toMatchObject({ allowed: true });
  });
});
