import { StorageProvider, UploadIntent, UploadIntentInput } from './provider.types';

export class InMemoryStorageProvider implements StorageProvider {
  readonly deleted: string[] = [];

  async createUploadIntent(input: UploadIntentInput): Promise<UploadIntent> {
    return { provider: 'memory-test', objectKey: input.objectKey, uploadUrl: `https://storage.test/upload/${encodeURIComponent(input.objectKey)}`, expiresAt: new Date(Date.now() + 15 * 60_000) };
  }

  async deleteObject(objectKey: string) {
    this.deleted.push(objectKey);
  }
}
