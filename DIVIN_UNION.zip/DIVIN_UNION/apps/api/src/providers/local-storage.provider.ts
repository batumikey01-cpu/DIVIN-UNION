import { mkdir, readFile, unlink, writeFile } from 'node:fs/promises';
import { dirname, join, normalize } from 'node:path';
import { StorageProvider, UploadIntent, UploadIntentInput } from './provider.types';

export class LocalStorageProvider implements StorageProvider {
  private readonly root = process.env.MEDIA_STORAGE_DIR || './storage/media';

  private pathFor(objectKey: string) {
    const safe = normalize(objectKey).replace(/^([.][.][/\\])+/, '').replace(/^[/\\]+/, '');
    const root = normalize(this.root);
    const target = normalize(join(root, safe));
    if (!(target === root || target.startsWith(`${root}/`) || target.startsWith(`${root}\\`))) throw new Error('Invalid object key');
    return target;
  }

  async createUploadIntent(input: UploadIntentInput): Promise<UploadIntent> {
    const expiresAt = new Date(Date.now() + 15 * 60_000);
    return { provider: 'local', objectKey: input.objectKey, uploadUrl: `/media/upload/${encodeURIComponent(input.objectKey)}`, expiresAt };
  }

  async putObject(objectKey: string, data: Buffer) {
    const target = this.pathFor(objectKey);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, data, { flag: 'wx' });
  }

  async getObject(objectKey: string) {
    return readFile(this.pathFor(objectKey));
  }

  async deleteObject(objectKey: string) {
    await unlink(this.pathFor(objectKey)).catch(() => undefined);
  }
}
