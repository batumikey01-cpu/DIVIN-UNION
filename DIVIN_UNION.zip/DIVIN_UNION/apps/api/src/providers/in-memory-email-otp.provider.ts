import { EmailOtpProvider } from './provider.types';
export class InMemoryEmailOtpProvider implements EmailOtpProvider {
  sent: Array<{ email: string; code: string; expiresAt: Date }> = [];
  async sendOtp(email: string, code: string, expiresAt: Date) { this.sent.push({ email, code, expiresAt }); }
  async sendPasswordReset(_email: string, _token: string, _expiresAt: Date) { return; }
}
