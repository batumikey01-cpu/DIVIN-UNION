import { loadProviderConfig } from './provider.config';

describe('loadProviderConfig', () => {
  it('uses safe development defaults', () => {
    const config = loadProviderConfig({ NODE_ENV: 'development' });
    expect(config.smsProvider).toBe('mock');
    expect(config.paymentProvider).toBe('mock');
    expect(config.storageProvider).toBe('local');
  });

  it('rejects mock providers in production', () => {
    expect(() => loadProviderConfig({
      NODE_ENV: 'production',
      SMS_PROVIDER: 'mock',
      PAYMENT_PROVIDER: 'mock',
      STORAGE_PROVIDER: 's3',
      PAYMENT_WEBHOOK_SECRET: 'x'.repeat(32),
    })).toThrow(/interdits en production/);
  });

  it('rejects invalid media limits', () => {
    expect(() => loadProviderConfig({ NODE_ENV: 'test', MAX_MEDIA_BYTES: '10' })).toThrow(/MAX_MEDIA_BYTES/);
  });
});
