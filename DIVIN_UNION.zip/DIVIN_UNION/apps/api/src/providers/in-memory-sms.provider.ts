import { Injectable } from '@nestjs/common';
import { SmsProvider } from './provider.types';

@Injectable()
export class InMemorySmsProvider implements SmsProvider {
  readonly sent: Array<{ phone: string; code: string; expiresAt: Date }> = [];

  async sendOtp(phone: string, code: string, expiresAt: Date) {
    this.sent.push({ phone, code, expiresAt });
  }
}
