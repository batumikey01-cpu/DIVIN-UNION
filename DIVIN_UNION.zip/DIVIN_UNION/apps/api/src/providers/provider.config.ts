export type RuntimeEnvironment = 'development' | 'test' | 'staging' | 'production';

export interface ProviderConfig {
  nodeEnv: RuntimeEnvironment;
  smsProvider: string;
  paymentProvider: string;
  storageProvider: string;
  paymentWebhookSecret?: string;
  maxMediaBytes: number;
}

const isRuntimeEnvironment = (value: string): value is RuntimeEnvironment =>
  value === 'development' || value === 'test' || value === 'staging' || value === 'production';

export function loadProviderConfig(env: NodeJS.ProcessEnv = process.env): ProviderConfig {
  const nodeEnv = env.NODE_ENV && isRuntimeEnvironment(env.NODE_ENV) ? env.NODE_ENV : 'development';
  const config: ProviderConfig = {
    nodeEnv,
    smsProvider: env.SMS_PROVIDER || 'mock',
    paymentProvider: env.PAYMENT_PROVIDER || 'mock',
    storageProvider: env.STORAGE_PROVIDER || 'local',
    paymentWebhookSecret: env.PAYMENT_WEBHOOK_SECRET,
    maxMediaBytes: Number(env.MAX_MEDIA_BYTES || 10 * 1024 * 1024),
  };

  if (!Number.isSafeInteger(config.maxMediaBytes) || config.maxMediaBytes < 1024) {
    throw new Error('MAX_MEDIA_BYTES doit être un entier sûr supérieur ou égal à 1024.');
  }
  if (nodeEnv === 'production') {
    if ([config.paymentProvider, config.storageProvider].some((provider) => ['mock', 'local'].includes(provider))) {
      throw new Error('Les providers mock/local sont interdits en production.');
    }
  }
  return config;
}
