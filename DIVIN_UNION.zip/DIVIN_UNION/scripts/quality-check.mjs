import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

function files(dir) {
  return readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    return statSync(path).isDirectory() ? files(path) : [path];
  });
}

const api = files('apps/api/src').filter((file) => file.endsWith('.ts') && !file.endsWith('.spec.ts'));
const web = files('apps/web/src').filter((file) => file.endsWith('.ts') || file.endsWith('.tsx'));
const apiText = api.map((file) => readFileSync(file, 'utf8')).join('\n');
const webText = web.map((file) => readFileSync(file, 'utf8')).join('\n');
const failures = [];
if (webText.includes('localStorage')) failures.push('localStorage doit rester absent du frontend.');
if (/devCode|\[DEV OTP\]/.test(apiText)) failures.push('Le code OTP de développement ne doit pas être exposé dans le code source runtime.');
if (/\@Body\(\)\s+\w+\s*:\s*any/.test(apiText)) failures.push('Les corps de contrôleurs ne doivent pas utiliser any.');
if (!readFileSync('apps/web/next.config.ts', 'utf8').includes('Content-Security-Policy')) failures.push('CSP frontend absente.');
if (failures.length) { console.error(failures.join('\n')); process.exit(1); }
console.log(`Quality check OK (${api.length} fichiers API, ${web.length} fichiers Web).`);
