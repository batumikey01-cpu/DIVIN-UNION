from pathlib import Path
from PIL import Image

logo = Image.open('apps/web/public/logo-divin-union.png').convert('RGBA')
for name, color in [('white', (255, 255, 255, 255)), ('navy', (24, 54, 111, 255))]:
    background = Image.new('RGBA', logo.size, color)
    background.alpha_composite(logo)
    background.convert('RGB').save(Path('docs') / f'logo-preview-{name}.png')
print('created logo previews')
