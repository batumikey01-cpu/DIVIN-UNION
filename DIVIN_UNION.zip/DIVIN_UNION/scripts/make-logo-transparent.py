from pathlib import Path
from PIL import Image

path = Path('apps/web/public/logo-divin-union.png')
image = Image.open(path).convert('RGBA')
updated = []
for red, green, blue, _alpha in image.getdata():
    blue_logo = blue > 55 and blue > red * 1.08 and blue > green * 1.03
    gold_logo = red > 105 and green > 65 and red > green * 1.08 and green > blue * 1.55
    updated.append((red, green, blue, 255 if blue_logo or gold_logo else 0))
image.putdata(updated)
image.save(path, format='PNG', optimize=True)
alpha = image.getchannel('A')
print(f'updated {path} — size={image.size} alpha_extrema={alpha.getextrema()}')
