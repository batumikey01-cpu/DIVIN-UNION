import { readFileSync, writeFileSync } from 'node:fs';

const pagePath = 'apps/web/src/app/page.tsx';
let page = readFileSync(pagePath, 'utf8');
const replacements = [
  [
    '<a href="#community" className="mt-5 flex w-fit items-center gap-2 text-xs font-semibold text-[#43566e] transition hover:text-[#17233d]"><ShieldIcon className="h-4 w-4 text-[#18366f]" /> Une communauté chrétienne en construction</a>',
    '',
  ],
  [
    '<h2 className={sectionTitle}>Une rencontre fondée sur l’essentiel</h2>',
    '<h2 className={`${sectionTitle} mx-auto max-w-4xl`}>Quand la foi unit les cœurs, l’amour prend un autre sens.</h2>',
  ],
  [
    '<div className="relative mt-14 grid gap-0 overflow-hidden rounded-[1.75rem] border border-[#d9e3ea] bg-white/35 sm:grid-cols-2 md:grid-cols-4 md:divide-x md:divide-[#d9e3ea]"><div className="pointer-events-none absolute left-[12%] right-[12%] top-[4.45rem] hidden h-px bg-[#d8bd82] md:block" />{steps.map(([number, title, text, Icon]) => <div key={number} className="relative z-10 border-b border-[#d9e3ea] px-5 py-8 md:border-b-0 md:px-5 lg:px-6 lg:py-9">',
    '<div className="journey-steps relative mt-14 grid gap-0 sm:grid-cols-2 md:grid-cols-4"><div className="journey-line pointer-events-none absolute left-[12%] right-[12%] top-[4.45rem] hidden h-px bg-[#d8bd82] md:block" />{steps.map(([number, title, text, Icon]) => <div key={number} className="journey-step relative z-10 border-b border-[#d9e3ea] px-5 py-9 md:border-b-0 md:px-5 lg:px-6 lg:py-10">',
  ],
];
for (const [from, to] of replacements) {
  if (!page.includes(from)) throw new Error(`Missing page replacement: ${from.slice(0, 80)}`);
  page = page.replace(from, to);
}
writeFileSync(pagePath, page);

const headerPath = 'apps/web/src/components/landing-header.tsx';
let header = readFileSync(headerPath, 'utf8');
const headerReplacements = [
  [
    'className="flex w-[88px] flex-col items-center justify-center text-center"',
    'className="flex w-[112px] flex-col items-center justify-center text-center"',
  ],
  [
    'width={38} height={39} className="h-9 w-9 object-contain"',
    'width={54} height={55} className="h-12 w-12 object-contain sm:h-[54px] sm:w-[54px]"',
  ],
  [
    'className="mt-0.5 whitespace-nowrap font-serif text-[11px] font-bold tracking-[-.045em]"',
    'className="mt-0.5 whitespace-nowrap font-serif text-[12px] font-bold tracking-[-.045em]"',
  ],
  [
    'className="sticky top-0 z-40 border-b border-[#e8e3d9]/90 bg-[#fbfaf7]/95 backdrop-blur-md"><div className="mx-auto flex h-[78px]',
    'className="sticky top-0 z-40 border-b border-[#e8e3d9]/90 bg-[#fbfaf7]/95 backdrop-blur-md"><div className="mx-auto flex h-[88px]',
  ],
];
for (const [from, to] of headerReplacements) {
  if (!header.includes(from)) throw new Error(`Missing header replacement: ${from.slice(0, 80)}`);
  header = header.replace(from, to);
}
writeFileSync(headerPath, header);
console.log('final landing fixes applied');
