const env = process.env;
const required = ['DATABASE_URL', 'JWT_SECRET', 'JWT_REFRESH_SECRET', 'WEB_ORIGIN', 'SMS_PROVIDER', 'PAYMENT_PROVIDER', 'STORAGE_PROVIDER'];
const missing = required.filter((name) => !env[name]);
if (missing.length) throw new Error(`Variables manquantes: ${missing.join(', ')}`);
if (env.NODE_ENV === 'production') {
  if ([env.SMS_PROVIDER, env.PAYMENT_PROVIDER, env.STORAGE_PROVIDER].some((value) => ['mock', 'local'].includes(value))) throw new Error('Provider mock/local interdit en production.');
  if (!env.PAYMENT_WEBHOOK_SECRET || env.PAYMENT_WEBHOOK_SECRET.length < 32) throw new Error('PAYMENT_WEBHOOK_SECRET trop court ou absent.');
  for (const name of ['JWT_SECRET', 'JWT_REFRESH_SECRET']) if (env[name].length < 32) throw new Error(`${name} trop court.`);
}
console.log(`Configuration ${env.NODE_ENV || 'development'} valide.`);
