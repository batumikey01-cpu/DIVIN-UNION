import { readFileSync, writeFileSync } from 'node:fs';

const pagePath = 'apps/web/src/app/page.tsx';
let page = readFileSync(pagePath, 'utf8');
page = page.replace(
  "import { LandingFooter } from '../components/landing-footer';",
  "import { LandingFooter } from '../components/landing-footer';\nimport { LandingDownloadSection } from '../components/landing-download-section';",
);
const changes = [
  ['className="bg-white px-5 py-20 sm:px-8 lg:px-10 lg:py-24"', 'className="bg-white px-5 py-14 sm:px-8 lg:px-10 lg:py-24"'],
  ['<div className="mt-14 grid overflow-hidden', '<div className="mt-10 grid overflow-hidden'],
  ['px-6 py-8 text-center transition', 'px-5 py-6 text-center transition'],
  ['className="relative overflow-hidden bg-[#edf4f8] px-5 py-20 sm:px-8 lg:px-10 lg:py-24"', 'className="relative overflow-hidden bg-[#edf4f8] px-5 py-14 sm:px-8 lg:px-10 lg:py-24"'],
  ['className="journey-steps relative mt-14 grid gap-0', 'className="journey-steps relative mt-10 grid gap-0'],
  ['px-5 py-9 md:border-b-0 md:px-5 lg:px-6 lg:py-10', 'px-5 py-6 md:border-b-0 md:px-5 lg:px-6 lg:py-10'],
  ['mt-4 flex h-11 w-11', 'mt-3 flex h-11 w-11'],
  ['className="mx-auto mt-4 min-h-[2.6rem]', 'className="mx-auto mt-3 min-h-[2.6rem]'],
  ['max-w-[210px] text-xs leading-6', 'max-w-[210px] text-xs leading-5'],
  ['className="landing-button mt-10 inline-flex', 'className="landing-button mt-8 inline-flex'],
  ['<p className="mx-auto mt-4 max-w-xl text-center text-[15px] leading-7 text-[#6b7280]">Découvrez des personnes qui partagent vos valeurs et vos intentions.</p><div className="mt-12"><ProfileCarousel /></div>', '<p className="mx-auto mt-3 max-w-xl text-center text-[15px] leading-7 text-[#6b7280]">Découvrez des personnes qui partagent vos valeurs et vos intentions.</p><div className="mt-9"><ProfileCarousel /></div>'],
];
for (const [from, to] of changes) page = page.replace(from, to);
const testimonialsMarker = '      <section id="testimonials"><TestimonialCarousel /></section>';
if (!page.includes(testimonialsMarker)) throw new Error('Testimonials marker missing');
page = page.replace(testimonialsMarker, `${testimonialsMarker}\n\n      <LandingDownloadSection />`);
writeFileSync(pagePath, page);

for (const [path, lines] of [
  ['.env.example', '\n# Landing downloads — leave blank until the official APK/App Store links exist\nNEXT_PUBLIC_ANDROID_DOWNLOAD_URL=\nNEXT_PUBLIC_IOS_DOWNLOAD_URL=\n'],
  ['.env.staging.example', '\n# Landing downloads — inject official distribution URLs when available\nNEXT_PUBLIC_ANDROID_DOWNLOAD_URL=\nNEXT_PUBLIC_IOS_DOWNLOAD_URL=\n'],
]) {
  const current = readFileSync(path, 'utf8');
  if (!current.includes('NEXT_PUBLIC_ANDROID_DOWNLOAD_URL')) writeFileSync(path, current + lines);
}
console.log('launch finish applied');
