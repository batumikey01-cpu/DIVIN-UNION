# Divin'Union

MVP full-stack d'une plateforme de rencontres chrétiennes francophone. Monorepo pnpm avec Next.js, NestJS, Prisma/PostgreSQL et Redis.

## Architecture
- `apps/web`: interface web responsive.
- `apps/api`: API REST + Socket.IO, authentification, profils, matching, messagerie, modération, abonnements et administration.
- `infra`: Docker Compose pour PostgreSQL et Redis.
- `packages/*`: contrats/types partagés.

## Démarrage local
1. Copier `.env.example` vers `.env` et ajuster les secrets.
2. `docker compose -f infra/docker-compose.yml up -d`
3. `pnpm install`
4. `pnpm db:generate`
5. `pnpm db:migrate`
6. `pnpm db:seed`
7. `pnpm dev`

Web: http://localhost:3000 — API: http://localhost:4000

## Sécurité MVP
- OTP téléphone obligatoire avant activation.
- Profil impossible à publier sans photo.
- Contrôle serveur de la limite gratuite de 5 messages/jour.
- Filtrage des coordonnées sociales/téléphoniques côté serveur avant persistance.
- RBAC super-admin / sous-admin.
- Validation DTO stricte.
- Hash des mots de passe avec Argon2id.
- JWT court + refresh token rotatif (à brancher au stockage persistant de session avant production).

## Important
Le fournisseur SMS et le prestataire de paiement sont volontairement abstraits. Le code inclut un mode mock pour le développement. Avant production, il faut brancher le fournisseur choisi, ses webhooks signés et ses clés secrètes sans les committer.
